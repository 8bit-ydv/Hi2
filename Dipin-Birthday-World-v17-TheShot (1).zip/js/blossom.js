/* =============================================================
   BLOSSOM — the divine wish tree (WebGL), chapter 3 of scene ii

   Ported from "Blossom Animation 2026" and rebuilt:
     • the project's own vendored three.module.min.js (r160)
     • transparent renderer — the site's night sky IS the sky
     • tree.obj vendored locally, procedural fallback if missing
     • OrbitControls → a scroll-driven orbit + pointer parallax
     • SOLID plum trunk with a double glowing outline (gold
       filament + rose-gold aura) — divine, not "simple wood"
     • the canopy is real sakura FOLIAGE: thousands of soft pink
       leaves clustered around the branch tips (custom shader,
       sway + twinkle + depth shading), over the dark silhouette
     • growth animation: the tree rises from a sapling
     • a warm moon behind the crown, a swing + lantern on the
       branches, a fallen-sakura carpet + pink leaves under it
     • the petal swarm is deliberately sparse and slow (pink,
       the "2026" year petals stay gold)
     • god-rays and a halo give the tree its divine light

   Exposes window.Blossom = { mount, setProgress, setActive,
   setPointer, setWind, resize, ready }
   ============================================================ */
import * as THREE from "../assets/vendor/three.module.min.js";

(function (w) {
  const mobile = matchMedia("(max-width: 820px)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  const TREE_HEIGHT = 16;
  /* foliage density: enough to read as leaves, not a swarm */
  const CANOPY_CLUSTERS = mobile ? 24 : 36;
  const CANOPY_PER = mobile ? 48 : 72;
  const GLOW_PER = mobile ? 100 : 180;
  const FIREFLIES = mobile ? 36 : 64;
  /* the petal swarm — intentionally few, slow, candle-soft */
  const PETAL_PTS = mobile ? 2200 : 4200;

  const M = { mounted: false, ready: false, failed: false, active: false, progress: 0 };

  let renderer = null, scene = null, camera = null, canvas = null;
  let treeMesh = null, canopy = null, canopyGlow = null, petals = null;
  let rays = null, halo = null, base = null, carpet = null;
  let moon = null, fireflies = null, swingGrp = null, lantern = null;
  let trunkOutline = null, trunkAura = null, underLeaves = null;

  const uTimeCanopy = { value: 0 };
  const uRevealCanopy = { value: 0 };
  const uGrow = { value: 1 };
  const uWind = { value: 0 };
  const uniformsTree = { time: { value: 0 }, uGrow: uGrow };
  const uniforms = {
    time: { value: 0 },
    upperLimit: { value: 12 },
    upperRatio: { value: 1.25 },
    spiralRadius: { value: 1 },
    spiralTurns: { value: 1 },
    tex2026: { value: null },
    azimuth: { value: 0 },
    uReveal: { value: 0 },
    uYear: { value: 0 }
  };
  const rayMats = [];

  const ptr = { x: 0, y: 0, tx: 0, ty: 0 };
  let clockT = 0, lastFrame = 0, wind = 0;

  const lerp = (a, b, t) => a + (b - a) * t;
  const clamp01 = v => Math.max(0, Math.min(1, v));
  const smooth = t => t * t * (3 - 2 * t);
  const randFloat = (a, b) => a + Math.random() * (b - a);
  const gauss = () => (Math.random() + Math.random() + Math.random() - 1.5) * 0.816;

  /* ---------- tiny OBJ parser (positions + fan faces) ---------- */
  function parseOBJ(text) {
    const vs = [], idx = [], lines = text.split("\n");
    for (let i = 0; i < lines.length; i++) {
      const ln = lines[i].trim();
      if (ln.startsWith("v ")) {
        const p = ln.split(/\s+/);
        vs.push(+p[1], +p[2], +p[3]);
      } else if (ln.startsWith("f ")) {
        const p = ln.split(/\s+/).slice(1).map(tok => parseInt(tok.split("/")[0], 10) - 1);
        for (let k = 1; k < p.length - 1; k++) idx.push(p[0], p[k], p[k + 1]);
      }
    }
    return { positions: new Float32Array(vs), indices: idx };
  }

  /* ---------- area-weighted surface sampler ---------- */
  function sampleSurface(positions, indices, count) {
    const tri = indices.length / 3;
    const cdf = new Float32Array(tri);
    const a = new THREE.Vector3(), b = new THREE.Vector3(), c = new THREE.Vector3();
    const ab = new THREE.Vector3(), ac = new THREE.Vector3(), cr = new THREE.Vector3();
    let total = 0;
    for (let i = 0; i < tri; i++) {
      a.fromArray(positions, indices[i * 3] * 3);
      b.fromArray(positions, indices[i * 3 + 1] * 3);
      c.fromArray(positions, indices[i * 3 + 2] * 3);
      ab.subVectors(b, a); ac.subVectors(c, a); cr.crossVectors(ab, ac);
      total += cr.length() * 0.5; cdf[i] = total;
    }
    const pts = [];
    const p = new THREE.Vector3();
    for (let i = 0; i < count; i++) {
      const r = Math.random() * total;
      let lo = 0, hi = tri - 1;
      while (lo < hi) { const mid = (lo + hi) >> 1; if (cdf[mid] < r) lo = mid + 1; else hi = mid; }
      a.fromArray(positions, indices[lo * 3] * 3);
      b.fromArray(positions, indices[lo * 3 + 1] * 3);
      c.fromArray(positions, indices[lo * 3 + 2] * 3);
      ab.subVectors(b, a); ac.subVectors(c, a);
      let u = Math.random(), v = Math.random();
      if (u + v > 1) { u = 1 - u; v = 1 - v; }
      p.copy(a).addScaledVector(ab, u).addScaledVector(ac, v);
      pts.push(p.clone());
    }
    return pts;
  }

  /* ---------- procedural fallback tree cloud ---------- */
  function proceduralTree(count) {
    const pts = [];
    (function branch(x, y, z, dx, dy, dz, len, depth) {
      const steps = Math.max(2, Math.round(len * 7));
      for (let s = 0; s < steps; s++) {
        const t = s / steps;
        pts.push(new THREE.Vector3(
          x + dx * len * t + randFloat(-.04, .04),
          y + dy * len * t + randFloat(-.04, .04),
          z + dz * len * t + randFloat(-.04, .04)));
      }
      const nx = x + dx * len, ny = y + dy * len, nz = z + dz * len;
      if (depth <= 0) {
        for (let i = 0; i < 46; i++) {
          const r = randFloat(0.1, 0.6) * len * 2.4;
          const az = randFloat(0, Math.PI * 2), po = Math.acos(randFloat(-1, 1));
          pts.push(new THREE.Vector3(
            nx + r * Math.sin(po) * Math.cos(az),
            ny + r * Math.cos(po) * 0.8,
            nz + r * Math.sin(po) * Math.sin(az)));
        }
        return;
      }
      const kids = 2 + (Math.random() < .45 ? 1 : 0);
      for (let k = 0; k < kids; k++) {
        const aa = randFloat(0, Math.PI * 2), tilt = randFloat(0.35, 0.8);
        const nd = new THREE.Vector3(
          dx * (1 - tilt) + Math.cos(aa) * tilt + randFloat(-.18, .18),
          dy * 0.75 + 0.4,
          dz * (1 - tilt) + Math.sin(aa) * tilt + randFloat(-.18, .18)
        ).normalize();
        branch(nx, ny, nz, nd.x, nd.y, nd.z, len * randFloat(0.62, 0.78), depth - 1);
      }
    })(0, 0, 0, randFloat(-.05, .05), 1, randFloat(-.05, .05), 1.05, 4);
    while (pts.length < count) {
      const i = (Math.random() * pts.length) | 0;
      pts.push(pts[i].clone().add(new THREE.Vector3(randFloat(-.05, .05), randFloat(-.05, .05), randFloat(-.05, .05))));
    }
    return pts.slice(0, count);
  }

  /* ---------- the year, written in petals ---------- */
  function makeYearTexture() {
    const cnvs = document.createElement("canvas");
    cnvs.width = 128; cnvs.height = 64;
    const ctx = cnvs.getContext("2d");
    ctx.fillStyle = "transparent";
    ctx.fillRect(0, 0, cnvs.width, cnvs.height);
    ctx.fillStyle = "#f3c98b";
    ctx.textAlign = "center"; ctx.textBaseline = "middle";
    ctx.font = "bold 56px Arial";
    ctx.fillText("2026", cnvs.width * 0.5, cnvs.height * 0.5);
    return new THREE.CanvasTexture(cnvs);
  }

  /* ---------- foliage: sakura leaves clustered at branch tips ----------
     pure sakura pink — inner soft pink, outer deep sakura, zero gold.
     aY (cluster height) + uGrow gate the growth: the canopy pops in
     as the growth line climbs the tree.                                */
  const canopyVert = `
    uniform float uTime;
    uniform float uGrow;
    uniform float uWind;
    attribute float aSize;
    attribute float aTint;
    attribute float aPhase;
    attribute float aY;
    varying float vTint;
    varying float vTw;
    varying float vDim;
    varying float vGate;
    void main(){
      vTint = aTint;
      vec3 p = position;
      float ph = aPhase * 6.2831;
      float sway = 0.15 + uWind * 0.22;
      p.x += sin(uTime * 0.55 + ph + position.y * 0.32) * sway;
      p.z += cos(uTime * 0.45 + ph * 0.8) * sway * 0.86;
      p.y += sin(uTime * 0.7 + ph * 1.7) * 0.06;
      vTw = 0.84 + 0.16 * sin(uTime * 2.1 + ph * 3.0);
      /* growth gate: a point blooms only once the growth line passes its height */
      float hN = clamp(aY / ${TREE_HEIGHT.toFixed(1)}, 0.0, 1.0);
      vGate = smoothstep(hN - 0.22, hN + 0.02, uGrow * 1.22);
      float pop = 0.6 + 0.4 * vGate;
      vec4 mv = modelViewMatrix * vec4(p, 1.0);
      float dist = -mv.z;
      vDim = clamp(1.55 - dist / 34.0, 0.35, 1.0);
      gl_PointSize = aSize * pop * (250.0 / max(1.0, dist));
      gl_Position = projectionMatrix * mv;
    }`;
  const canopyFrag = `
    uniform float uReveal;
    uniform float uAlpha;
    uniform float uGold;
    varying float vTint;
    varying float vTw;
    varying float vDim;
    varying float vGate;
    void main(){
      vec2 uv = gl_PointCoord - 0.5;
      float d = length(uv);
      float a = smoothstep(0.5, 0.14, d) * uReveal * vTw * uAlpha * vDim * vGate;
      if (a < 0.012) discard;
      vec3 inner = mix(vec3(1.00, 0.878, 0.910), vec3(1.00, 0.886, 0.700), uGold * smoothstep(0.30, 0.72, vTint));  // sakura / ivory-gold split
      vec3 outer = mix(vec3(0.941, 0.451, 0.600), vec3(1.00, 0.760, 0.380), uGold * smoothstep(0.30, 0.72, vTint));  // deep sakura / gold
      vec3 col = mix(inner, outer, vTint);
      gl_FragColor = vec4(col * (0.88 + 0.30 * uReveal), a);
    }`;

  function makeCanopyLayer(pos, sizes, tints, phases, ys, additive, alpha, sizeMul, gold) {
    const g = new THREE.BufferGeometry();
    g.setAttribute("position", new THREE.Float32BufferAttribute(pos, 3));
    g.setAttribute("aSize", new THREE.Float32BufferAttribute(sizes.map(s => s * sizeMul), 1));
    g.setAttribute("aTint", new THREE.Float32BufferAttribute(tints, 1));
    g.setAttribute("aPhase", new THREE.Float32BufferAttribute(phases, 1));
    g.setAttribute("aY", new THREE.Float32BufferAttribute(ys, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      blending: additive ? THREE.AdditiveBlending : THREE.NormalBlending,
      uniforms: { uTime: uTimeCanopy, uReveal: uRevealCanopy, uGrow: uGrow, uWind: uWind, uAlpha: { value: alpha }, uGold: { value: gold ? 1 : 0 } },
      vertexShader: canopyVert, fragmentShader: canopyFrag
    });
    const pts = new THREE.Points(g, mat);
    pts.renderOrder = additive ? 3 : 1;
    return pts;
  }

  function buildCanopyFromCloud(cloudPts, normalise) {
    // cluster centres: spread points from the upper half of the tree
    const up = cloudPts.map(normalise).filter(p => p.y > TREE_HEIGHT * 0.42);
    const pool = up.length > 12 ? up : cloudPts.map(normalise);
    const centres = [];
    let guard = 0;
    while (centres.length < CANOPY_CLUSTERS && guard++ < 600) {
      const c = pool[(Math.random() * pool.length) | 0];
      if (!centres.some(o => o.distanceTo(c) < 0.95)) centres.push(c);
    }
    if (!centres.length) centres.push(new THREE.Vector3(0, TREE_HEIGHT * 0.8, 0));

    const pos = [], sizes = [], tints = [], phases = [], ys = [];
    const glowPos = [], glowSizes = [], glowTints = [], glowPhases = [], glowYs = [];
    centres.forEach(c => {
      const n = Math.round(CANOPY_PER * randFloat(0.8, 1.2));
      for (let i = 0; i < n; i++) {
        const sx = gauss() * 0.72, sy = gauss() * 0.52, sz = gauss() * 0.72;
        pos.push(c.x + sx, c.y + sy, c.z + sz);
        const rr = Math.sqrt(sx * sx + sz * sz) / 1.2;
        sizes.push(randFloat(0.5, 1.0));
        tints.push(clamp01(rr * 0.8 + randFloat(0, 0.3)));
        phases.push(Math.random());
        ys.push(c.y + sy);
      }
      for (let i = 0; i < Math.round(GLOW_PER / centres.length); i++) {
        glowPos.push(c.x + gauss() * 0.8, c.y + gauss() * 0.55, c.z + gauss() * 0.8);
        glowSizes.push(randFloat(1.6, 2.8));
        glowTints.push(Math.random());
        glowPhases.push(Math.random());
        glowYs.push(c.y);
      }
    });
    canopy = makeCanopyLayer(pos, sizes, tints, phases, ys, false, 0.96, 1, true); // gold divine body
    canopyGlow = makeCanopyLayer(glowPos, glowSizes, glowTints, glowPhases, glowYs, true, 0.30, 1, true);
    scene.add(canopy, canopyGlow);
    buildUnderLeaves();
  }

  /* ---------- pink fallen sakura + low foliage under the tree ----------
     msg-15 fix: the pink leaves/flowers under the tree must READ clearly */
  function buildUnderLeaves() {
    underLeaves = new THREE.Group();
    const N = mobile ? 220 : 420;
    const pos = [], sizes = [], tints = [], phases = [], ys = [];
    for (let i = 0; i < N; i++) {
      const r = Math.sqrt(Math.random()) * 6.8;
      const a = Math.random() * Math.PI * 2;
      const x = Math.cos(a) * r, z = Math.sin(a) * r;
      pos.push(x, randFloat(0.04, 0.34) * (1 - r / 8), z);
      sizes.push(randFloat(0.55, 1.15));
      tints.push(clamp01(Math.random() * 0.9));
      phases.push(Math.random());
      ys.push(TREE_HEIGHT); /* under-leaves are present from the start of the growth finish */
    }
    const layer = makeCanopyLayer(pos, sizes, tints, phases, ys, false, 1.0, 1.15);
    layer.renderOrder = 1;
    underLeaves.add(layer);
    /* a few brighter fallen petals right at the base */
    const pos2 = [], sz2 = [], tn2 = [], ph2 = [], y2 = [];
    for (let i = 0; i < Math.round(N * 0.4); i++) {
      const r = Math.sqrt(Math.random()) * 3.4;
      const a = Math.random() * Math.PI * 2;
      pos2.push(Math.cos(a) * r, randFloat(0.10, 0.55), Math.sin(a) * r);
      sz2.push(randFloat(0.8, 1.5));
      tn2.push(clamp01(0.15 + Math.random() * 0.55));
      ph2.push(Math.random());
      y2.push(TREE_HEIGHT);
    }
    const layer2 = makeCanopyLayer(pos2, sz2, tn2, ph2, y2, true, 0.22, 1.1, true);
    underLeaves.add(layer2);
    scene.add(underLeaves);
  }

  /* ---------- the ghost silhouette + solid plum trunk from the OBJ ----------
     msg-8/14: the trunk is a near-black plum silhouette with a double
     glowing outline — a crisp gold filament + a wide rose-gold aura. */
  function buildTree(positions, indices) {
    let minY = Infinity, maxY = -Infinity, minX = Infinity, maxX = -Infinity, minZ = Infinity, maxZ = -Infinity;
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i], y = positions[i + 1], z = positions[i + 2];
      if (x < minX) minX = x; if (x > maxX) maxX = x;
      if (y < minY) minY = y; if (y > maxY) maxY = y;
      if (z < minZ) minZ = z; if (z > maxZ) maxZ = z;
    }
    const s = TREE_HEIGHT / Math.max(1e-6, maxY - minY);
    const cx = (minX + maxX) / 2, cz = (minZ + maxZ) / 2;
    const map = p => new THREE.Vector3((p.x - cx) * s, (p.y - minY) * s, (p.z - cz) * s);

    const g = new THREE.BufferGeometry();
    const pos = new Float32Array(positions.length);
    for (let i = 0; i < positions.length; i += 3) {
      const p = map({ x: positions[i], y: positions[i + 1], z: positions[i + 2] });
      pos[i] = p.x; pos[i + 1] = p.y; pos[i + 2] = p.z;
    }
    g.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    g.setIndex(indices);

    /* solid plum bark — rose-tinted toward the top, near-black at the roots */
    const barkMat = new THREE.ShaderMaterial({
      transparent: true,
      uniforms: { uGrow: uGrow },
      vertexShader: `
        varying vec3 vPos; varying vec3 vN;
        void main(){
          vPos = position; vN = normalize(normalMatrix * normal);
          vec3 p = position;
          gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
        }`,
      fragmentShader: `
        uniform float uGrow; varying vec3 vPos; varying vec3 vN;
        void main(){
          float h = clamp(vPos.y / ${TREE_HEIGHT.toFixed(1)}, 0.0, 1.0);
          vec3 lo = vec3(0.030, 0.016, 0.030);          // near-black plum
          vec3 hi = vec3(0.115, 0.055, 0.085);          // rose-tinted top
          vec3 col = mix(lo, hi, h);
          float rim = pow(1.0 - abs(vN.z), 2.2);
          col += vec3(0.13, 0.09, 0.10) * rim;
          gl_FragColor = vec4(col, 1.0);
        }`
    });
    treeMesh = new THREE.Mesh(g, barkMat);
    treeMesh.renderOrder = 0;
    scene.add(treeMesh);

    /* glowing outline: a crisp gold filament + a wide rose-gold aura */
    const edgeGeo = new THREE.EdgesGeometry(g, 32);
    trunkOutline = new THREE.LineSegments(edgeGeo, new THREE.LineBasicMaterial({
      color: 0xffd9a6, transparent: true, opacity: 0.34, depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    trunkOutline.renderOrder = 2;
    scene.add(trunkOutline);
    trunkAura = new THREE.Mesh(g.clone(), new THREE.MeshBasicMaterial({
      color: 0xe8949f, transparent: true, opacity: 0.11, depthWrite: false,
      side: THREE.BackSide, blending: THREE.AdditiveBlending
    }));
    trunkAura.scale.setScalar(1.045);
    trunkAura.renderOrder = 1;
    scene.add(trunkAura);

    buildCanopyFromCloud(sampleSurface(positions, indices, CANOPY_CLUSTERS * 12), map);
    if (!swingGrp) buildSwing();
    if (!lantern) buildLantern();
  }

  /* ---------- the swing on the lower branch ---------- */
  function buildSwing() {
    swingGrp = new THREE.Group();
    const ropeMat = new THREE.MeshBasicMaterial({ color: 0xc9a3b2, transparent: true, opacity: 0.75 });
    const seatMat = new THREE.MeshBasicMaterial({ color: 0x8a5f74, transparent: true, opacity: 0.9 });
    const ropeGeo = new THREE.CylinderGeometry(0.035, 0.035, 4.4, 6);
    const r1 = new THREE.Mesh(ropeGeo, ropeMat); r1.position.set(-0.55, -2.2, 0);
    const r2 = new THREE.Mesh(ropeGeo, ropeMat); r2.position.set(0.55, -2.2, 0);
    const seat = new THREE.Mesh(new THREE.BoxGeometry(1.5, 0.12, 0.55), seatMat);
    seat.position.set(0, -4.42, 0);
    swingGrp.add(r1, r2, seat);
    swingGrp.position.set(2.5, 9, 0.4);
    swingGrp.renderOrder = 2;
    scene.add(swingGrp);
  }

  /* ---------- the lantern on the far branch ---------- */
  function buildLantern() {
    const cnvs = document.createElement("canvas");
    cnvs.width = cnvs.height = 64;
    const ctx = cnvs.getContext("2d");
    const g = ctx.createRadialGradient(32, 32, 2, 32, 32, 30);
    g.addColorStop(0, "rgba(255,220,160,1)");
    g.addColorStop(0.35, "rgba(255,190,120,0.55)");
    g.addColorStop(1, "rgba(255,170,90,0)");
    ctx.fillStyle = g; ctx.fillRect(0, 0, 64, 64);
    const mat = new THREE.SpriteMaterial({
      map: new THREE.CanvasTexture(cnvs), transparent: true,
      blending: THREE.AdditiveBlending, depthWrite: false
    });
    lantern = new THREE.Sprite(mat);
    lantern.position.set(-2.5, 8.2, 0.6);
    lantern.scale.setScalar(1.9);
    scene.add(lantern);
  }

  /* ---------- the petals: a slow, sparse spiral of sakura candle-light ---------- */
  function buildPetals() {
    const r = 5.5;
    const points = [], delay = [], speed = [], color = [];
    const c = new THREE.Color();
    let count = 0;
    while (count < PETAL_PTS) {
      const vec = new THREE.Vector3(randFloat(-r, r), 0, randFloat(-r, r));
      const rRatio = vec.length() / r;
      if (vec.length() <= r && Math.random() < (1 - rRatio)) {
        points.push(vec);
        /* sakura pink motes — with a soft ivory variance */
        c.setHSL(0.94 + Math.random() * 0.04, 0.55, 0.72 + Math.random() * 0.12);
        color.push(c.r, c.g, c.b);
        delay.push(randFloat(-10, 0));
        let val = randFloat(1, 2) * 0.8;                 // slower rise
        val = Math.random() < 0.25 ? 0 : val;
        speed.push(Math.PI * val * 0.125, val);
        count++;
      }
    }
    const g = new THREE.BufferGeometry().setFromPoints(points);
    g.setAttribute("color", new THREE.Float32BufferAttribute(color, 3));
    g.setAttribute("delay", new THREE.Float32BufferAttribute(delay, 1));
    g.setAttribute("speed", new THREE.Float32BufferAttribute(speed, 2));

    const mat = new THREE.PointsMaterial({ vertexColors: true, size: 0.16, transparent: true, opacity: 1 });
    mat.onBeforeCompile = (shader) => {
      shader.uniforms.time = uniforms.time;
      shader.uniforms.upperLimit = uniforms.upperLimit;
      shader.uniforms.upperRatio = uniforms.upperRatio;
      shader.uniforms.spiralRadius = uniforms.spiralRadius;
      shader.uniforms.spiralTurns = uniforms.spiralTurns;
      shader.uniforms.tex2026 = uniforms.tex2026;
      shader.uniforms.azimuth = uniforms.azimuth;
      shader.uniforms.uYear = uniforms.uYear;

      shader.vertexShader = `
      uniform float time;
      uniform float upperLimit;
      uniform float upperRatio;
      uniform float spiralRadius;
      uniform float spiralTurns;
      uniform sampler2D tex2026;
      uniform float azimuth;
      uniform float uYear;
      attribute float delay;
      attribute vec2 speed;
      varying float vRatio;
      varying vec2 vSpeed;
      varying float vIsEffect;
      mat2 rot( float a){ return mat2(cos(a), -sin(a), sin(a), cos(a)); }
      ` + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace(
        `#include <begin_vertex>`,
        `#include <begin_vertex>
        float t = time + delay;
        t = t < 0. ? 0. : t;
        float h = mod(speed.y * t, upperLimit);
        float hRatio = clamp(h / upperLimit, 0., 1.);
        vRatio = hRatio; vSpeed = speed;
        transformed.y = h;
        float a = atan(position.x, position.z);
        a += speed.x * t;
        float initLength = length(position.xz);
        float finalLength = initLength * upperRatio;
        float ratio = mix(initLength, finalLength, hRatio);
        transformed.x = cos(a) * ratio;
        transformed.z = sin(a) * -ratio;
        float sTurns = sin(time * 0.5) * 0.5 + spiralTurns;
        float spiralA = hRatio * sTurns * PI * 2.;
        float sRadius = mix(spiralRadius, 0., hRatio);
        transformed.x += cos(spiralA) * sRadius;
        transformed.z += sin(spiralA) * -sRadius;
        vec3 efcPos = vec3(0, 6, 0.5);
        vec3 efcClamp = vec3(1., 0.75, 0.25) * 3.5;
        vec3 efcMin = efcPos - efcClamp;
        vec3 efcMax = efcPos + efcClamp;
        vec3 UVTransformed = vec3(transformed);
        UVTransformed.xz *= rot(azimuth);
        vec3 efcUV = (UVTransformed - efcMin) / (efcMax - efcMin);
        float isEffect = texture2D(tex2026, efcUV.xy).r;
        isEffect *= (efcUV.z > 0. && efcUV.z < 1.) ? 1. : 0.;
        isEffect *= uYear;
        vIsEffect = isEffect;
        `
      );
      shader.vertexShader = shader.vertexShader.replace(
        `gl_PointSize = size;`,
        `bool cond = floor(speed.y + 0.5) == 0.;
        gl_PointSize = size * ( cond ? 0.75 : ((1. - hRatio) * (smoothstep(0., 0.01, hRatio) * 0.25) + 0.75));
        gl_PointSize = mix(gl_PointSize, size * 2.2, isEffect);
        `
      );
      shader.fragmentShader = `
      uniform float time;
      uniform float uReveal;
      varying float vRatio;
      varying vec2 vSpeed;
      varying float vIsEffect;
      mat2 rot( float a){ return mat2(cos(a), -sin(a), sin(a), cos(a)); }
      ` + shader.fragmentShader;
      shader.fragmentShader = shader.fragmentShader.replace(
        `#include <clipping_planes_fragment>`,
        `
        if (vRatio == 1.) discard;
        if (uReveal < 0.01) discard;
        vec2 uv = gl_PointCoord - 0.5;
        float a = (time * vSpeed.x + vSpeed.x) * 10.;
        uv *= rot(a);
        uv.y *= floor(a + 0.5) == 0. ? 1.25 : 2. + sin(a * PI);
        if (length(uv) > 0.5) discard;
        #include <clipping_planes_fragment>`
      );
      shader.fragmentShader = shader.fragmentShader.replace(
        `vec4 diffuseColor = vec4( diffuse, opacity );`,
        `
          /* sakura pink body — only the "2026" year petals turn gold */
          vec3 col = vec3(1.0, 0.72, 0.82);
          float d = clamp(uv.x + .5, 0., 1.);
          vec3 base = mix(diffuse, col, pow(d, 2.)) * uReveal * 0.85;
          vec4 diffuseColor = vec4(mix(base, vec3(1.0, 0.82, 0.45), vIsEffect * uReveal), 1.);
        `
      );
    };
    petals = new THREE.Points(g, mat);
    petals.renderOrder = 2;
    scene.add(petals);
  }

  /* ---------- fireflies: warm motes drifting around the canopy ---------- */
  function buildFireflies() {
    const pts = [], phases = [], sizes = [];
    for (let i = 0; i < FIREFLIES; i++) {
      const r = randFloat(2, 7.5), a = randFloat(0, Math.PI * 2);
      pts.push(new THREE.Vector3(Math.cos(a) * r, randFloat(2, 15), Math.sin(a) * r));
      phases.push(Math.random());
      sizes.push(randFloat(1.2, 2.4));
    }
    const g = new THREE.BufferGeometry().setFromPoints(pts);
    g.setAttribute("aPhase", new THREE.Float32BufferAttribute(phases, 1));
    g.setAttribute("aSize", new THREE.Float32BufferAttribute(sizes, 1));
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: uTimeCanopy, uReveal: uRevealCanopy },
      vertexShader: `
        uniform float uTime; attribute float aPhase; attribute float aSize;
        varying float vA;
        void main(){
          vec3 p = position;
          float ph = aPhase * 6.2831;
          p.x += sin(uTime * 0.5 + ph) * 0.9;
          p.y += sin(uTime * 0.34 + ph * 1.6) * 0.7;
          p.z += cos(uTime * 0.42 + ph * 0.8) * 0.9;
          vA = 0.35 + 0.65 * (0.5 + 0.5 * sin(uTime * 1.6 + ph * 4.0));
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = aSize * (170.0 / max(1.0, -mv.z));
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        uniform float uReveal; varying float vA;
        void main(){
          vec2 uv = gl_PointCoord - 0.5;
          float a = smoothstep(0.5, 0.05, length(uv)) * vA * uReveal * 0.75;
          if (a < 0.01) discard;
          gl_FragColor = vec4(1.0, 0.85, 0.58, a);
        }`
    });
    fireflies = new THREE.Points(g, mat);
    fireflies.renderOrder = 3;
    scene.add(fireflies);
  }

  /* ---------- the warm moon behind the crown (divine backlight) ---------- */
  function buildMoon() {
    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: uTimeCanopy, uReveal: uRevealCanopy },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `
        uniform float uReveal; uniform float uTime; varying vec2 vUv;
        void main(){
          float d = length(vUv - 0.5) * 2.0;
          float disc = smoothstep(0.46, 0.38, d);
          float glow = smoothstep(1.0, 0.1, d);
          float pulse = 0.88 + 0.12 * sin(uTime * 0.3);
          float a = (disc * 0.55 + glow * 0.34) * uReveal * pulse;
          vec3 col = mix(vec3(1.0, 0.86, 0.62), vec3(1.0, 0.95, 0.84), disc);
          gl_FragColor = vec4(col, a);
        }`
    });
    moon = new THREE.Mesh(new THREE.PlaneGeometry(15, 15), mat);
    moon.position.set(0, 11.6, -9);
    moon.renderOrder = -1;
    scene.add(moon);
  }

  /* ---------- divine light: three soft beams + a halo ---------- */
  function buildRays() {
    rays = new THREE.Group();
    const beamGeo = new THREE.PlaneGeometry(3.2, 26);
    for (let i = 0; i < 3; i++) {
      const mat = new THREE.ShaderMaterial({
        transparent: true, depthWrite: false, side: THREE.DoubleSide,
        blending: THREE.AdditiveBlending,
        uniforms: { uTime: uTimeCanopy, uOn: { value: 0 }, uSeed: { value: i * 2.13 } },
        vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
        fragmentShader: `
          uniform float uTime; uniform float uSeed; uniform float uOn; varying vec2 vUv;
          void main(){
            float vert = pow(vUv.y, 2.0);
            float horiz = smoothstep(0.0, 0.5, vUv.x) * smoothstep(1.0, 0.5, vUv.x);
            float pulse = 0.62 + 0.38 * sin(uTime * 0.32 + uSeed);
            float a = vert * horiz * pulse * uOn * 0.16;
            gl_FragColor = vec4(1.0, 0.89, 0.64, a);
          }`
      });
      rayMats.push(mat);
      const m = new THREE.Mesh(beamGeo, mat);
      const az = i * 2.2 + 0.7;
      m.position.set(Math.sin(az) * 2.0, 13.2, Math.cos(az) * 2.0);
      m.rotation.y = az + Math.PI / 2;
      m.rotation.z = (i - 1) * 0.045;
      m.renderOrder = 4;
      rays.add(m);
    }
    scene.add(rays);

    const haloMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uOn: { value: 0 }, uTime: uTimeCanopy, uSeed: { value: 9.4 } },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `
        uniform float uOn; uniform float uTime; uniform float uSeed; varying vec2 vUv;
        void main(){
          float d = length(vUv - 0.5) * 2.0;
          float pulse = 0.72 + 0.28 * sin(uTime * 0.4 + uSeed);
          float a = smoothstep(1.0, 0.05, d) * uOn * 0.46 * pulse;
          gl_FragColor = vec4(1.0, 0.9, 0.68, a);
        }`
    });
    rayMats.push(haloMat);
    halo = new THREE.Mesh(new THREE.PlaneGeometry(34, 34), haloMat);
    halo.position.set(0, 12.5, 0);
    halo.renderOrder = 4;
    scene.add(halo);
  }

  /* ---------- the ground: a warm pool + the fallen-sakura carpet ---------- */
  function buildBase() {
    const geom = new THREE.CircleGeometry(7.5, 64);
    geom.rotateX(-Math.PI * 0.5);
    const mat = new THREE.MeshBasicMaterial({ color: 0x6b4a52 });
    mat.defines = { "USE_UV": "" };
    mat.onBeforeCompile = (shader) => {
      shader.fragmentShader = shader.fragmentShader.replace(
        `#include <opaque_fragment>`,
        `
          vec3 col = vec3(0.075, 0.05, 0.10);
          vec2 uv = vUv - 0.5;
          uv *= 2.;
          col = mix(outgoingLight, col, length(uv));
          gl_FragColor = vec4(col, diffuseColor.a);
        `
      );
    };
    base = new THREE.Mesh(geom, mat);
    base.position.y = -0.02;
    scene.add(base);

    /* the fallen-sakura carpet: pink glow ring around the trunk base */
    const cGeom = new THREE.CircleGeometry(6.2, 64);
    cGeom.rotateX(-Math.PI * 0.5);
    const cMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uReveal: uRevealCanopy, uTime: uTimeCanopy },
      vertexShader: `varying vec2 vUv; void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }`,
      fragmentShader: `
        uniform float uReveal; uniform float uTime; varying vec2 vUv;
        void main(){
          float d = length(vUv - 0.5) * 2.0;
          float ring = smoothstep(1.0, 0.18, d) * (0.32 + 0.24 * smoothstep(0.85, 0.25, d));
          float petalN = sin(vUv.x * 42.0 + uTime * 0.2) * sin(vUv.y * 38.0 - uTime * 0.15);
          float a = ring * (0.42 + 0.12 * petalN) * uReveal;
          vec3 col = mix(vec3(0.86, 0.36, 0.52), vec3(1.0, 0.72, 0.82), smoothstep(1.0, 0.2, d));
          gl_FragColor = vec4(col, a);
        }`
    });
    carpet = new THREE.Mesh(cGeom, cMat);
    carpet.position.y = 0.02;
    carpet.renderOrder = 1;
    scene.add(carpet);
  }

  /* ---------- camera: scroll drives the orbit ----------
     The WHOLE tree stays in frame the entire time (16-unit tree,
     55° fov → lens stays ≥ ~16 units out, look-point at mid-tree). */
  function updateCamera() {
    const p = smooth(clamp01(M.progress));
    const drift = reduce ? 0 : clockT * 0.04;
    const az = lerp(-2.4, 0.95, p) + drift + ptr.x * 0.25;
    let radius = lerp(18.5, 15.6, p);
    if (camera.aspect < 0.75) radius *= 1.16;
    const h = lerp(5.2, 6.8, p) + ptr.y * 0.7;
    camera.position.set(Math.sin(az) * radius, h, Math.cos(az) * radius);
    camera.lookAt(0, lerp(7.4, 7.9, p), 0);
    if (halo) halo.quaternion.copy(camera.quaternion);
    if (moon) moon.quaternion.copy(camera.quaternion);
    uniforms.azimuth.value = az;
  }

  function renderFrame(dt) {
    clockT += dt * (reduce ? 0.18 : 0.5);
    uTimeCanopy.value = clockT;
    uniformsTree.time.value = clockT * 5;
    uniforms.time.value = clockT;
    ptr.x += (ptr.tx - ptr.x) * 0.05;
    ptr.y += (ptr.ty - ptr.y) * 0.05;
    wind += ((reduce ? 0 : uWind.value) - wind) * 0.05;
    uWind.value = wind;
    if (swingGrp) swingGrp.rotation.z = Math.sin(clockT * 0.5) * (0.06 + wind * 0.10);
    if (lantern) {
      lantern.material.opacity = 0.75 + 0.25 * Math.sin(clockT * 2.2) * Math.sin(clockT * 0.7 + 1.4);
      lantern.scale.setScalar(1.9 + 0.12 * Math.sin(clockT * 1.8));
    }
    updateCamera();
    /* keep-fresh clear: some GPUs composite a stale alpha canvas black */
    if (renderer) {
      renderer.setClearColor(0x000000, 0);
      renderer.clear();
    }
    renderer.render(scene, camera);
  }

  function loop(now) {
    requestAnimationFrame(loop);
    if (!M.active || !M.ready || !renderer) return;
    const dt = lastFrame ? Math.min((now - lastFrame) / 1000, 0.05) : 0.016;
    lastFrame = now;
    renderFrame(dt);
  }

  /* ---------- public API ---------- */
  function mount(el) {
    if (M.failed) return false;
    if (M.mounted) return true;
    canvas = el;
    if (!canvas) return false;
    try {
      renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: true, preserveDrawingBuffer: true });
      renderer.setClearColor(0x000000, 0);
    } catch (e) {
      console.warn("[blossom] WebGL unavailable:", e);
      M.failed = true;
      return false;
    }
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, mobile ? 1.5 : 1.75));
    scene = new THREE.Scene();
    camera = new THREE.PerspectiveCamera(55, 1, 0.1, 100);
    camera.position.set(0, 5, 10);

    uniforms.tex2026.value = makeYearTexture();
    buildBase();
    buildPetals();
    buildFireflies();
    buildMoon();
    buildRays();

    fetch("assets/models/tree.obj")
      .then(r => { if (!r.ok) throw new Error("tree.obj " + r.status); return r.text(); })
      .then(txt => {
        const { positions, indices } = parseOBJ(txt);
        buildTree(positions, indices);
      })
      .catch(() => {
        // procedural fallback: normalise the cloud, then cluster it
        const cloud = proceduralTree(CANOPY_CLUSTERS * 30);
        let minY = Infinity, maxY = -Infinity;
        cloud.forEach(p => { if (p.y < minY) minY = p.y; if (p.y > maxY) maxY = p.y; });
        const s = TREE_HEIGHT / Math.max(1e-6, maxY - minY);
        buildCanopyFromCloud(cloud, p => new THREE.Vector3(p.x * s, (p.y - minY) * s, p.z * s));
        buildSwing(); buildLantern();
      })
      .then(() => {
        M.ready = true;
        resize();
        renderFrame(0.016);
      });

    window.addEventListener("resize", () => { if (M.mounted) resize(); }, { passive: true });
    M.mounted = true;
    requestAnimationFrame(loop);
    return true;
  }

  function setProgress(p) {
    M.progress = clamp01(p);
    uniforms.uReveal.value = smooth(clamp01((M.progress - 0.04) / 0.24));
    uniforms.uYear.value = smooth(clamp01((M.progress - 0.40) / 0.18));
    uRevealCanopy.value = smooth(clamp01((M.progress - 0.02) / 0.20));
    /* growth: the tree rises from a sapling over the first half of the orbit */
    uGrow.value = Math.max(smooth(clamp01((M.progress - 0.02) / 0.48)), 0.06);
    const raysOn = smooth(clamp01((M.progress - 0.06) / 0.22));
    rayMats.forEach(m => { m.uniforms.uOn.value = raysOn; });
  }

  function setActive(b) { M.active = !!b; if (b) lastFrame = 0; }
  function setPointer(x, y) { ptr.tx = x; ptr.ty = y; }
  function setWind(v) { uWind.value = clamp01(Math.abs(v)); }
  function resize() {
    if (!renderer || !canvas) return;
    const wd = canvas.clientWidth || 1, ht = canvas.clientHeight || 1;
    renderer.setSize(wd, ht, false);
    camera.aspect = wd / ht;
    camera.updateProjectionMatrix();
  }

  w.Blossom = {
    mount, setProgress, setActive, setPointer, setWind, resize,
    get ready() { return M.ready; },
    get failed() { return M.failed; },
    get stats() {
      let frame = null;
      if (camera && treeMesh) {
        const a = new THREE.Vector3(0, 0, 0).project(camera);
        const b = new THREE.Vector3(0, TREE_HEIGHT, 0).project(camera);
        frame = {
          topY: +b.y.toFixed(3), bottomY: +a.y.toFixed(3),
          coverage: +(Math.abs(b.y - a.y) / 2).toFixed(3),
          inFrame: b.y <= 1 && a.y >= -1 && Math.abs(b.x) <= 1
        };
      }
      return {
        canopy: canopy ? canopy.geometry.attributes.position.count : 0,
        trunk: !!treeMesh,
        petals: petals ? petals.geometry.attributes.position.count : 0,
        progress: +M.progress.toFixed(3),
        grow: +uGrow.value.toFixed(3),
        frame
      };
    }
  };
  try { w.dispatchEvent(new Event("blossom:ready")); } catch (e) {}
})(window);
