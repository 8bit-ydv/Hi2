/* Entry point for the 3D house module (kept tiny on purpose). */
import { mountHouse } from "./house/index.js";

/* ---------------------------------------------------------------------
   V15 QA — repair trigger positions after every global refresh.

   The house module mounts AFTER the other scenes, so every ScrollTrigger
   created before it (the finale's star simulation, its once-animations,
   the floor indicator, …) was measured against a layout that did not yet
   include the house's 11,200 px pin spacer. A plain ScrollTrigger.refresh()
   does NOT repair them: a global refresh re-initialises triggers in start
   order while the pin spacers are still being rebuilt, so triggers that
   live after the house re-read the pre-spacer layout and keep their stale
   numbers. Runtime effect: the finale's star-sim pinned itself over the
   house intro (constellation over the captions) and the finale's
   animations all fired early, leaving the ending static and empty.

   Fix: after every global refresh, re-measure each trigger individually,
   in document order (so every earlier pin spacer is in place before the
   next trigger reads its element).
   --------------------------------------------------------------------- */
function repairTriggerPositions() {
  const sts = ScrollTrigger.getAll()
    .filter(t => t.trigger && t.trigger.getBoundingClientRect)
    .sort((a, b) => {
      const ay = a.trigger.getBoundingClientRect().top + scrollY;
      const by = b.trigger.getBoundingClientRect().top + scrollY;
      return ay - by;
    });
  sts.forEach(t => t.refresh());
}
ScrollTrigger.addEventListener("refresh", repairTriggerPositions);

function boot() {
  try { window.__house = mountHouse(); }
  catch (e) { console.warn("[house] failed to mount:", e); }
  if (window.ScrollTrigger) ScrollTrigger.refresh();
}
if (window.__bdayReady) boot();
else window.addEventListener("bday:ready", boot, { once: true });
