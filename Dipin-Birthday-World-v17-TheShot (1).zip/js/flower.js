/* =============================================================
   THE GARDEN — chapter 1 of scene ii

   Three flowers grow and open on the night — a big one in the
   centre and two smaller companions — with grass swaying, seeds
   drifting in before they plant themselves, a moon and low mist,
   butterflies that find the blooms, dew that falls as the petals
   open, and warm lights rising. The centre bud is visible almost
   immediately, so the chapter never starts on an empty screen.

   Scroll-scrubbed via setProgress(0..1); setWind() lets scroll
   velocity drive the sway.
   ============================================================ */
(function (w) {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  let canvas = null, ctx = null;
  let W = 0, H = 0, dpr = 1;
  let progress = 0, time = 0, lastT = 0, active = false, wind = 0;
  const M = { mounted: false };

  const clamp01 = v => Math.max(0, Math.min(1, v));
  const smooth = t => t * t * (3 - 2 * t);
  const sstep = (a, b, t) => smooth(clamp01((t - a) / (b - a)));
  const lerp = (a, b, t) => a + (b - a) * t;
  const rand = (a, b) => a + Math.random() * (b - a);

  /* the three blooms: the big one first, companions join later */
  const FLOWERS = [
    { ox: 0.00, oy: 0.00, s: 1.00, start: 0.00, nO: 8, nI: 6, tilt: 0 },
    { ox: -0.27, oy: 0.085, s: 0.60, start: 0.20, nO: 7, nI: 5, tilt: -0.10 },
    { ox: 0.25, oy: 0.125, s: 0.48, start: 0.34, nO: 6, nI: 4, tilt: 0.12 }
  ];
  FLOWERS.forEach(f => {
    f.petalsO = Array.from({ length: f.nO }, (_, i) => ({
      ang: (i / f.nO) * Math.PI * 2 + rand(-0.08, 0.08),
      len: rand(0.92, 1.08), wid: rand(0.80, 0.96), d: i * 0.02
    }));
    f.petalsI = Array.from({ length: f.nI }, (_, i) => ({
      ang: (i / f.nI) * Math.PI * 2 + 0.4 + rand(-0.08, 0.08),
      len: rand(0.52, 0.64), wid: rand(0.72, 0.88), d: i * 0.018
    }));
    f.ph = rand(0, 6.28);
  });

  const GRASS = Array.from({ length: 18 }, (_, i) => ({
    x: (i + 0.5) / 18 + rand(-0.02, 0.02),
    h: rand(0.05, 0.115), lean: rand(-0.35, 0.35),
    ph: rand(0, 6.28), w: rand(0.5, 1)
  }));
  const LIGHTS = Array.from({ length: 11 }, () => ({
    ox: rand(-0.42, 0.42), oy: rand(-0.16, 0.1),
    sp: rand(0.16, 0.38), ph: rand(0, 6.28), sz: rand(1.3, 2.6)
  }));
  /* seeds drift in on the night breeze before the garden begins */
  const SEEDS = Array.from({ length: 5 }, (_, i) => ({
    x: rand(0.1, 0.9), y0: rand(-0.25, -0.05), sp: rand(0.35, 0.6),
    amp: rand(10, 26), ph: rand(0, 6.28), d: i * 0.018
  }));
  /* two butterflies find the garden */
  const FLIES = [
    { ox: -0.16, oy: -0.05, sp: 0.5, ph: rand(0, 6.28), hue: "#f2b263", sz: 1.0 },
    { ox: 0.14, oy: -0.10, sp: 0.38, ph: rand(0, 6.28), hue: "#e88aa0", sz: 0.8 }
  ];
  /* dew waits on the open petals, then falls */
  const DEW = Array.from({ length: 3 }, (_, i) => ({
    ang: rand(0, Math.PI * 2), d: i * 0.05
  }));

  function resize() {
    if (!canvas) return;
    dpr = Math.min(window.devicePixelRatio || 1, 2);
    W = canvas.clientWidth || 1; H = canvas.clientHeight || 1;
    canvas.width = Math.round(W * dpr); canvas.height = Math.round(H * dpr);
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    if (!active) draw(progress, 1);
  }

  /* ---------- backdrop: a soft moon + low mist ---------- */
  function drawSky(p, t) {
    /* moon, upper right, breathes gently */
    const moonA = sstep(0.0, 0.2, p) * (reduce ? 1 : 0.92 + 0.08 * Math.sin(t * 0.3));
    if (moonA > 0.01) {
      const mx = W * 0.78, my = H * 0.16, mr = Math.min(W, H) * 0.07;
      let g = ctx.createRadialGradient(mx, my, 0, mx, my, mr * 3.4);
      g.addColorStop(0, `rgba(255,240,214,${0.30 * moonA})`);
      g.addColorStop(1, "rgba(255,240,214,0)");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(mx, my, mr * 3.4, 0, Math.PI * 2); ctx.fill();
      g = ctx.createRadialGradient(mx - mr * 0.3, my - mr * 0.3, mr * 0.1, mx, my, mr);
      g.addColorStop(0, `rgba(255,248,230,${0.95 * moonA})`);
      g.addColorStop(0.75, `rgba(255,232,196,${0.85 * moonA})`);
      g.addColorStop(1, `rgba(255,220,170,${0.5 * moonA})`);
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(mx, my, mr, 0, Math.PI * 2); ctx.fill();
    }
    /* two slow mist bands near the ground */
    const mistA = sstep(0.06, 0.4, p) * 0.5;
    if (mistA > 0.01) {
      for (let i = 0; i < 2; i++) {
        const yb = H * (0.86 + i * 0.05);
        const drift = reduce ? 0 : Math.sin(t * (0.1 + i * 0.06) + i * 2) * W * 0.04;
        const g = ctx.createLinearGradient(0, yb - H * 0.06, 0, yb + H * 0.07);
        g.addColorStop(0, "rgba(210,190,220,0)");
        g.addColorStop(0.5, `rgba(210,190,220,${(i ? 0.05 : 0.08) * mistA})`);
        g.addColorStop(1, "rgba(210,190,220,0)");
        ctx.fillStyle = g;
        ctx.fillRect(-W * 0.1 + drift, yb - H * 0.06, W * 1.2, H * 0.13);
      }
    }
  }

  /* ---------- seeds drift in and plant themselves ---------- */
  function drawSeeds(p, t) {
    const on = sstep(0.0, 0.05, p) * (1 - sstep(0.16, 0.26, p));
    if (on <= 0.01) return;
    SEEDS.forEach(s => {
      const lp = clamp01((p - s.d) / 0.2);
      if (lp <= 0 || lp >= 1) return;
      const x = W * s.x + Math.sin(t * 1.1 + s.ph) * s.amp;
      const y = lerp(H * (0.2 + s.y0 * -1), H * 0.9, smooth(lp));
      const a = Math.sin(lp * Math.PI) * on;
      ctx.save();
      ctx.translate(x, y);
      ctx.rotate(Math.sin(t * 2 + s.ph) * 0.6);
      ctx.fillStyle = `rgba(240,220,180,${a})`;
      ctx.beginPath(); ctx.ellipse(0, 0, 3.2, 2.1, 0, 0, Math.PI * 2); ctx.fill();
      /* the tuft */
      ctx.strokeStyle = `rgba(240,220,180,${a * 0.7})`;
      ctx.lineWidth = 1;
      for (let k = -1; k <= 1; k++) {
        ctx.beginPath(); ctx.moveTo(0, -2);
        ctx.lineTo(k * 3, -7); ctx.stroke();
      }
      ctx.restore();
    });
  }

  /* one flower: stem → bud → open petals → golden core */
  function drawFlower(f, p, t) {
    const lp = clamp01((p - f.start) / (0.66 - f.start));
    if (lp <= 0.001) return null;

    const R = Math.max(46, Math.min(W, H) * 0.135) * f.s;
    const bx = W * (0.5 + f.ox), by = H * 0.94;
    const swayA = reduce ? 0 : (1 + wind * 2.2);
    const sway = Math.sin(t * 0.7 + f.ph) * R * 0.05 * swayA;
    const hx = bx + f.tilt * R * 2.4 + sway, hy = H * (0.40 + f.oy);

    /* stem (quick — it should be up early) */
    const grow = sstep(0, 0.26, lp);
    if (grow > 0.001) {
      const segs = 22, upto = Math.max(1, Math.round(segs * grow));
      ctx.save();
      ctx.lineCap = "round";
      for (let i = 0; i < upto; i++) {
        const s0 = i / segs, s1 = (i + 1) / segs;
        const a = { x: lerp(bx, hx, s0), y: lerp(by, hy, s0 * s0) };
        const b = { x: lerp(bx, hx, s1), y: lerp(by, hy, s1 * s1) };
        const tt = s0;
        ctx.strokeStyle = `rgba(${Math.round(lerp(128, 176, tt))},${Math.round(lerp(94, 130, tt))},${Math.round(lerp(64, 92, tt))},0.92)`;
        ctx.lineWidth = Math.max(1.2, lerp(R * 0.06, R * 0.02, tt));
        ctx.beginPath(); ctx.moveTo(a.x, a.y); ctx.lineTo(b.x, b.y); ctx.stroke();
      }
      ctx.restore();
      /* two small leaves on the stem */
      [[0.3, -1], [0.55, 1]].forEach(([s, side]) => {
        const lg = sstep(0.14, 0.3, lp);
        if (lg <= 0.001) return;
        const at = { x: lerp(bx, hx, s), y: lerp(by, hy, s * s) };
        const L = R * 0.5 * lg, Wd = R * 0.15 * lg;
        ctx.save();
        ctx.translate(at.x, at.y);
        ctx.rotate(side < 0 ? Math.PI * 0.86 : Math.PI * 0.14);
        const g = ctx.createLinearGradient(0, 0, L, 0);
        g.addColorStop(0, "#a97e4f"); g.addColorStop(1, "#d9b278");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.bezierCurveTo(L * 0.3, -Wd, L * 0.75, -Wd * 0.8, L, 0);
        ctx.bezierCurveTo(L * 0.75, Wd * 0.8, L * 0.3, Wd, 0, 0);
        ctx.fill();
        ctx.restore();
      });
    }

    /* the bud — visible early, before any petal opens */
    const bud = sstep(0.10, 0.24, lp);
    const open = sstep(0.22, 0.58, lp);
    const halo = sstep(0.2, 0.6, lp);

    if (halo > 0.01) {
      const breathe = reduce ? 1 : 1 + Math.sin(t * 0.9 + f.ph) * 0.045;
      const hr = R * 2.5 * breathe;
      const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, hr);
      g.addColorStop(0, `rgba(255,206,150,${0.20 * halo})`);
      g.addColorStop(0.5, `rgba(255,170,130,${0.08 * halo})`);
      g.addColorStop(1, "rgba(255,170,130,0)");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(hx, hy, hr, 0, Math.PI * 2); ctx.fill();
    }
    if (bud > 0.001 && open < 0.985) {
      const br = R * 0.24 * (bud - open * 0.5);
      if (br > 0.5) {
        const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, br);
        g.addColorStop(0, `rgba(232,110,140,${0.95 * bud})`);
        g.addColorStop(1, "rgba(180,60,100,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(hx, hy, br, 0, Math.PI * 2); ctx.fill();
      }
    }

    /* petals: closed nubs → full fan */
    const petal = (ang, o, len, wid, cBase, cTip) => {
      const L = R * len * (0.24 + 0.76 * o);
      const Wd = R * 0.30 * wid * (0.35 + 0.65 * o);
      const a = lerp(-Math.PI / 2 + Math.sin(ang) * 0.15, ang, smooth(o));
      ctx.save();
      ctx.translate(hx, hy);
      ctx.rotate(a + (reduce ? 0 : Math.sin(t * 0.8 + f.ph + ang) * 0.03 * swayA));
      const g = ctx.createLinearGradient(0, 0, L, 0);
      g.addColorStop(0, cBase); g.addColorStop(1, cTip);
      ctx.fillStyle = g;
      ctx.shadowColor = "rgba(255,190,140,.30)";
      ctx.shadowBlur = 10;
      ctx.beginPath();
      ctx.moveTo(0, 0);
      ctx.bezierCurveTo(L * 0.22, -Wd, L * 0.78, -Wd * 0.86, L, -R * 0.02);
      ctx.bezierCurveTo(L * 0.78, Wd * 0.86, L * 0.22, Wd, 0, 0);
      ctx.fill();
      ctx.restore();
    };
    f.petalsO.forEach(pt => {
      const o = sstep(0.22 + pt.d, 0.5 + pt.d, lp);
      if (o > 0.001) petal(pt.ang, o, pt.len, pt.wid, "#d95f7e", "#ffd9ae");
    });
    f.petalsI.forEach(pt => {
      const o = sstep(0.34 + pt.d, 0.6 + pt.d, lp);
      if (o > 0.001) petal(pt.ang, o, pt.len, pt.wid, "#f2926e", "#fff3dc");
    });

    /* the golden core */
    const core = sstep(0.5, 0.72, lp);
    if (core > 0.01) {
      const cr = R * 0.3 * core;
      const g = ctx.createRadialGradient(hx, hy, 0, hx, hy, cr * 2.1);
      g.addColorStop(0, `rgba(255,246,222,${0.95 * core})`);
      g.addColorStop(0.45, `rgba(243,201,139,${0.85 * core})`);
      g.addColorStop(1, "rgba(243,201,139,0)");
      ctx.fillStyle = g;
      ctx.beginPath(); ctx.arc(hx, hy, cr * 2.1, 0, Math.PI * 2); ctx.fill();
    }
    return { hx, hy, R, open };
  }

  /* ---------- butterflies wander between the blooms ---------- */
  function drawButterflies(p, t) {
    const on = sstep(0.38, 0.55, p) * (1 - sstep(0.8, 0.95, p));
    if (on <= 0.01 || reduce) return;
    const cx = W * 0.5, cy = H * 0.42;
    FLIES.forEach(b => {
      const tt = t * b.sp + b.ph;
      const x = cx + W * b.ox + Math.sin(tt * 1.3) * W * 0.10 + Math.sin(tt * 0.37) * W * 0.06;
      const y = cy + H * b.oy + Math.cos(tt * 1.7) * H * 0.07 + Math.sin(tt * 0.53) * H * 0.05;
      const flap = Math.abs(Math.sin(tt * 9));
      const dir = Math.cos(tt * 1.3) >= 0 ? 1 : -1;
      const s = 13 * b.sz;
      ctx.save();
      ctx.translate(x, y);
      ctx.scale(dir, 1);
      ctx.globalAlpha = on * (0.75 + 0.25 * Math.sin(tt * 2));
      /* wings */
      ctx.fillStyle = b.hue;
      ctx.globalAlpha *= 0.9;
      ctx.beginPath(); ctx.ellipse(-s * 0.45, 0, s * 0.5 * (0.25 + 0.75 * flap), s * 0.62, -0.5, 0, Math.PI * 2); ctx.fill();
      ctx.beginPath(); ctx.ellipse(s * 0.45, 0, s * 0.5 * (0.25 + 0.75 * flap), s * 0.62, 0.5, 0, Math.PI * 2); ctx.fill();
      ctx.globalAlpha = on;
      /* body */
      ctx.fillStyle = "#4a2c18";
      ctx.beginPath(); ctx.ellipse(0, 0, s * 0.1, s * 0.5, 0, 0, Math.PI * 2); ctx.fill();
      ctx.restore();
    });
  }

  /* ---------- dew falls from the freshly opened petals ---------- */
  function drawDew(p, t) {
    if (reduce) return;
    const on = sstep(0.5, 0.58, p) * (1 - sstep(0.68, 0.78, p));
    if (on <= 0.01) return;
    const cx = W * 0.5, cy = H * 0.40;
    DEW.forEach((d, i) => {
      const lp = clamp01((p - 0.52 - d.d) / 0.14);
      if (lp <= 0 || lp >= 1) return;
      const ang = d.ang;
      const sx = cx + Math.cos(ang) * W * 0.05, sy = cy + Math.sin(ang) * H * 0.04;
      const fall = smooth(lp);
      const y = sy + fall * fall * H * 0.30;
      const a = Math.sin(lp * Math.PI) * on;
      ctx.fillStyle = `rgba(255,244,220,${a * 0.9})`;
      ctx.beginPath();
      ctx.ellipse(sx + Math.sin(t * 3 + i) * 2, y, 2.4, 3.4, 0, 0, Math.PI * 2);
      ctx.fill();
      /* a tiny ring when it lands */
      if (lp > 0.86) {
        const r = (lp - 0.86) / 0.14;
        ctx.strokeStyle = `rgba(255,244,220,${(1 - r) * a * 0.5})`;
        ctx.lineWidth = 1;
        ctx.beginPath(); ctx.ellipse(sx, sy + H * 0.30, 5 + r * 10, 2 + r * 3, 0, 0, Math.PI * 2); ctx.stroke();
      }
    });
  }

  function drawGrass(p, t) {
    const grow = sstep(0.02, 0.4, p);
    if (grow <= 0.001) return;
    const swayA = reduce ? 0 : (1 + wind * 2.6);
    ctx.save();
    ctx.lineCap = "round";
    GRASS.forEach(bl => {
      const h = H * bl.h * grow;
      if (h < 2) return;
      const x0 = W * bl.x, y0 = H * 0.955;
      const sway = Math.sin(t * 1.1 + bl.ph) * h * 0.12 * swayA;
      const tipX = x0 + bl.lean * h + sway, tipY = y0 - h;
      ctx.strokeStyle = `rgba(${Math.round(lerp(96, 132, grow))},${Math.round(lerp(78, 106, grow))},${Math.round(lerp(48, 66, grow))},0.55)`;
      ctx.lineWidth = Math.max(1, 2.2 * bl.w);
      ctx.beginPath();
      ctx.moveTo(x0, y0);
      ctx.quadraticCurveTo(x0 + bl.lean * h * 0.4, y0 - h * 0.55, tipX, tipY);
      ctx.stroke();
    });
    ctx.restore();
  }

  function draw(p, t) {
    ctx.clearRect(0, 0, W, H);
    drawSky(p, t);
    drawSeeds(p, t);
    drawGrass(p, t);

    /* small companions first, the big bloom on top */
    [FLOWERS[2], FLOWERS[1], FLOWERS[0]].forEach(f => drawFlower(f, p, t));

    drawButterflies(p, t);
    drawDew(p, t);

    /* warm lights drift up around the open blooms */
    const lit = sstep(0.4, 0.66, p);
    if (lit > 0.01 && !reduce) {
      LIGHTS.forEach(L => {
        const ph = (t * L.sp + L.ph) % 1;
        const lx = W * (0.5 + L.ox) + Math.sin(t * 0.4 + L.ph * 5) * 14;
        const ly = H * 0.46 - ph * H * 0.34;
        const a = Math.sin(ph * Math.PI) * lit * (0.5 + 0.5 * Math.sin(t * 2.1 + L.ph * 3));
        if (a <= 0.02) return;
        const g = ctx.createRadialGradient(lx, ly, 0, lx, ly, L.sz * 3.2);
        g.addColorStop(0, `rgba(255,238,200,${a})`);
        g.addColorStop(1, "rgba(255,220,160,0)");
        ctx.fillStyle = g;
        ctx.beginPath(); ctx.arc(lx, ly, L.sz * 3.2, 0, Math.PI * 2); ctx.fill();
      });
    }
  }

  function loop(now) {
    requestAnimationFrame(loop);
    if (!M.mounted) return;
    const dt = lastT ? Math.min((now - lastT) / 1000, 0.05) : 0.016;
    lastT = now;
    if (!active) return;
    time += dt;
    draw(progress, time);
  }

  function mount(el) {
    if (M.mounted) return true;
    canvas = el;
    if (!canvas || !canvas.getContext) return false;
    ctx = canvas.getContext("2d");
    if (!ctx) return false;
    M.mounted = true;
    resize();
    window.addEventListener("resize", () => { if (M.mounted) resize(); }, { passive: true });
    if (!reduce) requestAnimationFrame(loop);
    return true;
  }

  function setProgress(p) {
    progress = clamp01(p);
    if (reduce || !active) draw(progress, 1);
  }
  function setActive(b) { active = !!b; if (b) lastT = 0; }
  function setWind(v) { wind = clamp01(Math.abs(v)); }

  w.Flower = {
    mount, setProgress, setActive, setWind, resize,
    get ready() { return M.mounted; }
  };
})(window);
