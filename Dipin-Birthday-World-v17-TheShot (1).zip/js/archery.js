/* =============================================================
   ARCHERY — chapter 2 of scene ii: "the shot"

   A vertical Cupid shot, ported from the Interactive Birthday Gift
   and rebuilt for the night sky: the bow waits under a beating
   heart, the string is pulled (drag / Enter / Space / auto-fire),
   the arrow flies straight up, strikes — and the heart bursts.

   Cinematography (the 23-ideas pass):
     • a gold comet-trail follows the arrow
     • impact freeze — 220ms where everything holds its breath
     • the heart SPLITS in two halves that fall before the wash
     • a soft burst (hearts + one clean gold ring)
     • an ember bridge flies UP toward where the tree will stand
     • the whole sky takes one warm heartbeat (sky pulse)

   Exposes window.Shot = { arm, enter, autoFire, fire, reset,
   refreshRig, rig, fired, drawing }
   ============================================================ */
(function (w) {
  const $ = (id) => document.getElementById(id);
  const mobile = matchMedia("(max-width: 820px)").matches;
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;

  /* elements (all live inside #bwStage) */
  const stage = () => $("bwStage");
  const archery = () => $("bwArchery");
  const bow = () => $("bwBow");
  const arrow = () => $("bwArrow");
  const target = () => $("bwTarget");
  const targetHeart = () => $("bwHeart");
  const aim = () => $("bwAim");
  const strL = () => $("bwStrL");
  const strR = () => $("bwStrR");
  const serving = () => $("bwServing");
  const tip = () => $("bwTip");
  const eyebrow = () => $("bwEyebrow");
  const hint = () => $("bwHint");
  const wash = () => $("bwWash");
  const bloom = () => $("bwBloom");

  const rand = (a, b) => a + Math.random() * (b - a);
  const pick = (a) => a[(Math.random() * a.length) | 0];
  const clamp = (v, a, b) => (v < a ? a : v > b ? b : v);
  const clamp01 = (v) => (v < 0 ? 0 : v > 1 ? 1 : v);

  /* ---------- bow geometry (re-measured on resize) ----------
     The rig is anchored lower-center and aims STRAIGHT UP at the
     heart — the shot is vertical (the pull axis is (0, 1)). */
  let svgScale = 1, arrowBaseX = 0, arrowBaseY = 0, maxDraw = 120, curDraw = 0;
  let pullUX = 0, pullUY = 1;
  let gripPX = 0, gripPY = 0;
  const REST_NOCK = 96;
  const nockProxy = { val: REST_NOCK };
  let W = 0, H = 0;

  function applyNock() {
    const y = nockProxy.val;
    const a = strL(), b = strR(), s = serving();
    if (a) a.setAttribute("y2", y);
    if (b) b.setAttribute("y2", y);
    if (s) s.setAttribute("cy", y);
  }

  function measure() {
    const st = stage();
    if (!st) return;
    const r = st.getBoundingClientRect();
    W = r.width; H = r.height;
  }

  function refreshRig() {
    const ar = archery(); if (!ar) return;
    measure();
    /* heart sits at its layout centre (33% down, centred); the grip
       anchors at 50% width / 78% height — the shot is dead vertical. */
    gripPX = W * 0.5; gripPY = H * 0.78;
    pullUX = 0; pullUY = 1;

    nockProxy.val = REST_NOCK; applyNock();
    gsap.set(ar, { rotation: 0, scale: 1, x: 0, y: 0 });
    ar.style.left = "0px"; ar.style.top = "0px";
    const aw = arrow(); if (aw) gsap.set(aw, { x: 0, y: 0 });

    const aR = ar.getBoundingClientRect();
    const bR = bow().getBoundingClientRect();
    const sR = serving().getBoundingClientRect();
    const rR = aw.getBoundingClientRect();
    svgScale = bR.width / 460;
    const gripLX = (bR.left - aR.left) + 0.5 * bR.width;
    const gripLY = (bR.top - aR.top) + (240 / 300) * bR.height;
    const nockLX = (sR.left - aR.left) + 0.5 * sR.width;
    const nockLY = (sR.top - aR.top) + 0.5 * sR.height;
    arrowBaseX = nockLX - ((rR.left - aR.left) + 0.5 * rR.width);
    arrowBaseY = nockLY - ((rR.top - aR.top) + (205 / 220) * rR.height);

    ar.style.left = (gripPX - gripLX) + "px";
    ar.style.top = (gripPY - gripLY) + "px";
    gsap.set(ar, { transformOrigin: `${gripLX}px ${gripLY}px`, rotation: 0 });
    gsap.set(aw, { x: arrowBaseX, y: arrowBaseY });
    maxDraw = Math.min(bR.height * 0.72, H * 0.16, 132);
    curDraw = 0;
  }

  function setDraw(d) {
    curDraw = clamp(d, 0, maxDraw);
    const aw = arrow(); if (!aw) return;
    gsap.set(aw, { x: arrowBaseX, y: arrowBaseY + curDraw });
    nockProxy.val = REST_NOCK + curDraw / svgScale; applyNock();
    const am = aim(); if (am) gsap.set(am, { opacity: 0.55 * (curDraw / maxDraw) });
  }

  /* ---------- the heart's beat ---------- */
  let beatTL = null;
  function startBeat() {
    const th = targetHeart(), hg = document.querySelector("#bwTarget .heart__glow");
    if (!th) return;
    gsap.set(th, { scale: 1 });
    if (hg) gsap.set(hg, { scale: 1, opacity: 0.7 });
    beatTL = gsap.timeline({ repeat: -1, repeatDelay: 0.5 });
    beatTL.to(th, { scale: 1.07, duration: 0.13, ease: "power2.out" }, 0)
      .to(th, { scale: 1.0, duration: 0.2, ease: "power2.in" }, 0.13)
      .to(th, { scale: 1.05, duration: 0.12, ease: "power2.out" }, 0.3)
      .to(th, { scale: 1.0, duration: 0.5, ease: "power2.inOut" }, 0.42);
    if (hg) {
      beatTL.to(hg, { scale: 1.15, opacity: 0.9, duration: 0.13, ease: "power2.out" }, 0)
        .to(hg, { scale: 1.0, opacity: 0.7, duration: 0.7, ease: "power2.inOut" }, 0.3);
    }
  }
  function stopBeat() {
    if (beatTL) { beatTL.kill(); beatTL = null; }
    const th = targetHeart(); if (th) gsap.set(th, { scale: 1 });
  }

  /* ---------- bursts ---------- */
  function miniHeartSVG(fill) {
    return `<svg viewBox="0 0 24 22" width="100%" height="100%"><path d="M12 20C5.5 15 1.5 11.4 1.5 6.9 1.5 3.6 4 1.5 7 1.5c2 0 3.4 1.1 5 3 1.6-1.9 3-3 5-3 3 0 5.5 2.1 5.5 5.4C23.5 11.4 19.5 15 12 20Z" fill="${fill}"/></svg>`;
  }

  function burstHearts() {
    const st = stage(); if (!st) return;
    const t = target(); if (!t) return;
    const r = t.getBoundingClientRect(), hr = st.getBoundingClientRect();
    const ox = r.left - hr.left + r.width / 2;
    const oy = r.top - hr.top + r.height * 0.42;
    const cols = ["#ff6f97", "#ffb14e", "#ff8fae", "#ffd36a", "#e23b67"];
    const frag = document.createDocumentFragment();
    const nodes = [];
    /* soft: 6 hearts + 2 gold sparks + one clean gold ring */
    for (let i = 0; i < 8; i++) {
      const heart = i < 6;
      const el = document.createElement("span");
      el.className = "burst";
      const s = heart ? rand(12, 22) : rand(4, 8);
      el.style.cssText = `position:absolute;left:${ox}px;top:${oy}px;width:${s}px;height:${s}px;margin:${-s / 2}px 0 0 ${-s / 2}px;pointer-events:none;z-index:4;`;
      if (heart) el.innerHTML = miniHeartSVG(pick(cols));
      else { el.style.borderRadius = "50%"; el.style.background = "radial-gradient(circle,#fff,rgba(255,210,150,0) 70%)"; }
      frag.appendChild(el); nodes.push({ el, heart });
    }
    /* the gold ring */
    const ring = document.createElement("span");
    ring.className = "burst-ring";
    ring.style.cssText = `position:absolute;left:${ox}px;top:${oy}px;width:24px;height:24px;margin:-12px 0 0 -12px;border-radius:50%;border:2px solid rgba(255,214,150,.9);pointer-events:none;z-index:4;`;
    frag.appendChild(ring);
    st.appendChild(frag);
    gsap.to(ring, { scale: 9, opacity: 0, duration: 0.9, ease: "power2.out", onComplete: () => ring.remove() });
    nodes.forEach(({ el, heart }) => {
      const ang = rand(-Math.PI, 0);
      const dist = rand(heart ? 70 : 40, heart ? 190 : 120);
      gsap.to(el, {
        x: Math.cos(ang) * dist, y: Math.sin(ang) * dist - rand(10, 50),
        rotation: rand(-120, 120), scale: heart ? rand(0.7, 1.2) : rand(0.4, 1),
        duration: rand(0.7, 1.15), ease: "power2.out",
      });
      gsap.to(el, { opacity: 0, duration: 0.5, delay: rand(0.35, 0.6), ease: "power1.in", onComplete: () => el.remove() });
    });
  }

  /* heart splits in two — the halves fall away before the wash */
  function heartSplit() {
    const st = stage(); const th = targetHeart(); if (!st || !th) return;
    const r = th.getBoundingClientRect(), hr = st.getBoundingClientRect();
    const ox = r.left - hr.left + r.width / 2;
    const oy = r.top - hr.top + r.height / 2;
    gsap.set(th, { opacity: 0 });
    for (let side = -1; side <= 1; side += 2) {
      const half = document.createElement("span");
      half.className = "heart-half";
      half.style.cssText = `position:absolute;left:${ox}px;top:${oy}px;width:${r.width * 0.62}px;height:${r.height * 0.72}px;margin:${-r.height * 0.36}px 0 0 ${side < 0 ? -r.width * 0.62 : 0}px;pointer-events:none;z-index:4;overflow:hidden;`;
      half.innerHTML = `<span style="position:absolute;left:${side < 0 ? 0 : -r.width * 0.31}px;top:0;width:${r.width * 0.62}px;height:${r.height * 0.72}px;display:block;">` +
        `<svg viewBox="0 0 100 92" width="100%" height="100%"><path d="M50 88C22 68 4 50 4 30 4 14 16 4 30 4c9 0 16 5 20 12 4-7 11-12 20-12 14 0 26 10 26 26 0 20-18 38-46 58Z" fill="#e23b67"/></svg></span>`;
      st.appendChild(half);
      gsap.to(half, {
        x: side * rand(60, 110), y: rand(120, 200), rotation: side * rand(25, 55),
        opacity: 0, duration: rand(0.75, 1.0), ease: "power1.in", onComplete: () => half.remove()
      });
    }
  }

  /* the gold comet-trail behind the arrow */
  function spawnTrail(fromX, fromY, toX, toY, on) {
    const st = stage(); if (!st || !on) return;
    const n = 14;
    for (let i = 0; i < n; i++) {
      const t = i / n;
      const s = document.createElement("span");
      s.className = "arrow-trail";
      const sz = rand(3, 7) * (1 - t * 0.5);
      s.style.cssText = `position:absolute;left:${fromX + (toX - fromX) * t}px;top:${fromY + (toY - fromY) * t}px;width:${sz}px;height:${sz}px;margin:${-sz / 2}px 0 0 ${-sz / 2}px;border-radius:50%;background:radial-gradient(circle,rgba(255,224,160,.95),rgba(255,190,110,0) 70%);pointer-events:none;z-index:4;`;
      st.appendChild(s);
      gsap.to(s, {
        y: "+=" + rand(-18, 24), x: "+=" + rand(-16, 16), opacity: 0,
        duration: rand(0.5, 0.9), delay: (1 - t) * 0.22, ease: "power1.out",
        onComplete: () => s.remove()
      });
    }
  }

  /* the ember bridge: sparks rise toward where the tree will stand */
  function emberBridge() {
    const st = stage(); if (!st) return;
    for (let i = 0; i < 12; i++) {
      const e = document.createElement("span");
      e.className = "ember";
      const sz = rand(5, 11);
      e.style.cssText = `position:absolute;left:${W * 0.5 + rand(-W * 0.18, W * 0.18)}px;top:${H * 0.42 + rand(-40, 60)}px;width:${sz}px;height:${sz}px;border-radius:50%;background:radial-gradient(circle,rgba(255,214,140,1),rgba(255,170,90,0) 70%);pointer-events:none;z-index:5;`;
      st.appendChild(e);
      gsap.to(e, {
        y: -(H * rand(0.30, 0.52)), x: rand(-40, 40), scale: rand(0.4, 1),
        opacity: 0, duration: rand(1.2, 2.0), delay: rand(0, 0.55), ease: "power1.out",
        onComplete: () => e.remove()
      });
    }
  }

  /* the sky takes one warm heartbeat */
  function skyPulse() {
    const sky = document.getElementById("skyWarm") || document.getElementById("sky");
    if (!sky) return;
    gsap.fromTo(sky, { opacity: 0 }, {
      opacity: 0.42, duration: 0.22, ease: "power2.out", yoyo: true, repeat: 1,
      onComplete: () => gsap.set(sky, { opacity: 0 })
    });
  }

  /* ---------- the shot geometry ---------- */
  function shotGeom() {
    const tp = tip(), t = target();
    if (!tp || !t) return {
      arrowStartY: arrowBaseY + curDraw, arrowFlyY: arrowBaseY + curDraw - H * 0.4,
      drawnNock: REST_NOCK + curDraw / svgScale, fx: 0, fy: 0,
      floodScale: 12, bloomScale: 12
    };
    const tipR = tp.getBoundingClientRect();
    const tRect = t.getBoundingClientRect();
    const tipX = tipR.left + tipR.width / 2, tipY = tipR.top + tipR.height / 2;
    const tcx = tRect.left + tRect.width / 2, tcy = tRect.top + tRect.height / 2;
    const flightDist = Math.hypot(tcx - tipX, tcy - tipY);
    const fallPx = Math.min(H * 0.26, H - tcy - tRect.height * 0.4);
    const impactX = tcx, impactY = tcy + fallPx;
    const distC = Math.hypot(Math.max(impactX, W - impactX), Math.max(impactY, H - impactY));
    const reach = Math.hypot(W / 2, H / 2);
    return {
      arrowStartY: arrowBaseY + curDraw,
      arrowFlyY: arrowBaseY + curDraw - flightDist,
      drawnNock: REST_NOCK + curDraw / svgScale,
      fallPx, fx: impactX - W / 2, fy: impactY - H / 2,
      floodScale: (distC * 1.12) / 70, bloomScale: (reach * 1.2) / 30
    };
  }

  /* ---------- the film: shot → freeze → split → burst → washes → bloom ---------- */
  let filmTL = null;
  let cb = { onShot: null, onBloom: null };

  function buildFilm(m) {
    const tl = gsap.timeline({ paused: true });
    const th = target(), aw = arrow(), ar = archery();
    const wa = wash(), bl = bloom();

    tl.set(th, { y: 0, scaleX: 1, scaleY: 1, opacity: 1 })
      .set(aw, { opacity: 1, x: arrowBaseX, y: m.arrowStartY, scaleY: 1 })
      .set([wa, bl], { autoAlpha: 0, scale: 0.001, x: 0, y: 0 })
      .set(wa, { x: m.fx, y: m.fy })
      .set(ar, { opacity: 1 });

    /* the shot: string snaps, the arrow flies — with its gold comet-trail */
    tl.fromTo(nockProxy, { val: m.drawnNock }, {
      val: REST_NOCK, duration: 0.5, ease: "elastic.out(1,0.34)", onUpdate: applyNock
    }, 0)
      .to(aw, { y: m.arrowFlyY, duration: 0.26, ease: "power2.in" }, 0)
      .to(aw, { scaleY: 1.16, duration: 0.14, ease: "power2.in" }, 0)
      .to(aw, { scaleY: 1.0, duration: 0.1, ease: "power1.out" }, 0.16)
      .to(aim(), { opacity: 0, duration: 0.18 }, 0)
      .to([eyebrow(), hint()], { opacity: 0, duration: 0.2, ease: "power1.out" }, 0)
      .call(() => {
        if (cb.onShot) cb.onShot();
        const arR = ar.getBoundingClientRect(), stR = stage().getBoundingClientRect();
        spawnTrail(
          arR.left - stR.left + arrowBaseX, arR.top - stR.top + m.arrowStartY,
          arR.left - stR.left + arrowBaseX, arR.top - stR.top + m.arrowFlyY, !reduce);
      }, null, 0.02);

    /* the strike + THE FREEZE (220ms: the world holds its breath) */
    tl.to(th, { x: 7, y: -9, duration: 0.06, ease: "power2.out" }, 0.26)
      .to(th, { x: 0, y: 0, duration: 0.22, ease: "power2.out" }, 0.32)
      .to(th, { scale: 1.14, duration: 0.06, ease: "power2.out" }, 0.26)
      .to(th, { scale: 1.0, duration: 0.22, ease: "power2.inOut" }, 0.32)
      .to(aw, { rotation: "+=4", duration: 0.05, yoyo: true, repeat: 3, ease: "sine.inOut" }, 0.27)
      .set(aw, { rotation: 0 }, 0.52)
      /* (the 220ms freeze window runs 0.27 → 0.49 — the camera and
         stage simply hold; nothing new enters until the split) */

      /* the heart splits in two — the halves fall */
      .call(() => heartSplit(), null, 0.49)
      .to(aw, { opacity: 0, duration: 0.16, ease: "power1.out" }, 0.56)

      /* the soft burst + gold ring + sky pulse */
      .call(() => { burstHearts(); skyPulse(); }, null, 0.52)

      /* the fall + the washes flood */
      .to(th, { y: m.fallPx, scaleX: 0.84, scaleY: 1.3, duration: 0.34, ease: "power1.in" }, 0.64)
      .set(wa, { autoAlpha: 1 }, 1.00)
      .fromTo(wa, { scale: 0.02 }, { scale: m.floodScale, duration: 0.34, ease: "power2.in" }, 1.00)
      .to(th, { opacity: 0, duration: 0.12, ease: "power1.out" }, 1.06)

      /* the gold bloom covers everything — THIS is where the tree is brought in */
      .set(bl, { autoAlpha: 1 }, 1.18)
      .fromTo(bl, { scale: 0.02 }, { scale: m.bloomScale, duration: 0.42, ease: "power2.in" }, 1.18)
      .set(wa, { autoAlpha: 0 }, 1.5)
      .call(() => { emberBridge(); if (cb.onBloom) cb.onBloom(); }, null, 1.42)

      /* the stage retires under the gold (the bow's work is done) */
      .to(stage(), { autoAlpha: 0, duration: 0.32, ease: "power1.in" }, 1.34)

      /* the washes part on the tree (the guided scroll is travelling) */
      .to(bl, { opacity: 0, duration: 1.05, ease: "power1.inOut" }, 2.0)
      .set(bl, { autoAlpha: 0 }, 3.1);

    return tl;
  }

  /* ---------- draw / release ---------- */
  let played = false, drawing = false, startPX = 0, startPY = 0, startDraw = 0;

  function fire() {
    if (played) return;
    played = true;
    drawing = false;
    stopBeat();
    filmTL = buildFilm(shotGeom());
    filmTL.play(0);
  }

  function springBack() {
    const from = curDraw;
    gsap.to({ d: from }, {
      d: 0, duration: 0.55, ease: "elastic.out(1,0.4)",
      onUpdate() { setDraw(this.targets()[0].d); }
    });
  }

  function autoFire() {
    if (played) return;
    gsap.to({ d: curDraw }, {
      d: maxDraw * 0.94, duration: 0.62, ease: "power2.inOut",
      onUpdate() { setDraw(this.targets()[0].d); },
      onComplete: () => gsap.delayedCall(0.16, fire),
    });
  }

  function bindPointer() {
    const ar = archery(); if (!ar) return;
    ar.addEventListener("pointerdown", (e) => {
      if (played) return;
      drawing = true;
      try { ar.setPointerCapture(e.pointerId); } catch (_) { }
      startPX = e.clientX; startPY = e.clientY; startDraw = curDraw;
      e.preventDefault();
    });
    ar.addEventListener("pointermove", (e) => {
      if (!drawing) return;
      const proj = (e.clientX - startPX) * pullUX + (e.clientY - startPY) * pullUY;
      setDraw(startDraw + proj);
    });
    const endDraw = () => {
      if (!drawing) return;
      drawing = false;
      if (curDraw > maxDraw * 0.26) fire(); else springBack();
    };
    ar.addEventListener("pointerup", endDraw);
    ar.addEventListener("pointercancel", endDraw);
    ar.addEventListener("keydown", (e) => {
      if (played) return;
      if (e.key === "Enter" || e.key === " ") { e.preventDefault(); autoFire(); }
    });
    w.addEventListener("resize", () => {
      if (!played) { refreshRig(); setDraw(0); }
    }, { passive: true });
  }
  bindPointer();

  /* ---------- public control ---------- */
  function enter() {
    const st = stage(); if (!st) return;
    measure();
    refreshRig();
    setDraw(0);
    const th = target(), hg = document.querySelector("#bwTarget .heart__glow");
    const ar = archery();
    gsap.set(st, { autoAlpha: 1 });
    gsap.set([eyebrow(), hint()], { opacity: 0, y: 14 });
    gsap.set(th, { opacity: 0, y: 10, scaleX: 0.9, scaleY: 0.9 });
    gsap.set(ar, { opacity: 0, scale: 0.85 });
    if (hg) gsap.set(hg, { opacity: 0, scale: 1 });
    gsap.set(arrow(), { opacity: 1 });

    const tl = gsap.timeline({ onComplete: startBeat });
    tl.to(th, { opacity: 1, y: 0, scaleX: 1, scaleY: 1, duration: 0.8, ease: "power3.out" }, 0.1)
      .to(hg, { opacity: 0.7, duration: 0.8, ease: "power2.out" }, 0.2)
      .to(ar, { opacity: 1, scale: 1, duration: 0.8, ease: "power3.out" }, 0.28)
      .to(eyebrow(), { opacity: 1, y: 0, duration: 0.7, ease: "power3.out" }, 0.4)
      .to(hint(), { opacity: 1, y: 0, duration: 0.7, ease: "power3.out" }, 0.7);
  }

  function reset() {
    played = false;
    drawing = false;
    stopBeat();
    if (filmTL) { filmTL.pause(0); filmTL.kill(); filmTL = null; }
    const st = stage();
    if (st) {
      st.querySelectorAll(".burst,.burst-ring,.heart-half,.arrow-trail,.ember").forEach(n => n.remove());
      gsap.set([wash(), bloom()], { autoAlpha: 0 });
    }
    const th = targetHeart(); if (th) gsap.set(th, { opacity: 1 });
  }

  function arm(opts) {
    cb = Object.assign({ onShot: null, onBloom: null }, opts || {});
  }

  w.Shot = {
    arm, enter, autoFire, fire, reset, refreshRig, setDraw,
    get fired() { return played; },
    get drawing() { return drawing; },
    get rig() { return { pullUX, pullUY }; }
  };
})(window);
