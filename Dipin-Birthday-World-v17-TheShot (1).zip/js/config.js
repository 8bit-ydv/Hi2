/* =============================================================
   CONFIG — sab kuch yahin se badlo (content ≠ presentation)
   ============================================================= */
window.BDAY_CONFIG = {
  // --- Person ---
  name: "Dipin",
  handle: "@dipin",
  dob: "16 October 2006",

  // --- the start gate (the very first thing you see) ---
  gate: {
    kicker: "Ekanth Yadav · for his brother",
    name: "Dipin",
    sub: "A whole website, built for one date.",
    button: "start",
    note: "sound on · headphones if you have them"
  },

  // --- music: no file. the score is composed live, scene by scene ---
  audio: {
    volume: 0.8,
    credit: "Score composed live in your browser · one chord for every memory"
  },

  // --- Copy (keep it short & cinematic) ---
  copy: {
    arrivalKicker: "Ekanth Yadav · for his brother",
    arrivalTitle: "Dipin",
    arrivalSub: "Twenty years. Scroll to walk through them.",
    pxKickerC: "sixteen october · two thousand six",
    memoriesLine: "Some memories deserve their own little world.",
    yearsLine: "Twenty years, riding one line.",
    trainLine: "Every memory, on its way to you.",
    celebrationLine: "The sky is warming up.",
    celebrationSub: "It knows what today is.",
    finaleLine: "And that was the whole scene.",
    finaleMessage:
      "Tu bas aise hi rehna — thoda ziddi, thoda shaant, poora apna. May this year give you the roads you want, the calm you deserve, and a hundred more photos worth keeping.",
    finaleSign: "— Ekanth, your brother"
  },

  // --- scene ii : the bloom → the shot → the divine tree ---
  shot: {
    flowerKicker: "Scene ii — the bloom",
    flowerLine: "Every wish begins as a small bloom.",
    storyBeats: [
      "ek beej tha…",
      "phir ek kali bani…",
      "aur phir, ek din — wo khil gaya."
    ],
    shotKicker: "Scene ii — the shot",
    shotLine: "Some wishes need a steady aim.",
    eyebrow: "a little something, for you",
    hint: "pull & release",
    wishKicker: "and the wish took root",
    wishBig: "Happy Birthday, Dipin.",
    wishSub: "here's to a year that blooms"
  },

  // --- scene i : the parallax opening ---
  parallax: {
    lineB: "Today is about you, bhai.",
    lineC: "For your birthday celebration, the sky looked like this."
  },

  // --- scene v : the closing card ---
  finaleCard: {
    kicker: "and that's a wrap",
    big: "Twenty",
    date: "16 October 2006  ·  16 October 2026",
    line: "Ghar ka har kamra, har frame, har candle — sab tere liye tha.\nAgle saal phir milte hain, bhai.",
    credit: "for Dearest Bhai"
  },

  // --- Photo roles across the journey ---
  // (context unknown → used purely visually, no invented stories)
  photos: {
    journey:     ["p16", "p02", "p05"],
    corridor:    ["p04", "p08", "p03", "p12", "p06", "p10", "p14", "p01"],
    celebration: ["p07", "p11", "p13", "p09"],
    finale:      ["p17", "p15", "p16", "p08", "p04", "p01"],
    hero:        "p17"
  },

  // tiny ambient captions (no facts, only mood)
  captions: {
    p04: "sunlight, borrowed",
    p08: "the road, again",
    p03: "still frame",
    p12: "green hour",
    p06: "wide open",
    p10: "afternoon shadows",
    p14: "keep going",
    p01: "quiet one"
  },

  // --- SCENE VII : the 3D house ---
  // Replaces the reference portfolio's "about me" showcase.
  // Everything here is about Dipin, not a portfolio.
  // --- who is wishing whom ---
  from: "Ekanth Yadav",
  to:   "Dipin Yadav",
  age:  20,

  house: {
    kicker: "Scene vi — the house",
    title: "Come inside.",
    sub: "All floors, decorated for you.",

    // ---- the opening title cards + note (before the house appears) ----
    intro: {
      cards: [
        { small: "Ekanth Yadav", big: "presents" },
        { small: "for my brother", big: "Dipin Yadav" },
        { small: "who turns", big: "Twenty" }
      ],
      note: [
        "Bhai —",
        "Maine poora ghar saja diya hai.",
        "Lights lagayi, cake rakha, gubbare bhi.",
        "Ab bas tu andar aa jaa.",
        "Chal, celebrate karte hain."
      ],
      noteSign: "— Ekanth"
    },

    nameplate: "DIPIN",
    datePlaque: "16 OCTOBER 2006",
    banner: "HAPPY BIRTHDAY",
    birthdayBoy: "BIRTHDAY BOY · DIPIN",
    roofTitle: "HAPPY BIRTHDAY",
    roofName: "DIPIN",
    roofSub: "sixteen october · twenty years",

    // ---- the cake ceremony, driven by scroll ----
    // Every beat is pinned to a camera key (see js/house/CameraRig.js),
    // so the words and the picture can never drift apart.
    cake: {
      beats: [
        { from: "cake-approach", to: "cake-candles", text: "Candles first." },
        { from: "cake-candles",  to: "cake-number",  text: "Twenty of them — in two digits." },
        { from: "cake-number",   to: "cake-lit",     text: "Now we light them." },
        { from: "cake-lit",      to: "cake-wish",    text: "Close your eyes, bhai. Make the wish." },
        { from: "cake-wish",     to: "cake-blow",    text: "And blow." },
        { from: "cake-blow",     to: "cake-cut",     text: "Wish locked in. Now cut it." },
        { from: "cake-cut",      to: "cake-slice",   text: "First slice is yours." },
        { from: "cake-slice",    to: "gifts",        text: "That's twenty, bhai." }
      ]
    },

    // ---- the wishes that float up after the cake ----
    wishes: [
      "Happy birthday, bhai",
      "Stay exactly like this",
      "Roads, and open skies",
      "Everything you asked for",
      "A hundred more of these",
      "Twenty looks good on you"
    ],

    // ---- the three add-on features (see js/house/Magic.js) ----
    magic: {
      gifts: ["p04", "p08", "p12"],   // the boxes that open by the cake
      mirror: "p01"                   // the memory the mirror shows
    },

    photos: {
      mantel:   ["p16", "p17"],
      sideTable:["p01"],
      stairs:   ["p03", "p04", "p05", "p06"],
      memoryWall:["p07", "p08", "p09", "p10", "p11", "p12"],
      hallway:  ["p13", "p14"],
      rooftop:  ["p15", "p02"]
    },

    // ---- ambient captions, each pinned to a stretch of the journey ----
    captions: [
      { from: "far",       to: "side",      text: "There's a light on. It's been on all evening." },
      { from: "side",      to: "garden",    text: "Your brother decorated the whole place." },
      { from: "garden",    to: "enter",     text: "Someone left the door open for you." },
      { from: "enter",     to: "cake-approach", text: "Ground floor. Everything is ready." },
      { from: "gifts",     to: "wishes",    text: "The gifts have been waiting since morning." },
      { from: "wishes",    to: "turn",      text: "And every wish anyone made for you today." },
      { from: "turn",      to: "stairtop",  text: "The stairs remember everything." },
      { from: "stairtop",  to: "hallway",   text: "Upper floor. Every frame is a day you already lived." },
      { from: "hallway",   to: "roofstair", text: "Keep going. There's one more floor." },
      { from: "wishfoot",  to: "wishturn",  text: "Every wish anyone made tonight — they live here now." },
      { from: "climb6",    to: "climb7",    text: "One last flight. Something red glows ahead." },
      { from: "emerging",  to: "darkdoor",  text: "A red light at the top of the house. Go on." },
      { from: "darkroom",  to: "bayout",    text: "Some memories take their time to show up." },
      { from: "bayout",    to: "reveal",    text: "The roof. Where the sky does the rest." },
      { from: "reveal",    to: "final",     text: "Happy birthday, Dipin. Twenty looks good on you." }
    ],

    hotspots: [
      { at: [0, 8.2, 6.4],   from: "far", to: "arc",
        title: "The house",
        text: "Three floors, decorated by your brother, built out of one date." },
      { at: [0, 4.06, 7.0],  from: "portico", to: "threshold",
        title: "16 October 2006",
        text: "The day it all started. Everything above this door is built on it." },
      { at: [0.4, 2.9, -1.4], from: "cake-number", to: "cake-wish",
        title: "Twenty",
        text: "One cake, two digits. Twenty years of being my brother." },
      { at: [-3.9, 3.4, 1.4], from: "stairfoot", to: "climb2",
        title: "The staircase",
        text: "Four frames on the way up. No captions — you were there." },
      { at: [0, 7.0, -5.0],  from: "gallery", to: "hallway",
        title: "The memory wall",
        text: "Roads, trees, monuments, quiet afternoons. All of it you." },
      { at: [0, 10.6, -2.6], from: "wishfoot", to: "wishturn",
        title: "The room of wishes",
        text: "Every wish anyone made for you today, hanging here and glowing." },
      { at: [2.2, 12.9, -3.6], from: "darkdoor", to: "bayout",
        title: "The darkroom",
        text: "Some memories take their time to show up. Stand in the red light and wait." },
      { at: [0, 14.4, 0],    from: "terrace", to: "pullback",
        title: "The roof",
        text: "Make the wish up here. It's closer to wherever wishes go." }
    ]
  },

  paths: { photos: "assets/photos/" }
};
