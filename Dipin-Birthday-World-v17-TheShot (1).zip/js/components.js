/* =============================================================
   COMPONENTS — reusable builders
   photoFrame · balloon · garland · cake · splitWords
   ============================================================= */
(function (w) {
  const C = w.BDAY_CONFIG;
  const P = C.paths.photos;

  /* ---- Photo frame ---------------------------------------- */
  function photoFrame(id, opts = {}) {
    const el = document.createElement("figure");
    el.className = "photo " + (opts.className || "");
    el.style.margin = "0";
    const img = document.createElement("img");
    img.src = P + id + (opts.small ? "_sm.webp" : ".webp");
    img.alt = "";
    img.loading = opts.eager ? "eager" : "lazy";
    img.decoding = "async";
    img.draggable = false;
    if (opts.pos) img.style.objectPosition = opts.pos;
    el.appendChild(img);
    const glare = document.createElement("span");
    glare.className = "glare";
    el.appendChild(glare);
    if (opts.mat) {
      const m = document.createElement("span");
      m.className = "mat";
      el.appendChild(m);
    }
    if (opts.veil) {
      const v = document.createElement("span");
      v.className = "veil";
      el.appendChild(v);
    }
    const cap = C.captions[id];
    if (cap && opts.caption !== false) {
      const cp = document.createElement("figcaption");
      cp.className = "cap";
      cp.textContent = cap;
      el.appendChild(cp);
    }
    el.dataset.photo = id;
    return el;
  }

  /* ---- Balloon (original SVG) ------------------------------ */
  const BALLOON_PALETTE = [
    ["#e4869a", "#8e3f61"],
    ["#f3c98b", "#b0703c"],
    ["#9fb8ff", "#4a5aa0"],
    ["#f2f0ea", "#9a8f84"],
    ["#c98ad8", "#6d3a86"]
  ];
  function balloon(i = 0, size = 90) {
    const [a, b] = BALLOON_PALETTE[i % BALLOON_PALETTE.length];
    const uid = "bg" + i + "_" + Math.random().toString(36).slice(2, 7);
    const el = document.createElement("div");
    el.className = "balloon";
    el.innerHTML = `
      <svg width="${size}" height="${size * 1.75}" viewBox="0 0 100 175" aria-hidden="true">
        <defs>
          <radialGradient id="${uid}" cx="36%" cy="30%" r="72%">
            <stop offset="0" stop-color="#ffffff" stop-opacity=".72"/>
            <stop offset="28%" stop-color="${a}"/>
            <stop offset="100%" stop-color="${b}"/>
          </radialGradient>
        </defs>
        <path d="M50 108 C22 108 8 84 8 60 C8 30 27 8 50 8 C73 8 92 30 92 60 C92 84 78 108 50 108 Z" fill="url(#${uid})"/>
        <path d="M50 108 l-7 9 h14 z" fill="${b}"/>
        <path d="M50 117 C58 130 42 138 50 150 C57 161 46 168 50 175" stroke="rgba(255,236,214,.42)" stroke-width="1.2" fill="none"/>
        <ellipse cx="34" cy="36" rx="9" ry="14" fill="#fff" opacity=".26" transform="rotate(-22 34 36)"/>
      </svg>`;
    return el;
  }

  /* ---- Garland of bulbs ------------------------------------ */
  function garland(svg, spans = 3) {
    const W = 1440, H = 300;
    let d = "", bulbs = "";
    const segW = W / spans;
    for (let s = 0; s < spans; s++) {
      const x0 = s * segW, x1 = x0 + segW;
      d += `M${x0},18 Q${x0 + segW / 2},${118} ${x1},18 `;
      const N = 9;
      for (let i = 1; i < N; i++) {
        const t = i / N;
        // quadratic bezier point
        const x = (1 - t) ** 2 * x0 + 2 * (1 - t) * t * (x0 + segW / 2) + t * t * x1;
        const y = (1 - t) ** 2 * 18 + 2 * (1 - t) * t * 118 + t * t * 18;
        const hue = ["#ffd89b", "#e4869a", "#9fb8ff", "#ffe9c4"][(s * N + i) % 4];
        bulbs += `<g class="bulb" data-b="${s * N + i}">
            <line x1="${x}" y1="${y}" x2="${x}" y2="${y + 8}" stroke="rgba(255,236,214,.35)" stroke-width="1"/>
            <circle cx="${x}" cy="${y + 14}" r="5.4" fill="${hue}" opacity=".95"/>
            <circle cx="${x}" cy="${y + 14}" r="13" fill="${hue}" opacity=".16"/>
          </g>`;
      }
    }
    svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
    svg.innerHTML = `<path d="${d}" fill="none" stroke="rgba(255,236,214,.28)" stroke-width="1.4"/>${bulbs}`;
    return svg.querySelectorAll(".bulb");
  }

  /* ---- Cake (original layered SVG) ------------------------- */
  function cake(container, candleCount = 5) {
    const cw = 560, ch = 520;
    let candles = "", hits = [];
    const baseY = 172, spread = 210;
    for (let i = 0; i < candleCount; i++) {
      const t = candleCount === 1 ? 0.5 : i / (candleCount - 1);
      const x = cw / 2 - spread / 2 + t * spread;
      const h = 62 + (i % 2 ? 0 : 8);
      const topY = baseY - h;          // wick base = candle top
      // Flame is drawn in LOCAL coords around (0,0) inside a translated anchor,
      // so GSAP scales it around its own bottom-centre (the wick) with no drift.
      candles += `
        <g class="candle" data-c="${i}">
          <rect x="${x - 5}" y="${topY}" width="10" height="${h}" rx="4"
                fill="${i % 2 ? "#f6e7d4" : "#e8bfae"}"/>
          <rect x="${x - 5}" y="${topY}" width="10" height="${h}" rx="4"
                fill="url(#stripe)" opacity=".5"/>
          <line x1="${x}" y1="${topY}" x2="${x}" y2="${topY - 6}"
                stroke="#3b2a20" stroke-width="1.8" stroke-linecap="round"/>
          <g transform="translate(${x}, ${topY - 6})">
            <g class="flame" data-f="${i}">
              <ellipse cx="0" cy="-13" rx="15" ry="21" fill="url(#halo)" opacity=".5"/>
              <path d="M0,-27 C7.5,-16 7,-5 0,0 C-7,-5 -7.5,-16 0,-27 Z" fill="url(#fl)"/>
              <path d="M0,-17 C3.2,-11.5 3,-4.5 0,-1.5 C-3,-4.5 -3.2,-11.5 0,-17 Z"
                    fill="#fff6db" opacity=".92"/>
            </g>
            <g class="smoke" data-s="${i}" opacity="0">
              <path d="M0,-6 C9,-26 -9,-44 2,-66"
                    stroke="rgba(228,220,210,.5)" stroke-width="2.4" fill="none" stroke-linecap="round"/>
            </g>
          </g>
        </g>`;
      hits.push({ x: x / cw, y: (topY - 16) / ch });
    }

    container.innerHTML = `
      <svg viewBox="0 0 ${cw} ${ch}" width="100%" aria-hidden="true" id="cakeSvg">
        <defs>
          <linearGradient id="fl" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#fff3cf"/><stop offset="45%" stop-color="#ffc460"/><stop offset="100%" stop-color="#ff7a30"/>
          </linearGradient>
          <radialGradient id="halo"><stop offset="0" stop-color="#ffbe63"/><stop offset="100%" stop-color="rgba(255,140,50,0)"/></radialGradient>
          <linearGradient id="tier1" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#fbe6cf"/><stop offset="100%" stop-color="#d9a882"/>
          </linearGradient>
          <linearGradient id="tier2" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#f7dcc4"/><stop offset="100%" stop-color="#c9906d"/>
          </linearGradient>
          <linearGradient id="tier3" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#f2d0b8"/><stop offset="100%" stop-color="#b87c60"/>
          </linearGradient>
          <linearGradient id="plate" x1="0" y1="0" x2="1" y2="0">
            <stop offset="0" stop-color="#7a5340"/><stop offset="50%" stop-color="#e0b184"/><stop offset="100%" stop-color="#7a5340"/>
          </linearGradient>
          <linearGradient id="plateTop" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stop-color="#6b4a55"/><stop offset="100%" stop-color="#493046"/>
          </linearGradient>
          <pattern id="stripe" width="8" height="8" patternTransform="rotate(38)" patternUnits="userSpaceOnUse">
            <rect width="4" height="8" fill="#c25a5a"/>
          </pattern>
          <filter id="soft"><feGaussianBlur stdDeviation="9"/></filter>
        </defs>

        <ellipse cx="${cw / 2}" cy="470" rx="215" ry="30" fill="#2a1630" filter="url(#soft)" opacity=".85"/>
        ${candles}

        <!-- tier 3 (top) -->
        <g class="tier" data-t="3">
          <ellipse cx="${cw / 2}" cy="176" rx="112" ry="24" fill="#fff0dc"/>
          <path d="M168,176 L168,232 Q280,262 392,232 L392,176 Q280,206 168,176 Z" fill="url(#tier3)"/>
          <path d="M168,180 q28,22 56,4 q28,22 56,4 q28,22 56,4 q28,22 56,-12" fill="none" stroke="#fff2e0" stroke-width="7" stroke-linecap="round" opacity=".92"/>
        </g>
        <!-- tier 2 -->
        <g class="tier" data-t="2">
          <ellipse cx="${cw / 2}" cy="248" rx="150" ry="30" fill="#fff0dc"/>
          <path d="M130,248 L130,322 Q280,358 430,322 L430,248 Q280,284 130,248 Z" fill="url(#tier2)"/>
          <g opacity=".9">
            <circle cx="180" cy="292" r="4.2" fill="#e4869a"/><circle cx="222" cy="303" r="4.2" fill="#ffd89b"/>
            <circle cx="266" cy="309" r="4.2" fill="#9fb8ff"/><circle cx="310" cy="307" r="4.2" fill="#e4869a"/>
            <circle cx="352" cy="299" r="4.2" fill="#ffd89b"/><circle cx="392" cy="286" r="4.2" fill="#9fb8ff"/>
          </g>
        </g>
        <!-- tier 1 (base) -->
        <g class="tier" data-t="1">
          <ellipse cx="${cw / 2}" cy="338" rx="190" ry="36" fill="#fff0dc"/>
          <path d="M90,338 L90,420 Q280,462 470,420 L470,338 Q280,382 90,338 Z" fill="url(#tier1)"/>
          <path d="M92,346 q34,26 68,6 q34,26 68,6 q34,26 68,6 q34,26 68,2 q30,22 66,-14"
                fill="none" stroke="#fff4e6" stroke-width="9" stroke-linecap="round" opacity=".95"/>
        </g>
        <!-- plate -->
        <ellipse cx="${cw / 2}" cy="436" rx="232" ry="30" fill="url(#plate)" opacity=".55"/>
        <ellipse cx="${cw / 2}" cy="430" rx="232" ry="30" fill="url(#plateTop)" opacity=".92"/>
        <ellipse cx="${cw / 2}" cy="428" rx="232" ry="30" fill="none" stroke="rgba(255,222,175,.5)" stroke-width="1.4"/>
      </svg>`;
    return { hits, svg: container.querySelector("svg") };
  }

  /* ---- Split text into animatable words -------------------- */
  function splitWords(el, text) {
    if (!el) return [];
    el.textContent = "";
    const frag = document.createDocumentFragment();
    String(text).split(" ").forEach((word, i, arr) => {
      const mask = document.createElement("span");
      mask.className = "mask";
      mask.style.display = "inline-block";
      mask.style.verticalAlign = "top";
      const inner = document.createElement("span");
      inner.className = "word";
      inner.textContent = word + (i < arr.length - 1 ? "\u00A0" : "");
      mask.appendChild(inner);
      frag.appendChild(mask);
    });
    el.appendChild(frag);
    return el.querySelectorAll(".word");
  }

  w.UI = { photoFrame, balloon, garland, cake, splitWords };
})(window);
