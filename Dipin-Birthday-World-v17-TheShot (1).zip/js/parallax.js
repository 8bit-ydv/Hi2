/* =============================================================
   SCENE I — THE PARALLAX OPENING
   -------------------------------------------------------------
   Original artwork + motion: isladjan (https://isladjan.com/work/4/)
   Re-timed here for the birthday journey: the same three sunset →
   dusk → starfield beats, but the copy is Dipin's, and the whole
   stage hands over cleanly to the memory corridor at the end.

   The SVG is a single fixed stage (one paint layer, GPU-composited)
   so the opening costs almost nothing to animate.
   ============================================================= */
(function (w) {
  const C = w.BDAY_CONFIG;

  function init() {
    const stage = document.getElementById("pxStage");
    const svg = document.getElementById("pxSvg");
    const sec = document.getElementById("parallax");
    const scrollEl = document.getElementById("pxScroll");
    if (!stage || !svg || !sec) return;

    const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
    const speed = 100;
    const height = svg.getBBox ? svg.getBBox().height : 500;

    /* ---------- copy ---------- */
    const P = C.parallax || {};
    document.getElementById("pxLineB").textContent = P.lineB || "";
    document.getElementById("pxLineC").textContent = P.lineC || "";
    w.UI.splitWords(document.getElementById("pxTitle"), C.copy.arrivalTitle);

    // the portfolio's own signature lettering has no place here
    ["#info", "#info2"].forEach(s => {
      const el = svg.querySelector(s);
      if (el) el.style.display = "none";
    });

    /* ---------- initial state ---------- */
    gsap.set("#h2-1", { opacity: 0 });
    gsap.set("#bg_grad", { attr: { cy: "-50" } });
    gsap.set(["#dinoL", "#dinoR"], { y: 80 });
    gsap.set("#dinoL", { x: -10 });
    gsap.set(["#cloudStart-L", "#cloudStart-R"], { x: 10, opacity: 1 });
    gsap.set("#scene3", { y: height - 40, visibility: "visible" });
    gsap.set("#fstar", { y: -400 });
    gsap.set("#bats", { transformOrigin: "50% 50%" });

    const T = (sel) => svg.querySelector(sel) ? sel : null;

    /* ---------- stage visibility ----------
       The stage is fixed, so it must switch off the moment the corridor
       takes over — otherwise it would sit on top of the whole site. */
    ScrollTrigger.create({
      trigger: sec, start: "top bottom", end: "bottom top",
      onToggle: self => stage.classList.toggle("on", self.isActive)
    });
    // and it dissolves into the night sky over the last stretch
    gsap.fromTo(stage, { opacity: 1 }, {
      opacity: 0, ease: "none",
      scrollTrigger: { trigger: sec, start: "bottom-=900 top", end: "bottom top", scrub: true }
    });

    /*  SCENE 1 — the sunset hills  */
    const scene1 = gsap.timeline();
    ScrollTrigger.create({
      animation: scene1, trigger: scrollEl,
      start: "top top", end: "45% 100%", scrub: 3
    });
    scene1.to("#h1-1", { y: 3 * speed, x: 1 * speed, scale: 0.9, ease: "power1.in" }, 0);
    scene1.to("#h1-2", { y: 2.6 * speed, x: -0.6 * speed, ease: "power1.in" }, 0);
    scene1.to("#h1-3", { y: 1.7 * speed, x: 1.2 * speed }, 0.03);
    scene1.to("#h1-4", { y: 3 * speed, x: 1 * speed }, 0.03);
    scene1.to("#h1-5", { y: 2 * speed, x: 1 * speed }, 0.03);
    scene1.to("#h1-6", { y: 2.3 * speed, x: -2.5 * speed }, 0);
    scene1.to("#h1-7", { y: 5 * speed, x: 1.6 * speed }, 0);
    scene1.to("#h1-8", { y: 3.5 * speed, x: 0.2 * speed }, 0);
    scene1.to("#h1-9", { y: 3.5 * speed, x: -0.2 * speed }, 0);
    scene1.to("#cloudsBig-L", { y: 4.5 * speed, x: -0.2 * speed }, 0);
    scene1.to("#cloudsBig-R", { y: 4.5 * speed, x: -0.2 * speed }, 0);
    scene1.to("#cloudStart-L", { x: -300 }, 0);
    scene1.to("#cloudStart-R", { x: 300 }, 0);

    /*  the bird  */
    gsap.fromTo("#bird", { opacity: 1 }, {
      y: -250, x: 800, ease: "power2.out",
      scrollTrigger: {
        trigger: scrollEl, start: "15% top", end: "60% 100%", scrub: 4,
        onEnter: () => gsap.to("#bird", { scaleX: 1, rotation: 0 }),
        onLeave: () => gsap.to("#bird", { scaleX: -1, rotation: -15 })
      }
    });

    /*  clouds  */
    const clouds = gsap.timeline();
    ScrollTrigger.create({ animation: clouds, trigger: scrollEl, start: "top top", end: "70% 100%", scrub: 1 });
    clouds.to("#cloud1", { x: 500 }, 0);
    clouds.to("#cloud2", { x: 1000 }, 0);
    clouds.to("#cloud3", { x: -1000 }, 0);
    clouds.to("#cloud4", { x: -700, y: 25 }, 0);

    /*  the sun goes down  */
    const sun = gsap.timeline();
    ScrollTrigger.create({ animation: sun, trigger: scrollEl, start: "1% top", end: "2150 100%", scrub: 2 });
    sun.fromTo("#bg_grad", { attr: { cy: "-50" } }, { attr: { cy: "330" } }, 0);
    sun.to("#bg_grad stop:nth-child(2)", { attr: { offset: "0.15" } }, 0);
    sun.to("#bg_grad stop:nth-child(3)", { attr: { offset: "0.18" } }, 0);
    sun.to("#bg_grad stop:nth-child(4)", { attr: { offset: "0.25" } }, 0);
    sun.to("#bg_grad stop:nth-child(5)", { attr: { offset: "0.46" } }, 0);
    sun.to("#bg_grad stop:nth-child(6)", { attr: { "stop-color": "#FF9171" } }, 0);

    /*  SCENE 2 — dusk  */
    const scene2 = gsap.timeline();
    ScrollTrigger.create({ animation: scene2, trigger: scrollEl, start: "15% top", end: "40% 100%", scrub: 3 });
    scene2.fromTo("#h2-1", { y: 500, opacity: 0 }, { y: 0, opacity: 1 }, 0);
    scene2.fromTo("#h2-2", { y: 500 }, { y: 0 }, 0.1);
    scene2.fromTo("#h2-3", { y: 700 }, { y: 0 }, 0.1);
    scene2.fromTo("#h2-4", { y: 700 }, { y: 0 }, 0.2);
    scene2.fromTo("#h2-5", { y: 800 }, { y: 0 }, 0.3);
    scene2.fromTo("#h2-6", { y: 900 }, { y: 0 }, 0.3);

    /*  bats  */
    gsap.fromTo("#bats", { opacity: 1, y: 400, scale: 0 }, {
      y: 20, scale: 0.8, ease: "power3.out",
      scrollTrigger: {
        trigger: scrollEl, start: "40% top", end: "70% 100%", scrub: 3,
        onEnter() {
          gsap.utils.toArray("#bats path").forEach((item, i) => {
            gsap.to(item, {
              scaleX: 0.5, yoyo: true, repeat: 9, transformOrigin: "50% 50%",
              duration: 0.15, delay: 0.7 + i / 10
            });
          });
          gsap.set("#bats", { opacity: 1 });
        }
      }
    });

    /*  the sun swells, the palette turns to night
        (the whole stop chain expands together — a lone expanding
        core stop inverts the gradient and the sun turns BLACK)  */
    const sun2 = gsap.timeline();
    ScrollTrigger.create({ animation: sun2, trigger: scrollEl, start: "2000 top", end: "5000 100%", scrub: 2 });
    sun2.to("#sun", { attr: { offset: "1.0" } }, 0);
    sun2.to("#bg_grad stop:nth-child(2)", { attr: { offset: "1.08" } }, 0);
    sun2.to("#bg_grad stop:nth-child(3)", { attr: { offset: "1.16" } }, 0);
    sun2.to("#bg_grad stop:nth-child(4)", { attr: { offset: "1.24" } }, 0);
    sun2.to("#bg_grad stop:nth-child(5)", { attr: { offset: "1.32" } }, 0);
    sun2.to("#bg_grad stop:nth-child(6)", { attr: { offset: "1.42" } }, 0);
    sun2.to("#sun", { attr: { "stop-color": "#FFD27A" } }, 0);
    sun2.to("#lg4 stop:nth-child(1)", { attr: { "stop-color": "#623951" } }, 0);
    sun2.to("#lg4 stop:nth-child(2)", { attr: { "stop-color": "#261F36" } }, 0);
    sun2.to("#bg_grad stop:nth-child(6)", { attr: { "stop-color": "#6b3a63" } }, 0);

    /*  transition into scene 3  */
    const sceneTransition = gsap.timeline();
    ScrollTrigger.create({ animation: sceneTransition, trigger: scrollEl, start: "60% top", end: "bottom 100%", scrub: 3 });
    sceneTransition.to("#h2-1", { y: -height - 100, scale: 1.5, transformOrigin: "50% 50%" }, 0);
    sceneTransition.to("#bg_grad", { attr: { cy: "-80" } }, 0);
    sceneTransition.to("#bg2", { y: 0 }, 0);

    /*  SCENE 3 — the starfield  */
    const scene3 = gsap.timeline();
    ScrollTrigger.create({ animation: scene3, trigger: scrollEl, start: "70% 50%", end: "bottom 100%", scrub: 3 });
    scene3.fromTo("#h3-1", { y: 300 }, { y: -550 }, 0);
    scene3.fromTo("#h3-2", { y: 800 }, { y: -550 }, 0.03);
    scene3.fromTo("#h3-3", { y: 600 }, { y: -550 }, 0.06);
    scene3.fromTo("#h3-4", { y: 800 }, { y: -550 }, 0.09);
    scene3.fromTo("#h3-5", { y: 1000 }, { y: -550 }, 0.12);
    scene3.fromTo("#stars", { opacity: 0 }, { opacity: 0.5, y: -500 }, 0);
    scene3.to("#bg2-grad", { attr: { cy: 600 } }, 0);
    scene3.to("#bg2-grad", { attr: { r: 500 } }, 0);

    /*  falling star  */
    const fstarTL = gsap.timeline();
    ScrollTrigger.create({
      animation: fstarTL, trigger: scrollEl, start: "4200 top", end: "6000 bottom", scrub: 2,
      onEnter: () => gsap.set("#fstar", { opacity: 1 }),
      onLeave: () => gsap.set("#fstar", { opacity: 0 })
    });
    fstarTL.to("#fstar", { x: -700, y: -250, ease: "power2.out" }, 0);

    /*  twinkle — a handful of stars only, and never off-screen  */
    if (!reduce) {
      [1, 3, 5, 8, 11, 15, 17, 18, 25, 28, 30, 35, 40, 45, 48].forEach((n, i) => {
        gsap.fromTo(`#stars path:nth-of-type(${n})`, { opacity: 0.3 },
          { opacity: 1, duration: 0.3, repeat: -1, repeatDelay: 0.5 + (i % 5) * 0.35 });
      });
    }

    /* ---------- the birthday copy on top ---------- */
    const A = document.getElementById("pxCopyA");
    const B = document.getElementById("pxCopyB");
    const Cc = document.getElementById("pxCopyC");
    const cue = document.getElementById("pxCue");

    gsap.set([B, Cc], { opacity: 0, y: 30 });

    // A: the title rides down with the hills, then leaves
    gsap.to(A, {
      y: 260, opacity: 0, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "top top", end: "22% 100%", scrub: 2 }
    });
    gsap.to(cue, {
      opacity: 0, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "top top", end: "6% top", scrub: true }
    });

    // B: arrives over the dusk hills
    gsap.fromTo(B, { opacity: 0, y: 40 }, {
      opacity: 1, y: 0, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "26% top", end: "38% top", scrub: 2 }
    });
    gsap.to(B, {
      opacity: 0, y: -50, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "48% top", end: "58% top", scrub: 2 }
    });

    // C: the night sky line, the last thing before the memories
    gsap.fromTo(Cc, { opacity: 0, y: 46 }, {
      opacity: 1, y: 0, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "76% top", end: "88% top", scrub: 2 }
    });
    gsap.to(Cc, {
      opacity: 0, y: -40, ease: "none",
      scrollTrigger: { trigger: scrollEl, start: "94% top", end: "bottom top", scrub: 2 }
    });
  }

  w.Parallax = { init };
})(window);
