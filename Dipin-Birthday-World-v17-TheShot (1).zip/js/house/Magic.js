/* =============================================================
   MAGIC — the three add-on features of the house

     🎁 memory gifts   boxes by the cake open as the camera reaches
                       them and a real photograph rises out
     🪞 magic mirror   a wall mirror on the upper floor whose glass
                       gives way to a memory as you pass
     🌌 constellation  every photograph becomes a point in the night
                       sky above the rooftop; the lines draw them-
                       selves, brighten, then drift apart as the
                       memories become stars

   Everything is a pure function of scroll progress (scrub back and
   it replays in reverse), every photograph uses the shared TEX_CACHE
   (one texture per file, forever), and nothing here adds a real
   light — glows are sprites that join the additive cloud.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { DIM, LEVEL } from "./Architecture.js";
import { makePhotoFrame, getPhotoTexture, PHOTO_RATIO } from "./PhotoFrame.js";
import { roundedBox, turned, glowSprite } from "./geometry.js";

const { G, U, R } = LEVEL;
const C = () => window.BDAY_CONFIG;
const P = () => window.BDAY_CONFIG.paths.photos;

const seg = (x, a, b) => {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
};

/* a photo plane with a soft radial mask — feels IN the glass, not pasted */
function maskedPhotoMaterial(url, aniso) {
  const tex = getPhotoTexture(url, aniso || 4);
  return new THREE.ShaderMaterial({
    transparent: true, depthWrite: false,
    uniforms: { map: { value: tex }, uReveal: { value: 0 }, uWarm: { value: 0.12 } },
    vertexShader: `
      varying vec2 vUv;
      void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `
      uniform sampler2D map; uniform float uReveal; uniform float uWarm;
      varying vec2 vUv;
      void main(){
        vec4 c = texture2D(map, vUv);
        float d = length((vUv - 0.5) * vec2(1.15, 1.32));
        float m = smoothstep(0.6, 0.36, d) * uReveal;
        c.rgb += vec3(0.9, 0.55, 0.25) * uWarm * smoothstep(0.25, 0.55, d) * uReveal;
        gl_FragColor = vec4(c.rgb, m);
      }`
  });
}

/* =============================================================
   🎁 THE MEMORY GIFTS
   ============================================================= */
function buildGifts(scene, M, quality, tAt) {
  const ids = (C().house.magic && C().house.magic.gifts) || ["p04", "p08", "p12"];
  const CAM = new THREE.Vector3(0.45, G + 1.62, 2.45);   // the "gifts" camera key
  const spots = [
    { x: -2.42, z: 1.42, size: 0.46, ry: 0.5 },
    { x: -1.05, z: 1.58, size: 0.40, ry: -0.35 },
    { x: -2.05, z: 0.18, size: 0.44, ry: 0.95 }
  ];
  const WINDOWS = [
    [tAt("cake-slice"), tAt("gifts")],
    [tAt("gifts"), (tAt("gifts") + tAt("wishes")) / 2],
    [(tAt("gifts") + tAt("wishes")) / 2, tAt("wishes")]
  ];

  const group = new THREE.Group();
  scene.add(group);
  const sprites = [];                       // glow halos — join the cloud
  const gifts = ids.slice(0, 3).map((id, i) => {
    const s = spots[i];
    const sz = s.size;
    const g = new THREE.Group();
    g.position.set(s.x, G, s.z);
    g.rotation.y = s.ry;

    const mat = M.gifts[(i * 2 + 1) % M.gifts.length];
    const box = new THREE.Mesh(roundedBox(sz, sz * 0.8, sz, sz * 0.06, 2), mat);
    box.position.y = sz * 0.4;
    g.add(box);
    const inner = new THREE.Mesh(
      new THREE.BoxGeometry(sz * 0.82, 0.04, sz * 0.82),
      new THREE.MeshStandardMaterial({ color: 0x3a2c22, roughness: 0.9,
        emissive: 0xffb066, emissiveIntensity: 0.0 }));
    inner.position.y = sz * 0.06;
    g.add(inner);

    // lid, hinged at its back edge so it swings away from the camera
    const lid = new THREE.Group();
    lid.position.set(0, sz * 0.8, -sz / 2);
    const lidTop = new THREE.Mesh(roundedBox(sz * 1.08, sz * 0.16, sz * 1.08, sz * 0.05, 1), mat);
    lidTop.position.set(0, sz * 0.08, sz / 2);
    lid.add(lidTop);
    const ribbon = new THREE.Mesh(roundedBox(sz * 0.13, sz * 0.17, sz * 1.1, 0.02, 1), M.ribbon);
    ribbon.position.set(0, sz * 0.09, sz / 2);
    lid.add(ribbon);
    const knot = new THREE.Mesh(new THREE.SphereGeometry(sz * 0.07, 10, 8), M.ribbon);
    knot.position.set(0, sz * 0.21, sz / 2);
    lid.add(knot);
    g.add(lid);

    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowSprite("rgb(255,205,140)"), color: 0xffcd8c, transparent: true,
      opacity: 0, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    halo.scale.setScalar(sz * 1.7);
    halo.position.y = sz * 0.85;
    g.add(halo);
    sprites.push(halo);

    // the photograph: a real framed print, opaque, anti-flicker by design
    const frame = makePhotoFrame(P() + id + "_sm.webp", M, {
      width: sz * 0.78, ratio: 1.33, frame: "frameGold",
      matWidth: 0.024, anisotropy: quality.aniso, glass: false
    });
    frame.position.set(0, sz * 0.5, 0);
    frame.scale.set(1, 0.02, 1);
    frame.visible = false;
    // aim the frame at the approaching camera (compensate the parent's yaw)
    frame.rotation.y = Math.atan2(CAM.x - s.x, CAM.z - s.z) - s.ry;
    g.add(frame);

    group.add(g);
    g.traverse(o => { o.userData.dynamic = true; });
    g.userData.dynamic = true;
    return { g, lid, halo, inner, frame, sz, win: WINDOWS[i] };
  });
  return { group, gifts, sprites };
}

/* =============================================================
   🪞 THE MAGIC MIRROR
   ============================================================= */
function buildMirror(scene, M, quality, tAt) {
  const id = (C().house.magic && C().house.magic.mirror) || "p01";
  const W2 = 0.78, H2 = 1.72;
  const g = new THREE.Group();
  // The frame's front face now meets the interior plaster (x ≈ 6.143) so
  // the mirror reads as mounted ON the wall instead of hovering 11 cm off it.
  g.position.set(DIM.W / 2 - DIM.T - 0.03, U + 1.82, 0.95);
  g.rotation.y = -Math.PI / 2;                     // on the right wall, facing the room

  const fw = 0.085;
  [[0, H2 / 2 + fw / 2, W2 + fw * 2, fw], [0, -H2 / 2 - fw / 2, W2 + fw * 2, fw],
   [-W2 / 2 - fw / 2, 0, fw, H2], [W2 / 2 + fw / 2, 0, fw, H2]]
    .forEach(([x, y, w, h]) => {
      const bar = new THREE.Mesh(roundedBox(w, h, 0.07, 0.02, 1), M.frameGold);
      bar.position.set(x, y, 0.015);
      g.add(bar);
    });
  const crest = new THREE.Mesh(
    turned([[0, 0], [0.05, 0], [0.04, 0.1], [0.07, 0.22], [0.03, 0.3], [0, 0.32]], 10), M.frameGold);
  crest.position.set(0, H2 / 2 + fw + 0.14, 0.03);
  g.add(crest);

  const glassMat = new THREE.ShaderMaterial({
    transparent: true,
    uniforms: { uTime: { value: 0 }, uShimmer: { value: 0 } },
    vertexShader: `
      varying vec2 vUv;
      void main(){ vUv = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0); }`,
    fragmentShader: `
      uniform float uTime; uniform float uShimmer;
      varying vec2 vUv;
      void main(){
        vec3 base = mix(vec3(0.055,0.075,0.11), vec3(0.13,0.16,0.21),
                        smoothstep(0.1, 0.9, vUv.y));
        float band = sin(vUv.y * 5.2 - uTime * 0.35 + sin(vUv.x * 3.0) * 0.6);
        base += vec3(0.05,0.06,0.08) * smoothstep(0.2, 1.0, band);
        float sweep = smoothstep(0.22, 0.0, abs(vUv.x - 0.5 - 0.34 * sin(uTime * 0.22)));
        base += vec3(0.22,0.24,0.3) * sweep * 0.35 * (0.35 + uShimmer);
        base += vec3(0.45,0.3,0.16) * uShimmer * smoothstep(0.5, 0.12, abs(vUv.y - 0.5));
        float d = length((vUv - 0.5) * vec2(1.0, 0.72));
        base *= 1.0 - 0.38 * smoothstep(0.42, 0.75, d);
        gl_FragColor = vec4(base, 0.94);
      }`
  });
  const glass = new THREE.Mesh(new THREE.PlaneGeometry(W2, H2), glassMat);
  glass.position.z = 0.055;
  g.add(glass);

  const photoMat = maskedPhotoMaterial(P() + id + ".webp", quality.aniso);
  // Size the photo plane to the photograph's own aspect ratio — the old
  // fixed 0.72×1.55 m plane squashed portrait photos by ~40 %.
  const photoW = W2 * 0.92;
  const photoH = photoW * (PHOTO_RATIO(id) || 1.333);
  const photo = new THREE.Mesh(new THREE.PlaneGeometry(photoW, photoH), photoMat);
  photo.position.z = 0.062;
  photo.renderOrder = 2;
  g.add(photo);

  scene.add(g);
  g.traverse(o => { o.userData.dynamic = true; });
  g.userData.dynamic = true;

  // the camera only rounds on the mirror as it swings from the memory
  // wall to the hallway — so the memory surfaces while it is arriving,
  // and is fully there by the hallway key, then quietly fades as the
  // camera turns to the stairs
  const mw = tAt("memorywall"), mh = tAt("hallway"), mr = tAt("roofstair");
  return {
    group: g, glass: glassMat, photo: photoMat,
    wShimmer: [tAt("gallery"), mw + (mh - mw) * 0.5],
    wReveal: [mw + (mh - mw) * 0.55, mh + (mr - mh) * 0.35],
    wFade: [tAt("climb4"), tAt("climb5")]
  };
}

/* =============================================================
   🌌 THE PHOTO CONSTELLATION — "twenty", written in stars
   Seventeen points, one per photograph, laid out high and FAR in
   the night sky so it reads as stars, never as objects hovering
   over the terrace. The points appear in stroke order — the "2"
   is drawn, then the "0" — the sky literally writes twenty.
   Two extra anchor stars frame the number. */
const CONST_POINTS = [
  // anchor stars (appear first, smallest)
  [-11.6, 38.6, -63], [11.4, 37.8, -58],
  // the "2" — top arc, the sweep down-left, the base
  [-8.2, 36.2, -60], [-6.2, 37.8, -62], [-4.0, 37.6, -64], [-2.9, 35.6, -63],
  [-4.8, 33.4, -61], [-7.6, 31.8, -59], [-2.8, 30.2, -62],
  // the "0" — a slow ellipse, clockwise from the top
  [3.2, 37.9, -61], [5.6, 36.8, -63], [6.6, 34.0, -64], [5.6, 31.2, -62],
  [3.2, 30.1, -60], [0.8, 31.2, -59], [0.8, 36.8, -59], [1.8, 37.4, -60]
];
const CONST_EDGES = [
  // the "2", in one stroke (points 2..8)
  [2, 3], [3, 4], [4, 5], [5, 6], [6, 7], [7, 8],
  // anchors touch the digits lightly
  [0, 2], [1, 9],
  // the "0", closed (points 9..16)
  [9, 10], [10, 11], [11, 12], [12, 13], [13, 14], [14, 15], [15, 16], [16, 9]
];

function buildConstellation(scene, quality, tAt) {
  const ids = [];
  for (let i = 1; i <= 17; i++) ids.push("p" + String(i).padStart(2, "0"));
  const N = CONST_POINTS.length;
  const centroid = new THREE.Vector3();
  CONST_POINTS.forEach(p => centroid.add(new THREE.Vector3(...p)));
  centroid.multiplyScalar(1 / N);

  const pos = new Float32Array(N * 3);
  const order = new Float32Array(N);
  const bright = new Float32Array(N);
  CONST_POINTS.forEach((p, i) => {
    pos.set(p, i * 3);
    order[i] = i / (N - 1);
    bright[i] = i === 0 || i === 1 ? 0.55 : 0.8 + (i % 3) * 0.07;
  });

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("aOrder", new THREE.BufferAttribute(order, 1));
  geo.setAttribute("aBright", new THREE.BufferAttribute(bright, 1));

  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: {
      uTime: { value: 0 }, uAppear: { value: 0 }, uGlow: { value: 0 },
      uSpread: { value: 0 }, uCentroid: { value: centroid },
      uPR: { value: Math.min(devicePixelRatio || 1, 2) }
    },
    vertexShader: `
      attribute float aOrder; attribute float aBright;
      uniform float uTime, uAppear, uSpread, uGlow; uniform vec3 uCentroid; uniform float uPR;
      varying float vA;
      void main(){
        vec3 p = mix(position, position + (position - uCentroid) * 0.22, uSpread);
        float appear = smoothstep(aOrder, aOrder + 0.045, uAppear);
        float tw = 0.75 + 0.25 * sin(uTime * 1.4 + aOrder * 21.0);
        vA = appear * aBright * (0.72 + 0.28 * tw) * (1.0 + uGlow * 0.8);
        vec4 mv = modelViewMatrix * vec4(p, 1.0);
        gl_PointSize = clamp((15.0 * aBright + 11.0 * uGlow) * uPR / -mv.z * 10.0, 1.0, 9.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vA;
      void main(){
        float d = length(gl_PointCoord - 0.5) * 2.0;
        if (d > 1.0) discard;
        float a = pow(1.0 - d, 2.4) * vA;
        vec3 col = mix(vec3(1.0, 0.88, 0.7), vec3(1.0, 0.97, 0.9), pow(1.0 - d, 3.0));
        gl_FragColor = vec4(col, a * 0.8);
      }`
  });
  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 5;
  points.userData.dynamic = true;
  scene.add(points);

  const lp = new Float32Array(CONST_EDGES.length * 6);
  const lo = new Float32Array(CONST_EDGES.length * 2);
  CONST_EDGES.forEach(([a, b], i) => {
    lp.set(CONST_POINTS[a], i * 6);
    lp.set(CONST_POINTS[b], i * 6 + 3);
    const o = Math.max(order[a], order[b]);
    lo[i * 2] = o; lo[i * 2 + 1] = o;
  });
  const lgeo = new THREE.BufferGeometry();
  lgeo.setAttribute("position", new THREE.BufferAttribute(lp, 3));
  lgeo.setAttribute("aOrder", new THREE.BufferAttribute(lo, 1));
  const lmat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: { uDraw: { value: 0 }, uGlow: { value: 0 }, uSpread: { value: 0 },
                uCentroid: { value: centroid } },
    vertexShader: `
      attribute float aOrder;
      uniform float uDraw, uSpread; uniform vec3 uCentroid;
      varying float vA;
      void main(){
        vec3 p = mix(position, position + (position - uCentroid) * 0.22, uSpread);
        vA = smoothstep(aOrder + 0.02, aOrder - 0.02, uDraw);
        gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
      }`,
    fragmentShader: `
      uniform float uGlow; varying float vA;
      void main(){
        gl_FragColor = vec4(1.0, 0.93, 0.78, vA * (0.10 + uGlow * 0.22));
      }`
  });
  const lines = new THREE.LineSegments(lgeo, lmat);
  lines.frustumCulled = false;
  lines.renderOrder = 5;
  lines.userData.dynamic = true;
  scene.add(lines);

  /* hover previews: one tiny masked photo per point, sized to each
     photograph's own aspect ratio (the old fixed 4.4×3.5 m plane
     stretched every portrait photo by ~40 %). */
  const previews = ids.map((id, i) => {
    const m = maskedPhotoMaterial(P() + id + "_sm.webp", quality.aniso || 4);
    const pw = 3.1;
    const ph = pw * (PHOTO_RATIO(id) || 1.333);
    const pl = new THREE.Mesh(new THREE.PlaneGeometry(pw, ph), m);
    pl.position.set(CONST_POINTS[i][0], CONST_POINTS[i][1] + 3.4, CONST_POINTS[i][2]);
    pl.renderOrder = 6;
    pl.visible = false;
    pl.userData.dynamic = true;
    scene.add(pl);
    return { plane: pl, mat: m, idx: i };
  });

  return {
    points, lines, mat, lmat, previews,
    appear: [tAt("terrace"), tAt("reveal")],
    draw: [tAt("reveal"), tAt("pullback")],
    glow: [tAt("pullback"), tAt("final")],
    spread: [tAt("pullback"), 1.0]
  };
}

/* =============================================================
   BUILD + UPDATE
   ============================================================= */
export function buildMagic(scene, M, quality, tAt) {
  const gifts = buildGifts(scene, M, quality, tAt);
  const mirror = buildMirror(scene, M, quality, tAt);
  const constellation = buildConstellation(scene, quality, tAt);

  /* the gift halos become points in the glow cloud; HouseScene wires
     these indices after the cloud exists */
  let haloIdx = [];

  const _ndc = new THREE.Vector2();
  const _rc = new THREE.Raycaster();
  _rc.params.Points.threshold = 2.6;

  function focusPreview(c, mouse, camera, p) {
    _ndc.set(mouse.tx, -mouse.ty);
    _rc.setFromCamera(_ndc, camera);
    const hits = _rc.intersectObject(c.points, false);
    const focus = hits.length ? hits[0].index : -1;
    for (let i = 0; i < c.previews.length; i++) {
      const pv = c.previews[i];
      const target = (pv.idx === focus && p > c.appear[1] - 0.02) ? 1 : 0;
      const cur = pv.mat.uniforms.uReveal.value;
      const next = cur + (target - cur) * 0.12;
      pv.mat.uniforms.uReveal.value = next;
      pv.plane.visible = next > 0.02;
      if (pv.plane.visible) pv.plane.lookAt(camera.position);
    }
  }

  function update(p, t, mouse, camera, glowCloud) {
    /* 🎁 gifts */
    for (let i = 0; i < gifts.gifts.length; i++) {
      const Gf = gifts.gifts[i];
      const [a, b] = Gf.win;
      const open = seg(p, a, b);
      Gf.lid.rotation.x = -1.45 * seg(p, a, a + (b - a) * 0.55);
      Gf.inner.material.emissiveIntensity = 0.15 + open * 1.6;
      const rise = seg(p, a + (b - a) * 0.3, b);
      Gf.frame.visible = rise > 0.01;
      Gf.frame.scale.y = 0.02 + 0.98 * rise;
      Gf.frame.position.y = Gf.sz * 0.5 + rise * (Gf.sz * 1.95);
      Gf.frame.rotation.z = Math.sin(t * 0.8 + i * 1.7) * 0.02;
      if (glowCloud && haloIdx[i] !== undefined)
        glowCloud.setBrightness(haloIdx[i], open * (0.4 + Math.sin(t * 3 + i) * 0.07));
    }

    /* 🪞 mirror */
    const shim = seg(p, mirror.wShimmer[0], mirror.wShimmer[1]) * 0.5
               + seg(p, mirror.wReveal[0], mirror.wReveal[1]) * 0.5;
    const rev = seg(p, mirror.wReveal[0], mirror.wReveal[1]);
    const out = 1 - seg(p, mirror.wFade[0], mirror.wFade[1]);
    mirror.glass.uniforms.uTime.value = t;
    mirror.glass.uniforms.uShimmer.value = shim * 0.8 * (1 - rev * 0.7);
    mirror.photo.uniforms.uReveal.value = rev * out;

    /* 🌌 constellation */
    const c = constellation;
    c.mat.uniforms.uTime.value = t;
    c.mat.uniforms.uAppear.value = seg(p, c.appear[0], c.appear[1]);
    c.mat.uniforms.uGlow.value = seg(p, c.glow[0], c.glow[1]);
    c.mat.uniforms.uSpread.value = seg(p, c.spread[0], c.spread[1]) * 0.85;
    c.lmat.uniforms.uDraw.value = seg(p, c.draw[0], c.draw[1]);
    c.lmat.uniforms.uGlow.value = c.mat.uniforms.uGlow.value;
    c.lmat.uniforms.uSpread.value = c.mat.uniforms.uSpread.value;

    /* preview focus — pointers only, and only once the stars are out */
    if (mouse && camera && !quality.mobile && p > c.appear[0] - 0.02 && p < 1.0) {
      focusPreview(c, mouse, camera, p);
    } else {
      for (let i = 0; i < c.previews.length; i++) {
        const pv = c.previews[i];
        if (pv.mat.uniforms.uReveal.value > 0)
          pv.mat.uniforms.uReveal.value = Math.max(0, pv.mat.uniforms.uReveal.value - 0.08);
        if (pv.mat.uniforms.uReveal.value <= 0) pv.plane.visible = false;
      }
    }
  }

  return {
    update, gifts, mirror, constellation,
    sprites: gifts.sprites,
    bindGlow(cloud, map) {
      haloIdx = gifts.sprites.map(s => map(s)).filter(i => i !== undefined && i !== null);
    }
  };
}
