/* =============================================================
   ENVIRONMENT
   The island the house stands on, the water around it, distant
   headlands, trees, fireflies and a night sky dome. This is what
   the parallax intro dissolves INTO, so it shares its palette.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { getPhotoTexture } from "./PhotoFrame.js";
import { roundedBox, turned, noiseTexture, glowSprite } from "./geometry.js";
import { DIM } from "./Architecture.js";

export function buildEnvironment(scene, M, quality) {
  const g = new THREE.Group();
  scene.add(g);
  const anim = { water: null, fireflies: null, seeds: [], lanterns: [] };

  /* ---------------- sky dome ---------------- */
  const skyGeo = new THREE.SphereGeometry(320, 32, 20);
  const skyMat = new THREE.ShaderMaterial({
    side: THREE.BackSide, depthWrite: false,
    uniforms: {
      uTop:    { value: new THREE.Color(0x0a0a1f) },
      uMid:    { value: new THREE.Color(0x2a1c44) },
      uBottom: { value: new THREE.Color(0x6a3a52) },
      uWarm:   { value: 0.0 }
    },
    vertexShader: `
      varying vec3 vWorld;
      void main(){
        vWorld = (modelMatrix * vec4(position,1.0)).xyz;
        gl_Position = projectionMatrix * modelViewMatrix * vec4(position,1.0);
      }`,
    fragmentShader: `
      uniform vec3 uTop; uniform vec3 uMid; uniform vec3 uBottom; uniform float uWarm;
      varying vec3 vWorld;
      void main(){
        float h = normalize(vWorld).y * 0.5 + 0.5;
        vec3 c = mix(uBottom, uMid, smoothstep(0.0, 0.55, h));
        c = mix(c, uTop, smoothstep(0.45, 1.0, h));
        // warm horizon glow that grows toward the finale
        c += vec3(0.32,0.13,0.03) * uWarm * pow(1.0 - abs(h - 0.42) * 2.2, 3.0);
        gl_FragColor = vec4(c, 1.0);
      }`
  });
  const sky = new THREE.Mesh(skyGeo, skyMat);
  sky.userData.alwaysVisible = true;   // seen from every zone, incl. through windows/from the roof
  g.add(sky);
  anim.sky = skyMat;

  /* ---------------- stars ---------------- */
  const starCount = quality.mobile ? 700 : 1800;
  const sPos = new Float32Array(starCount * 3);
  const sSize = new Float32Array(starCount);
  const sPhase = new Float32Array(starCount);
  for (let i = 0; i < starCount; i++) {
    // upper hemisphere only
    const u = Math.random(), v = Math.random() * 0.62 + 0.06;
    const th = u * Math.PI * 2, ph = Math.acos(1 - 2 * v * 0.5);
    const r = 240 + Math.random() * 50;
    sPos[i * 3]     = r * Math.sin(ph) * Math.cos(th);
    sPos[i * 3 + 1] = Math.abs(r * Math.cos(ph)) * 0.9 + 12;
    sPos[i * 3 + 2] = r * Math.sin(ph) * Math.sin(th);
    sSize[i] = Math.random() * 1.6 + 0.5;
    sPhase[i] = Math.random() * 6.28;
  }
  const starGeo = new THREE.BufferGeometry();
  starGeo.setAttribute("position", new THREE.BufferAttribute(sPos, 3));
  starGeo.setAttribute("aSize", new THREE.BufferAttribute(sSize, 1));
  starGeo.setAttribute("aPhase", new THREE.BufferAttribute(sPhase, 1));
  const starMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: { uTime: { value: 0 }, uOpacity: { value: 1 } },
    vertexShader: `
      attribute float aSize; attribute float aPhase;
      uniform float uTime; varying float vTw;
      void main(){
        vTw = 0.55 + 0.45 * sin(uTime * 1.4 + aPhase);
        vec4 mv = modelViewMatrix * vec4(position,1.0);
        gl_PointSize = aSize * (300.0 / -mv.z);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vTw; uniform float uOpacity;
      void main(){
        float d = length(gl_PointCoord - 0.5);
        if (d > 0.5) discard;
        float a = smoothstep(0.5, 0.0, d) * vTw * uOpacity;
        gl_FragColor = vec4(vec3(1.0, 0.96, 0.88), a);
      }`
  });
  const stars = new THREE.Points(starGeo, starMat);
  g.add(stars);
  anim.stars = starMat;

  /* ---------------- moon ---------------- */
  // Basic materials and sprites are fogged by default — at ~220 m from the
  // camera the fog swallowed ~30 % of the moon, and because the fog density
  // itself is animated during the intro, the moon visibly dimmed/brightened
  // as you scrolled. The moon is a light source; it stays out of the fog.
  const moon = new THREE.Mesh(
    new THREE.SphereGeometry(9, 28, 20),
    new THREE.MeshBasicMaterial({ color: 0xfff2d4, fog: false })
  );
  moon.position.set(-120, 78, -170);
  moon.userData.alwaysVisible = true;
  g.add(moon);
  const moonHalo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowSprite("rgb(255,236,200)"), color: 0xffecc8,
    transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending,
    fog: false
  }));
  moonHalo.scale.setScalar(72);
  moonHalo.position.copy(moon.position);
  g.add(moonHalo);

  /* ---------------- water ---------------- */
  /* perf: the water plane was 150x150 segments on desktop — 45,000
     triangles resubmitted to the GPU every single frame for the entire
     journey (exterior AND interior/rooftop, since it's never culled by
     zone). The gentle vertex-shader ripple reads exactly as smooth at
     80x80 (12,800 tri, a ~3.5x cut) since the waves are broad/low-freq
     and the surface is almost always seen from a distance. */
  const waterGeo = new THREE.PlaneGeometry(900, 900, quality.mobile ? 48 : 80, quality.mobile ? 48 : 80);
  const waterMat = new THREE.ShaderMaterial({
    transparent: true,
    uniforms: {
      uTime:  { value: 0 },
      uDeep:  { value: new THREE.Color(0x0b1030) },
      uShallow:{ value: new THREE.Color(0x2a3f6b) },
      uGlow:  { value: new THREE.Color(0xffb877) },
      uWarm:  { value: 0.0 },
      uMoon:  { value: new THREE.Vector3(-120, 78, -170) }
    },
    vertexShader: `
      uniform float uTime;
      varying vec3 vWorld; varying float vWave;
      void main(){
        vec3 p = position;
        float w =
            sin(p.x * 0.055 + uTime * 0.62) * 0.55
          + sin(p.y * 0.041 - uTime * 0.48) * 0.42
          + sin((p.x + p.y) * 0.021 + uTime * 0.3) * 0.7;
        p.z += w;
        vWave = w;
        vec4 wp = modelMatrix * vec4(p,1.0);
        vWorld = wp.xyz;
        gl_Position = projectionMatrix * viewMatrix * wp;
      }`,
    fragmentShader: `
      uniform vec3 uDeep; uniform vec3 uShallow; uniform vec3 uGlow;
      uniform float uWarm; uniform float uTime;
      varying vec3 vWorld; varying float vWave;
      void main(){
        float d = length(vWorld.xz);
        float shore = smoothstep(90.0, 22.0, d);
        vec3 c = mix(uDeep, uShallow, shore * 0.85);
        // wave crests
        c += vec3(0.10,0.13,0.18) * smoothstep(0.5, 1.3, vWave);
        // moon path down the middle
        float path = exp(-pow((vWorld.x + 60.0) * 0.014, 2.0));
        c += vec3(0.35,0.33,0.28) * path * (0.35 + 0.3 * sin(vWorld.z * 0.09 + uTime));
        // warm light spilling from the house as the finale builds
        c += uGlow * uWarm * shore * 0.35;
        float a = 0.9 - smoothstep(240.0, 430.0, d) * 0.55;
        gl_FragColor = vec4(c, a);
      }`
  });
  const water = new THREE.Mesh(waterGeo, waterMat);
  water.rotation.x = -Math.PI / 2;
  water.position.y = -2.2;
  g.add(water);
  anim.water = waterMat;

  /* ---------------- island ----------------
     A single radial landform. The centre is a DEAD FLAT plateau at
     y = 0 (exactly the level the house is founded on), so the house
     can never look half-buried. Past the plateau it rolls down into
     a grassy bank, then a sand beach, then under the water.        */
  const PLATEAU = 15.5;      // flat lawn radius
  const BANK    = 20.5;      // grass rolls down to here
  const BEACH   = 26.0;      // sand meets the water around here
  const RIM     = 44.0;      // sea floor edge

  const ss = (a, b, x) => { const t = Math.max(0, Math.min(1, (x - a) / (b - a))); return t * t * (3 - 2 * t); };

  /** Height of the ground at a distance r from the centre of the island. */
  function groundY(r) {
    if (r <= PLATEAU) return 0;
    if (r <= BANK)  return -0.85 * ss(PLATEAU, BANK, r);
    if (r <= BEACH) return -0.85 - 1.95 * ss(BANK, BEACH, r);
    return -2.8 - 5.0 * ss(BEACH, RIM, r);
  }
  const groundAt = (x, z) => groundY(Math.hypot(x, z));

  const sandTex = noiseTexture(256, 0.4, 224);
  sandTex.repeat.set(10, 10);

  {
    const RINGS = 46, SEG = 96;
    const geo = new THREE.RingGeometry(0.02, RIM, SEG, RINGS);
    geo.rotateX(-Math.PI / 2);
    const pos = geo.attributes.position;
    const colors = new Float32Array(pos.count * 3);
    const grass = new THREE.Color(0x3c5b41);
    const grassDry = new THREE.Color(0x55613f);
    const sand = new THREE.Color(0x9c8763);
    const deep = new THREE.Color(0x453d33);
    const c = new THREE.Color();
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i), z = pos.getZ(i);
      const r = Math.hypot(x, z);
      // gentle undulation, but ONLY outside the plateau
      const rough = (Math.sin(x * 0.21) * Math.cos(z * 0.19) * 0.5 +
                     Math.sin(x * 0.07 + z * 0.11) * 0.8) * ss(PLATEAU, BANK + 2, r);
      pos.setY(i, groundY(r) + rough);
      // colour: lawn -> dry grass -> sand -> sea floor
      c.copy(grass).lerp(grassDry, ss(9, PLATEAU, r));
      c.lerp(sand, ss(PLATEAU + 1.5, BANK + 2.5, r));
      c.lerp(deep, ss(BEACH - 1, BEACH + 6, r));
      colors[i * 3] = c.r; colors[i * 3 + 1] = c.g; colors[i * 3 + 2] = c.b;
    }
    geo.setAttribute("color", new THREE.BufferAttribute(colors, 3));
    geo.computeVertexNormals();
    const island = new THREE.Mesh(geo, new THREE.MeshStandardMaterial({
      vertexColors: true, roughness: 1, bumpMap: sandTex, bumpScale: 0.05
    }));
    island.position.y = 0;                    // plateau === house ground level
    island.receiveShadow = quality.shadows;
    g.add(island);
    anim.groundAt = groundAt;
    anim.island = island;
  }

  /* ---------------- garden path ---------------- */
  const zF = DIM.D / 2;
  for (let i = 0; i < 16; i++) {
    const t = i / 15;
    const stone = new THREE.Mesh(
      roundedBox(1.6 - t * 0.35, 0.09, 1.05, 0.1, 1),
      M.stone
    );
    stone.position.set(Math.sin(t * 2.2) * 1.1, 0.05, zF + 3.0 + t * 11);
    stone.rotation.y = Math.sin(t * 3) * 0.18;
    stone.receiveShadow = quality.shadows;
    g.add(stone);
  }
  // path lanterns
  for (let i = 0; i < 6; i++) {
    const t = i / 5;
    const s = i % 2 ? 1 : -1;
    const post = new THREE.Mesh(
      turned([[0, 0], [0.11, 0], [0.08, 0.06], [0.05, 0.9], [0.09, 1.0], [0, 1.0]], 10),
      M.iron);
    const x = Math.sin(t * 2.2) * 1.1 + s * 2.1;
    const z = zF + 3.6 + t * 9.6;
    post.position.set(x, 0.02, z);
    g.add(post);
    const head = new THREE.Mesh(
      new THREE.BoxGeometry(0.28, 0.32, 0.28),
      new THREE.MeshStandardMaterial({
        color: 0xffd9a0, emissive: 0xffb163, emissiveIntensity: 1.4,
        roughness: 0.4, transparent: true, opacity: 0.92
      }));
    head.position.set(x, 1.16, z);
    g.add(head);
    const cap = new THREE.Mesh(new THREE.ConeGeometry(0.24, 0.16, 4), M.iron);
    cap.position.set(x, 1.4, z);
    cap.rotation.y = Math.PI / 4;
    g.add(cap);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowSprite("rgb(255,190,120)"), color: 0xffbe78,
      transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    halo.scale.setScalar(0.62);
    halo.position.set(x, 1.16, z);
    g.add(halo);
    anim.lanterns.push({ halo, seed: i * 1.3 });
  }

  /* =============================================================
     THE GARDEN — hedges, flower beds, blossom bushes, pots
     Everything here is low (under ~1.4 m) and lives OUTSIDE the
     lane the camera walks down, so the front of the house always
     reads clean.
     ============================================================= */
  const petalMats = [0xe86f8e, 0xf6c65b, 0xf3f0e6, 0xb98ce0, 0xef8b52, 0xff9fc0]
    .map(col => new THREE.MeshStandardMaterial({
      color: col, roughness: 0.62, emissive: col, emissiveIntensity: 0.22
    }));
  const stemMat = new THREE.MeshStandardMaterial({ color: 0x3f6b45, roughness: 0.9 });
  const hedgeMat = new THREE.MeshStandardMaterial({ color: 0x2f4a35, roughness: 1, flatShading: true });
  const bushMats = [0x35553c, 0x3e6244, 0x2c4733].map(col =>
    new THREE.MeshStandardMaterial({ color: col, roughness: 1, flatShading: true }));
  const soilMat = new THREE.MeshStandardMaterial({ color: 0x3a2c22, roughness: 1 });

  const flowerGeo = new THREE.SphereGeometry(0.075, 7, 6);
  const budGeo = new THREE.SphereGeometry(0.045, 6, 5);
  const stemGeo = new THREE.CylinderGeometry(0.014, 0.018, 1, 5);

  /** one little flower on a stem */
  function flower(x, y, z, h, mat, small) {
    const st = new THREE.Mesh(stemGeo, stemMat);
    st.position.set(x, y + h / 2, z);
    st.scale.y = h;
    g.add(st);
    const head = new THREE.Mesh(small ? budGeo : flowerGeo, mat);
    head.position.set(x, y + h + 0.03, z);
    g.add(head);
    // three petals around the head so it isn't just a ball
    if (!small) {
      for (let p = 0; p < 5; p++) {
        const a = (p / 5) * Math.PI * 2;
        const pet = new THREE.Mesh(budGeo, mat);
        pet.position.set(x + Math.cos(a) * 0.06, y + h + 0.015, z + Math.sin(a) * 0.06);
        pet.scale.set(1, 0.55, 1);
        g.add(pet);
      }
    }
  }

  /** a soil bed packed with flowers */
  function flowerBed(cx, cz, rx, rz, count, rot = 0) {
    const bed = new THREE.Mesh(
      new THREE.CylinderGeometry(1, 1, 0.16, 22), soilMat);
    bed.scale.set(rx, 1, rz);
    bed.rotation.y = rot;
    bed.position.set(cx, groundAt(cx, cz) + 0.06, cz);
    bed.receiveShadow = quality.shadows;
    g.add(bed);
    // stone kerb
    const kerb = new THREE.Mesh(new THREE.TorusGeometry(1, 0.07, 6, 26), M.stone);
    kerb.rotation.x = Math.PI / 2;
    kerb.rotation.z = rot;
    kerb.scale.set(rx, rz, 1);
    kerb.position.set(cx, groundAt(cx, cz) + 0.12, cz);
    g.add(kerb);
    for (let i = 0; i < count; i++) {
      const a = Math.random() * Math.PI * 2;
      const rr = Math.sqrt(Math.random()) * 0.86;
      const fx = cx + Math.cos(a) * rr * rx, fz = cz + Math.sin(a) * rr * rz;
      flower(fx, groundAt(fx, fz) + 0.1, fz,
        0.2 + Math.random() * 0.28,
        petalMats[(i + Math.floor(cx)) % petalMats.length],
        i % 4 === 0);
    }
  }

  /** a rounded blossoming bush */
  function bush(x, z, s = 1) {
    const y = groundAt(x, z);
    const base = new THREE.Mesh(new THREE.IcosahedronGeometry(0.55 * s, 1), bushMats[Math.floor(Math.random() * 3)]);
    base.position.set(x, y + 0.42 * s, z);
    base.scale.set(1, 0.82, 1);
    base.castShadow = quality.shadows;
    g.add(base);
    for (let i = 0; i < 2; i++) {
      const lobe = new THREE.Mesh(new THREE.IcosahedronGeometry(0.34 * s, 1), bushMats[i % 3]);
      lobe.position.set(x + (Math.random() - 0.5) * 0.7 * s, y + (0.3 + Math.random() * 0.4) * s, z + (Math.random() - 0.5) * 0.7 * s);
      g.add(lobe);
    }
    // blossoms dotted over it
    const n = 7;
    for (let i = 0; i < n; i++) {
      const a = (i / n) * Math.PI * 2 + Math.random();
      const rr = 0.42 * s;
      const b = new THREE.Mesh(budGeo, petalMats[i % petalMats.length]);
      b.position.set(x + Math.cos(a) * rr, y + 0.5 * s + (Math.random() - 0.3) * 0.35 * s, z + Math.sin(a) * rr);
      b.scale.setScalar(s);
      g.add(b);
    }
  }

  /** clipped hedge run */
  function hedge(x0, z0, x1, z1, h = 0.62, w = 0.6) {
    const len = Math.hypot(x1 - x0, z1 - z0);
    const seg = Math.max(2, Math.round(len / 0.9));
    for (let i = 0; i < seg; i++) {
      const t = (i + 0.5) / seg;
      const x = x0 + (x1 - x0) * t, z = z0 + (z1 - z0) * t;
      const b = new THREE.Mesh(roundedBox(len / seg + 0.06, h, w, 0.14, 1), hedgeMat);
      b.position.set(x, groundAt(x, z) + h / 2, z);
      b.rotation.y = Math.atan2(x1 - x0, z1 - z0) - Math.PI / 2;
      b.castShadow = quality.shadows;
      b.receiveShadow = quality.shadows;
      g.add(b);
    }
  }

  /** terracotta pot bursting with flowers */
  function flowerPot(x, z, s = 1) {
    const y = groundAt(x, z);
    const pot = new THREE.Mesh(
      turned([[0, 0], [0.22, 0], [0.24, 0.05], [0.28, 0.34], [0.31, 0.4], [0.27, 0.42], [0, 0.42]], 16),
      M.terracotta);
    pot.position.set(x, y, z);
    pot.scale.setScalar(s);
    pot.castShadow = quality.shadows;
    g.add(pot);
    for (let i = 0; i < 9; i++) {
      const a = (i / 9) * Math.PI * 2;
      const rr = 0.16 * s * (0.4 + Math.random() * 0.8);
      flower(x + Math.cos(a) * rr, y + 0.4 * s, z + Math.sin(a) * rr,
        (0.14 + Math.random() * 0.2) * s, petalMats[i % petalMats.length], false);
    }
  }

  // --- beds flanking the entrance steps ---
  flowerBed(-4.6, zF + 3.4, 1.5, 2.4, 26);
  flowerBed( 4.6, zF + 3.4, 1.5, 2.4, 26);
  flowerBed(-6.4, zF + 8.0, 1.9, 1.5, 22);
  flowerBed( 6.4, zF + 8.0, 1.9, 1.5, 22);
  // --- low hedges lining the walk, well outside the lane ---
  hedge(-3.4, zF + 2.6, -3.4, zF + 11.5);
  hedge( 3.4, zF + 2.6,  3.4, zF + 11.5);
  hedge(-9.2, zF + 1.0, -9.2, zF + 7.0, 0.7);
  hedge( 9.2, zF + 1.0,  9.2, zF + 7.0, 0.7);
  // --- beds hugging the front of the house ---
  flowerBed(-8.2, zF - 0.4, 2.3, 1.1, 24);
  flowerBed( 8.2, zF - 0.4, 2.3, 1.1, 24);
  // --- side gardens ---
  flowerBed(-10.6, -1.5, 1.3, 3.0, 24);
  flowerBed( 10.6, -1.5, 1.3, 3.0, 24);
  flowerBed(-6.0, -9.0, 2.6, 1.2, 22);
  flowerBed( 6.0, -9.0, 2.6, 1.2, 22);
  // --- pots on the porch steps ---
  [-2.15, 2.15].forEach(x => flowerPot(x, zF + 2.5, 1.0));
  [-3.1, 3.1].forEach(x => flowerPot(x, zF + 0.9, 0.85));
  // --- blossom bushes scattered down both flanks ---
  const bushSpots = [
    [-7.6, 12.2], [7.6, 12.4], [-11.2, 9.0], [11.0, 9.4], [-12.6, 4.2], [12.4, 4.6],
    [-12.8, -3.0], [12.8, -3.2], [-10.4, -7.4], [10.6, -7.8], [-6.2, -12.4], [6.4, -12.6],
    [-2.0, -12.8], [2.2, -13.0], [-14.0, 0.4], [14.0, 0.6], [-9.0, 15.0], [9.2, 15.2]
  ];
  bushSpots.forEach(([x, z], i) => bush(x, z, 0.85 + (i % 3) * 0.22));
  // --- wildflower drifts on the lawn edges ---
  for (let i = 0; i < 150; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 8 + Math.random() * 7.5;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    // keep the walk and the front lane clear
    if (z > 3 && Math.abs(x) < 4.6) continue;
    flower(x, groundAt(x, z), z, 0.16 + Math.random() * 0.22,
      petalMats[i % petalMats.length], i % 3 === 0);
  }

  /* ---------------- trees ---------------- */
  const treeCount = quality.mobile ? 16 : 34;
  const trunkMat = new THREE.MeshStandardMaterial({ color: 0x3d2c22, roughness: 0.95 });
  const foliageMats = [0x2f4a37, 0x3a5942, 0x27412f].map(c =>
    new THREE.MeshStandardMaterial({ color: c, roughness: 0.95, flatShading: true }));
  /* The camera flies straight in over the front lawn, then swings out
     to the left before returning to the door. Trees must never cross
     that corridor, so any candidate inside it is rejected. */
  const LANE = [
    [0, 46], [-3, 40], [2, 34], [0, 28], [-8, 22], [-11, 14], [-6, 14], [0, 13.5], [0, 10.5], [0, 8]
  ];
  function blocksCamera(x, z) {
    // 1. the whole front approach lane
    if (z > 2.5 && Math.abs(x) < 10.5) return true;
    // 2. a clear radius around every point the camera passes through
    for (const [lx, lz] of LANE) if (Math.hypot(x - lx, z - lz) < 6.5) return true;
    return false;
  }

  let placed = 0, guard = 0;
  while (placed < treeCount && guard++ < 600) {
    const a = Math.random() * Math.PI * 2;
    const r = 14 + Math.random() * 10;
    const x = Math.cos(a) * r, z = Math.sin(a) * r;
    if (blocksCamera(x, z)) continue;
    placed++;
    const i = placed;
    const h = 3.2 + Math.random() * 3.4;
    const t = new THREE.Group();
    const trunk = new THREE.Mesh(
      turned([[0, 0], [0.22, 0], [0.16, 0.4], [0.12, h * 0.6], [0.09, h], [0, h]], 8), trunkMat);
    t.add(trunk);
    const layers = 3;
    for (let L = 0; L < layers; L++) {
      const lr = (1 - L / layers) * 1.5 + 0.55;
      const cone = new THREE.Mesh(
        new THREE.ConeGeometry(lr, h * 0.5, 7),
        foliageMats[(i + L) % 3]);
      cone.position.y = h * (0.55 + L * 0.22);
      cone.rotation.y = L * 0.7;
      cone.castShadow = quality.shadows;
      t.add(cone);
    }
    t.position.set(x, groundAt(x, z) - 0.05, z);
    t.scale.setScalar(0.8 + Math.random() * 0.5);
    g.add(t);
  }

  /* ---------------- distant headlands ---------------- */
  const farMat = new THREE.MeshStandardMaterial({ color: 0x1d1930, roughness: 1, fog: true });
  for (let i = 0; i < 9; i++) {
    const a = (i / 9) * Math.PI * 2 + 0.9;
    const r = 210 + Math.random() * 90;
    const h = 16 + Math.random() * 26;
    const m = new THREE.Mesh(new THREE.ConeGeometry(24 + Math.random() * 22, h, 6), farMat);
    m.position.set(Math.cos(a) * r, h / 2 - 3, Math.sin(a) * r);
    m.rotation.y = Math.random();
    g.add(m);
  }

  /* ---------------- fireflies ---------------- */
  const fN = quality.mobile ? 70 : 190;
  const fPos = new Float32Array(fN * 3);
  const fPhase = new Float32Array(fN);
  const seeds = [];
  for (let i = 0; i < fN; i++) {
    const a = Math.random() * Math.PI * 2;
    const r = 8 + Math.random() * 16;
    fPos[i * 3] = Math.cos(a) * r;
    fPos[i * 3 + 1] = 0.6 + Math.random() * 9;
    fPos[i * 3 + 2] = Math.sin(a) * r;
    fPhase[i] = Math.random() * 6.28;
    seeds.push({ x: fPos[i * 3], y: fPos[i * 3 + 1], z: fPos[i * 3 + 2], s: Math.random() * 6.28 });
  }
  const fGeo = new THREE.BufferGeometry();
  fGeo.setAttribute("position", new THREE.BufferAttribute(fPos, 3));
  fGeo.setAttribute("aPhase", new THREE.BufferAttribute(fPhase, 1));
  const fMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: { uTime: { value: 0 } },
    vertexShader: `
      attribute float aPhase; uniform float uTime; varying float vB;
      void main(){
        vB = pow(0.5 + 0.5 * sin(uTime * 2.1 + aPhase), 2.5);
        vec3 p = position;
        p.x += sin(uTime * 0.42 + aPhase) * 1.5;
        p.y += sin(uTime * 0.63 + aPhase * 1.7) * 0.75;
        p.z += cos(uTime * 0.36 + aPhase) * 1.5;
        vec4 mv = modelViewMatrix * vec4(p,1.0);
        gl_PointSize = clamp((2.2 + 1.6 * vB) * (34.0 / -mv.z), 1.0, 9.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying float vB;
      void main(){
        float d = length(gl_PointCoord - 0.5);
        if (d > 0.5) discard;
        gl_FragColor = vec4(1.0, 0.86, 0.5, smoothstep(0.5, 0.0, d) * vB * 0.55);
      }`
  });
  const fireflies = new THREE.Points(fGeo, fMat);
  g.add(fireflies);
  anim.fireflies = { points: fireflies, mat: fMat, geo: fGeo, seeds };

  /* ---------------- chimney smoke ----------------
     A wisp from the chimney cap (world position fixed by Architecture:
     -W/2+1.5 , F2+0.95+0.1 , -D/2+1.6). Seven soft puffs, normal
     blending, barely there — the house is lived-in, not on fire. */
  {
    const SN = quality.mobile ? 5 : 8;
    const ORIGIN = [-5.0, 13.5, -3.9];
    const sPos = new Float32Array(SN * 3);
    const sPhase = new Float32Array(SN);
    const sSize = new Float32Array(SN);
    for (let i = 0; i < SN; i++) {
      sPos[i * 3] = ORIGIN[0];
      sPos[i * 3 + 1] = ORIGIN[1];
      sPos[i * 3 + 2] = ORIGIN[2];
      sPhase[i] = i / SN;                 // stagger along the plume
      sSize[i] = 0.55 + Math.random() * 0.5;
    }
    const sGeo = new THREE.BufferGeometry();
    sGeo.setAttribute("position", new THREE.BufferAttribute(sPos, 3));
    sGeo.setAttribute("aPhase", new THREE.BufferAttribute(sPhase, 1));
    sGeo.setAttribute("aSize", new THREE.BufferAttribute(sSize, 1));
    const sMat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false,
      uniforms: { uTime: { value: 0 } },
      vertexShader: `
        attribute float aPhase; attribute float aSize; uniform float uTime;
        varying float vA;
        void main(){
          float life = fract(uTime * 0.055 + aPhase);   // 0..1 up the plume
          vec3 p = position;
          p.y += life * 3.6;
          p.x += sin(life * 5.0 + aPhase * 6.28) * 0.28 + life * life * 1.15;
          p.z += cos(life * 4.2 + aPhase * 6.28) * 0.22;
          vA = smoothstep(0.0, 0.14, life) * (1.0 - smoothstep(0.45, 1.0, life));
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = clamp(aSize * (1.0 + life * 2.4) * (46.0 / -mv.z), 1.0, 34.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying float vA;
        void main(){
          float d = length(gl_PointCoord - 0.5) * 2.0;
          if (d > 1.0) discard;
          float a = pow(1.0 - d, 2.2) * vA * 0.115;
          gl_FragColor = vec4(0.62, 0.62, 0.70, a);
        }`
    });
    const smoke = new THREE.Points(sGeo, sMat);
    smoke.frustumCulled = false;
    smoke.userData.dynamic = true;
    g.add(smoke);
    anim.smoke = { points: smoke, mat: sMat };
  }

  /* ---------------- drifting confetti in the sky (finale) ----------------
     GPU particles: the whole fall + sway + loop-back cycle is a pure
     function of uTime, so it lives entirely in the vertex shader — the
     CPU never rewrites a position buffer for this (used to be a 90-220
     item JS loop, every frame, for the whole finale). */
  const cN = quality.mobile ? 90 : 220;
  const cPos = new Float32Array(cN * 3);   // base (x0, y0, z0)
  const cCol = new Float32Array(cN * 3);
  const cSeed = new Float32Array(cN);
  const cVy = new Float32Array(cN);
  const CONF_TOP = DIM.F2 + 16, CONF_BOTTOM = DIM.F2 - 2, CONF_SPAN = CONF_TOP - CONF_BOTTOM;
  const palette = [[1, .84, .55], [.89, .53, .60], [.62, .72, 1], [1, .95, .88], [.79, .54, .85]];
  for (let i = 0; i < cN; i++) {
    const a = Math.random() * Math.PI * 2, r = Math.random() * 14;
    cPos[i * 3] = Math.cos(a) * r;
    cPos[i * 3 + 1] = DIM.F2 + Math.random() * 16;
    cPos[i * 3 + 2] = Math.sin(a) * r;
    const c = palette[i % palette.length];
    cCol[i * 3] = c[0]; cCol[i * 3 + 1] = c[1]; cCol[i * 3 + 2] = c[2];
    cSeed[i] = Math.random() * 6.28;
    cVy[i] = 0.1 + Math.random() * 0.5;
  }
  const cGeo = new THREE.BufferGeometry();
  cGeo.setAttribute("position", new THREE.BufferAttribute(cPos, 3));
  cGeo.setAttribute("color", new THREE.BufferAttribute(cCol, 3));
  cGeo.setAttribute("aSeed", new THREE.BufferAttribute(cSeed, 1));
  cGeo.setAttribute("aVy", new THREE.BufferAttribute(cVy, 1));
  cGeo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, DIM.F2 + 6, 0), 40);
  let confMap = null;
  // photo-confetti: every falling piece carries a fragment of a photograph
  try {
    const base = window.BDAY_CONFIG.paths.photos;
    const hero = (window.BDAY_CONFIG.photos && window.BDAY_CONFIG.photos.hero) || "p17";
    confMap = getPhotoTexture(base + hero + "_sm.webp", 2);
  } catch (e) { /* plain confetti is fine too */ }
  const cMat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending, vertexColors: true,
    uniforms: {
      uTime: { value: 0 }, uAmt: { value: 0 }, uSize: { value: quality.mobile ? 40 : 55 },
      uMap: { value: confMap }, uHasMap: { value: confMap ? 1 : 0 },
      uTop: { value: CONF_TOP }, uBottom: { value: CONF_BOTTOM }, uSpan: { value: CONF_SPAN }
    },
    vertexShader: `
      attribute float aSeed; attribute float aVy;
      uniform float uTime; uniform float uSize; uniform float uTop; uniform float uBottom; uniform float uSpan;
      varying vec3 vColor; varying float vAmt;
      void main(){
        vColor = color;
        float rawY = position.y - aVy * uTime * 3.2;
        float y = mod(rawY - uBottom, uSpan) + uBottom;
        float x = position.x + sin(uTime * 1.2 + aSeed) * 1.4;
        float z = position.z + cos(uTime * 0.9 + aSeed) * 1.4;
        vec4 mv = modelViewMatrix * vec4(x, y, z, 1.0);
        gl_PointSize = clamp(uSize / -mv.z, 1.0, 34.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      uniform float uAmt; uniform sampler2D uMap; uniform float uHasMap;
      varying vec3 vColor;
      void main(){
        vec4 tex = uHasMap > 0.5 ? texture2D(uMap, gl_PointCoord) : vec4(1.0);
        float a = tex.a * uAmt * 0.95;
        if (a < 0.01) discard;
        gl_FragColor = vec4(vColor * tex.rgb, a);
      }`
  });
  const confetti = new THREE.Points(cGeo, cMat);
  confetti.frustumCulled = false;
  confetti.visible = false;
  confetti.userData.dynamic = true;
  g.add(confetti);
  anim.confetti = { points: confetti, mat: cMat, geo: cGeo };

  /* =============================================================
     FIREWORKS
     Every shell is baked into one Points cloud and animated purely
     in the vertex shader: rise, burst, drift, fade. The CPU does
     nothing per frame except move one uniform, so the rooftop can
     have a full sky of them without costing a single frame.
     ============================================================= */
  {
    const SHELLS = quality.mobile ? 9 : 16;
    const PER = quality.mobile ? 90 : 150;
    const N = SHELLS * PER;
    const pos = new Float32Array(N * 3);       // launch position
    const dir = new Float32Array(N * 3);       // burst direction * speed
    const col = new Float32Array(N * 3);
    const meta = new Float32Array(N * 3);      // phase, burstHeight, sparkSeed

    // deeply saturated, so additive blending still reads as a colour
    const palette = [
      [1.00, 0.42, 0.14], [1.00, 0.16, 0.42], [0.20, 0.55, 1.00],
      [0.72, 0.22, 1.00], [0.18, 1.00, 0.62], [1.00, 0.84, 0.16]
    ];
    for (let s = 0; s < SHELLS; s++) {
      const a = (s / SHELLS) * Math.PI * 2 + Math.random();
      const r = 14 + Math.random() * 22;
      const lx = Math.cos(a) * r, lz = Math.sin(a) * r * 0.8 - 4;
      const burst = 17 + Math.random() * 13;
      const phase = Math.random();
      const c = palette[s % palette.length];
      const c2 = palette[(s + 3) % palette.length];
      const spread = 2.6 + Math.random() * 2.4;
      for (let i = 0; i < PER; i++) {
        const k = (s * PER + i) * 3;
        pos[k] = lx; pos[k + 1] = 0; pos[k + 2] = lz;
        // even sphere of directions
        const u = Math.random() * 2 - 1;
        const th = Math.random() * Math.PI * 2;
        const sq = Math.sqrt(1 - u * u);
        const sp = spread * (0.45 + Math.random() * 0.55);
        dir[k] = sq * Math.cos(th) * sp;
        dir[k + 1] = u * sp;
        dir[k + 2] = sq * Math.sin(th) * sp;
        const mix = i / PER;
        col[k]     = c[0] * (1 - mix) + c2[0] * mix;
        col[k + 1] = c[1] * (1 - mix) + c2[1] * mix;
        col[k + 2] = c[2] * (1 - mix) + c2[2] * mix;
        meta[k] = phase;
        meta[k + 1] = burst;
        meta[k + 2] = Math.random();
      }
    }
    const geo = new THREE.BufferGeometry();
    geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
    geo.setAttribute("aDir", new THREE.BufferAttribute(dir, 3));
    geo.setAttribute("color", new THREE.BufferAttribute(col, 3));
    geo.setAttribute("aMeta", new THREE.BufferAttribute(meta, 3));
    geo.boundingSphere = new THREE.Sphere(new THREE.Vector3(0, 20, 0), 90);

    const mat = new THREE.ShaderMaterial({
      transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
      uniforms: { uTime: { value: 0 }, uAmt: { value: 0 }, uSize: { value: quality.mobile ? 2.6 : 3.2 } },
      vertexShader: `
        attribute vec3 aDir;
        attribute vec3 aMeta;
        uniform float uTime; uniform float uAmt; uniform float uSize;
        varying vec3 vCol; varying float vA;
        void main(){
          float cycle = 4.2;
          float t = fract(uTime / cycle + aMeta.x);
          float rise = smoothstep(0.0, 0.22, t);
          vec3 p = position;
          p.y += rise * aMeta.y;
          float burnA = 0.0;
          if (t < 0.22) {
            // the shell climbing: every particle sits on the same point
            burnA = smoothstep(0.0, 0.05, t) * 0.85;
          } else {
            float te = (t - 0.22) / 0.78;
            p += aDir * (te * 2.9) * (1.0 - te * 0.3);
            p.y -= te * te * 4.5;                        // gravity
            p += aDir * sin(te * 7.0 + aMeta.z * 6.28) * 0.12;
            burnA = pow(1.0 - te, 2.0) * (0.55 + 0.45 * sin(te * 30.0 + aMeta.z * 20.0));
          }
          vCol = color;
          vA = clamp(burnA, 0.0, 1.0) * uAmt;
          vec4 mv = modelViewMatrix * vec4(p, 1.0);
          gl_PointSize = clamp(uSize * (100.0 / max(1.0, -mv.z)) * (t < 0.22 ? 1.7 : 1.0), 1.2, 13.0);
          gl_Position = projectionMatrix * mv;
        }`,
      fragmentShader: `
        varying vec3 vCol; varying float vA;
        void main(){
          float d = length(gl_PointCoord - 0.5);
          if (d > 0.5) discard;
          float a = smoothstep(0.5, 0.0, d) * vA;
          if (a < 0.01) discard;
          gl_FragColor = vec4(vCol * 1.15, a);
        }`
    });
    mat.vertexColors = true;
    const fw = new THREE.Points(geo, mat);
    fw.frustumCulled = false;
    fw.userData.dynamic = true;
    fw.visible = false;
    g.add(fw);
    anim.fireworks = { points: fw, mat };
  }

  return { group: g, anim, water };
}
