/* =============================================================
   MATERIAL LIBRARY
   Physically-plausible, varied roughness. Nothing is shiny plastic.
   Created once, shared everywhere (keeps draw calls & memory sane).
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { noiseTexture, woodTexture } from "./geometry.js";

export function buildMaterials(quality) {
  const plaster = noiseTexture(512, 0.35, 232);
  plaster.repeat.set(5, 5);
  const woodMap = woodTexture(512);
  woodMap.repeat.set(2, 2);
  const floorMap = woodTexture(512, "#7a5236", "#5b3a25");
  floorMap.repeat.set(6, 6);
  const fabricMap = noiseTexture(256, 0.6, 200);
  fabricMap.repeat.set(4, 4);

  /* perf: MeshStandardMaterial runs a full roughness/metalness PBR (GGX)
     lighting model per fragment, for every one of the up to ~7-11 active
     point lights at once — the single most expensive thing a mobile GPU
     does in this scene, and it's what almost every wall/floor/wood/fabric
     surface used, everywhere, all the time. On mobile we swap all the
     large-area "plain diffuse" surfaces to MeshLambertMaterial, which
     keeps the same color/map/bumpMap/emissive look but replaces the PBR
     BRDF with a cheap N·L sum — a large, direct cut to per-pixel cost on
     every one of those surfaces, with no change to draw calls or
     triangle count. Small specular bits (brass/iron/glass) stay as they
     were: little screen area, little to save, and they read better lit. */
  function surface(opts) {
    if (quality.mobile) {
      const { roughness, metalness, roughnessMap, ...rest } = opts;
      return new THREE.MeshLambertMaterial(rest);
    }
    return new THREE.MeshStandardMaterial(opts);
  }

  const M = {
    // ---- architecture ----
    wallExt: surface({
      color: 0xe9dcc8, roughness: 0.94, metalness: 0,
      roughnessMap: plaster, bumpMap: plaster, bumpScale: 0.012
    }),
    wallInt: surface({
      color: 0xf6ebda, roughness: 0.96, metalness: 0,
      roughnessMap: plaster, bumpMap: plaster, bumpScale: 0.008
    }),
    wallAccent: surface({
      color: 0x6d4a5e, roughness: 0.9, metalness: 0, roughnessMap: plaster
    }),
    trim: surface({ color: 0xfaf1e4, roughness: 0.55, metalness: 0 }),
    roofTile: surface({
      color: 0x8a4356, roughness: 0.74, metalness: 0.04, bumpMap: plaster, bumpScale: 0.02
    }),
    roofEdge: surface({ color: 0x5f2f3e, roughness: 0.66 }),
    stone: surface({
      color: 0x4d4152, roughness: 0.98, bumpMap: plaster, bumpScale: 0.03
    }),

    // ---- wood family (three distinct tones) ----
    woodDark: surface({ color: 0x4e3524, roughness: 0.78, map: woodMap }),
    woodWarm: surface({ color: 0x8a6242, roughness: 0.7, map: woodMap }),
    floor: surface({ color: 0x9a6c47, roughness: 0.62, map: floorMap }),
    floorUpper: surface({ color: 0x8b6a52, roughness: 0.68, map: floorMap }),

    // ---- metals ----
    brass: new THREE.MeshStandardMaterial({ color: 0xd6a860, roughness: 0.3, metalness: 0.85 }),
    brassDark: new THREE.MeshStandardMaterial({ color: 0x8c6a3a, roughness: 0.45, metalness: 0.8 }),
    iron: new THREE.MeshStandardMaterial({ color: 0x2e2a33, roughness: 0.55, metalness: 0.6 }),

    // ---- glass ----
    glassPane: new THREE.MeshPhysicalMaterial({
      color: 0xdfe9f2, roughness: 0.08, metalness: 0, transmission: quality.transmission ? 0.82 : 0,
      transparent: true, opacity: quality.transmission ? 1 : 0.28,
      thickness: 0.2, ior: 1.45, side: THREE.DoubleSide
    }),
    glassLit: new THREE.MeshStandardMaterial({
      color: 0xffd9a4, emissive: 0xffb063, emissiveIntensity: 1.1,
      roughness: 0.22, transparent: true, opacity: 0.9
    }),
    // what you see through a window from INSIDE at night
    nightPane: new THREE.MeshStandardMaterial({
      color: 0x141c33, emissive: 0x2b3c69, emissiveIntensity: 0.55,
      roughness: 0.25, metalness: 0.1, side: THREE.DoubleSide
    }),
    curtain: surface({
      color: 0xe6d3bb, roughness: 1, bumpMap: fabricMap, bumpScale: 0.03
    }),

    // ---- soft goods ----
    fabricRose: surface({ color: 0xa85a72, roughness: 1, bumpMap: fabricMap, bumpScale: 0.02 }),
    fabricCream: surface({ color: 0xe8d8c0, roughness: 1, bumpMap: fabricMap, bumpScale: 0.02 }),
    rug: surface({ color: 0x7b4257, roughness: 1, bumpMap: fabricMap, bumpScale: 0.05 }),

    // ---- cake & food ----
    frosting: surface({ color: 0xfdf0e0, roughness: 0.52, metalness: 0 }),
    frostingPink: surface({ color: 0xf3c3ce, roughness: 0.5 }),
    sponge: surface({ color: 0xc98f5e, roughness: 0.85 }),
    ceramic: surface({ color: 0xf7f2ea, roughness: 0.18, metalness: 0.02 }),

    // ---- decoration ----
    ribbon: surface({ color: 0xf6e3c6, roughness: 0.42, metalness: 0.1 }),
    leaf: surface({ color: 0x3f6b4a, roughness: 0.85, side: THREE.DoubleSide }),
    terracotta: surface({ color: 0xa8593c, roughness: 0.88 }),

    // ---- emissive helpers ----
    emitWarm: new THREE.MeshBasicMaterial({ color: 0xffe6bb, toneMapped: false }),
    // candle flame: tone mapping off, so it stays a bright hot core
    emitFlame: new THREE.MeshBasicMaterial({ color: 0xfff0c8, toneMapped: false }),
    emitFlameCore: new THREE.MeshBasicMaterial({ color: 0xffffff, toneMapped: false }),

    // ---- photo frames ----
    frameGold: new THREE.MeshStandardMaterial({ color: 0xc9a267, roughness: 0.42, metalness: 0.55 }),
    frameWood: surface({ color: 0x6a4630, roughness: 0.62, map: woodMap }),
    frameCream: surface({ color: 0xf2e6d2, roughness: 0.5 }),
    mat: surface({ color: 0xfbf4e8, roughness: 0.9 }),
    backing: surface({ color: 0x2a2029, roughness: 1 })
  };

  // balloon set — slight sheen, never mirror-like
  M.balloons = [0xe4869a, 0xf3c98b, 0x9fb8ff, 0xc98ad8, 0xfdf0e0, 0x8fd0c0].map(c =>
    surface({
      color: c, roughness: 0.26, metalness: 0.02,
      emissive: c, emissiveIntensity: 0.07
    })
  );

  // gift wrap set
  M.gifts = [0xb3546e, 0x4a6ba8, 0xd39a52, 0x6a4a86, 0x3f7a6a].map(c =>
    surface({ color: c, roughness: 0.66, metalness: 0.05 })
  );


  M.dispose = () => Object.values(M).forEach(m => {
    if (Array.isArray(m)) m.forEach(x => x.dispose && x.dispose());
    else if (m && m.dispose) m.dispose();
  });

  return M;
}
