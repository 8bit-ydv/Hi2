/* =============================================================
   THE CAKE CEREMONY
   A scroll-driven set piece on the ground floor. Every beat is
   pinned to its own camera key, so what you read and what you see
   can never drift apart:

     1. CANDLES  wax candles grow out of the frosting
     2. TWENTY   the big "20" number candle rises on the top tier
     3. LIT      every wick catches, the room glows
     4. WISH     the room dims, the flames stand tall and still
     5. BLOW     they bend, gutter, go out — smoke curls up
     6. CUT      the knife comes down and opens the cake
     7. SLICE    a slice lifts out onto a plate

   Everything is a pure function of scroll progress, so scrubbing
   backwards replays it perfectly in reverse. No timers, no state
   that can desync from the scrollbar.
   ============================================================= */

/** The scroll window the whole ceremony occupies. */
export function ceremonyRange(tAt) {
  return { start: tAt("cake-approach"), end: tAt("gifts") };
}

export function createCeremony(cake, opts = {}) {
  const D = cake.userData;
  const { onBlown, cakeLight, tAt } = opts;

  // resting transforms we interpolate away from
  const knifeRest = D.knife.position.clone();
  const knifeRestRot = D.knife.rotation.z;
  const sliceRest = D.slice.position.clone();

  D.smokes.forEach(s => { s.userData.lift = 0; });

  /* ---- each beat runs from one camera key to the next, so the
          animation always finishes exactly when the camera lands ---- */
  const BEATS = {
    candles: ["cake-approach", "cake-candles"],
    number:  ["cake-candles",  "cake-number"],
    light:   ["cake-number",   "cake-lit"],
    wish:    ["cake-lit",      "cake-wish"],
    blow:    ["cake-wish",     "cake-blow"],
    cut:     ["cake-blow",     "cake-cut"],
    slice:   ["cake-cut",      "cake-slice"]
  };
  const R = {};
  Object.keys(BEATS).forEach(k => {
    R[k] = [tAt(BEATS[k][0]), tAt(BEATS[k][1])];
  });
  const at = k => R[k];
  const stage = (k, p) => seg(p, at(k)[0], at(k)[1]);

  let blownFired = false;

  /**
   * @param {number} p   overall house scroll progress (0-1)
   * @param {number} t   elapsed seconds (for flicker/drift)
   */
  function update(p, t) {
    const grow  = stage("candles", p);
    const num   = stage("number", p);
    const light = stage("light", p);
    const wish  = stage("wish", p);
    const blow  = stage("blow", p);
    const cut   = stage("cut", p);
    const slice = stage("slice", p);

    /* ---------- 1. the candles grow out of the cake ---------- */
    for (let i = 0; i < D.candleGroups.length; i++) {
      const c = D.candleGroups[i];
      // staggered, with a tiny overshoot so they "pop" up one by one
      const d = i / Math.max(1, D.candleGroups.length);
      const s = seg(grow, d * 0.55, 0.55 + d * 0.45);
      const over = 1 + Math.sin(Math.min(1, s) * Math.PI) * 0.14;
      c.scale.y = Math.max(0.001, s * over);
      c.visible = s > 0.01;
    }

    /* ---------- 2. the "20" rises on the top tier ---------- */
    if (D.numeral) {
      const s = num;
      const over = 1 + Math.sin(Math.min(1, s) * Math.PI) * 0.16;
      D.numeral.scale.setScalar(Math.max(0.001, s * over));
      D.numeral.rotation.y = (1 - s) * 0.7;
      D.numeral.visible = s > 0.01;
    }

    /* ---------- 3-5. flames: catch, stand tall, blow out ---------- */
    const flameLife = Math.max(0, light - blow);
    for (let i = 0; i < D.flames.length; i++) {
      const f = D.flames[i];
      const s = f.userData.seed;
      const base = f.userData.baseScale || 1;

      // wicks catch one after another
      const catchUp = seg(light, (i / D.flames.length) * 0.6, 0.5 + (i / D.flames.length) * 0.5);
      const life = Math.max(0, catchUp - blow);

      const w = Math.sin(t * 6.1 + s) * 0.5 + Math.sin(t * 11.3 + s * 2) * 0.28;
      const bend = blow * (1 - blow) * 4;          // peaks mid-blow
      const gust = Math.sin(t * 26 + s) * bend * 0.5;

      const sx = (1 + w * 0.07 + gust * 0.5) * life;
      const sy = (1.9 + w * 0.2 + bend * 1.4) * life * (1 + wish * 0.3);
      f.scale.set(Math.max(0.0001, sx * base), Math.max(0.0001, sy * base), Math.max(0.0001, sx * base));
      f.position.y = f.userData.baseY + w * 0.004 + bend * 0.02;
      f.visible = life > 0.02;

      const h = D.halos[i];
      if (h) {
        h.material.opacity = (0.5 + Math.sin(t * 5.4 + i) * 0.12) * life * (1 + wish * 0.45);
        h.visible = life > 0.02;
        h.scale.setScalar((0.52 * base) * (1 + wish * 0.25 + bend * 0.4));
      }
    }

    /* ---------- smoke ---------- */
    for (let i = 0; i < D.smokes.length; i++) {
      const sm = D.smokes[i];
      const s = sm.userData.seed;
      const life = Math.max(0, Math.min(1, (blow - 0.3) / 0.7));
      const fade = 1 - Math.max(0, (cut - 0.2) / 0.8);
      sm.material.opacity = life * 0.45 * fade;
      sm.visible = sm.material.opacity > 0.01;
      sm.position.y = sm.userData.baseY + life * 0.34 + Math.sin(t * 0.9 + s) * 0.02;
      sm.rotation.z = Math.sin(t * 0.7 + s) * 0.3;
      sm.scale.set(1 + life * 0.8, 1 + life * 1.6, 1);
    }

    /* ---------- 6. the cutting ---------- */
    const k = D.knife;
    k.visible = cut > 0.02 && slice < 0.98;
    if (k.visible) {
      // enters from the right, swings down, sinks into the cake, withdraws
      const enter = seg(cut, 0.00, 0.35);
      const down  = seg(cut, 0.30, 0.85);
      const lift  = seg(slice, 0.10, 0.75);
      k.position.x = knifeRest.x + (1 - enter) * 0.9;
      // all the way down through the tiers, not hovering over them
      k.position.y = knifeRest.y - down * 1.45 + lift * 1.25;
      k.position.z = knifeRest.z * (1 - down * 0.45);
      k.rotation.z = knifeRestRot * (1 - down * 0.85) + lift * 0.4;
      const gone = seg(slice, 0.7, 0.98);
      k.scale.setScalar(Math.max(0.001, 1 - gone));
    }

    /* ---------- 7. the slice ---------- */
    const out = slice;
    D.gap.visible = out > 0.02;
    D.slice.visible = out > 0.02;
    D.plate.visible = out > 0.25;
    if (D.slice.visible) {
      // lifts, rotates out and settles ONTO the plate — exiting along the
      // wedge's own yaw (0.32 rad, facing the ceremony camera), so the
      // slice never clips through the cake wall on its way out.
      // The old path ended ~0.4 m above the plate (a floating slice); the
      // group now drops to y = plateTop − sliceBottom so the slice visibly
      // comes to rest on the plate, with a lift arc on the way.
      const plateX = 0.42, plateZ = 1.26;
      const landY = 0.02 - (D.baseTier.y - D.baseTier.h / 2);   // plate top − slice bottom
      D.slice.position.set(
        sliceRest.x + plateX * out,
        landY * out + Math.sin(out * Math.PI) * 0.55,
        sliceRest.z + plateZ * out
      );
      D.slice.rotation.y = 0.32 + out * 0.7;
      D.slice.rotation.z = out * 0.18;
    }
    if (D.plate.visible) {
      const pp = seg(out, 0.25, 0.5);
      D.plate.scale.setScalar(0.5 + pp * 0.5);
    }

    /* ---------- lighting through the ceremony ---------- */
    if (cakeLight) {
      // swells as the wicks catch, peaks on the wish, drops when blown,
      // warms back for the cut
      const l = 0.75 + light * 0.7 + wish * 0.9 - blow * 1.35 + cut * 0.5 + slice * 0.3;
      cakeLight.userData.ceremonyScale = Math.max(0.18, l);
    }

    /* ---------- one-shot: the moment they go out ---------- */
    if (!blownFired && blow > 0.85) {
      blownFired = true;
      if (onBlown) onBlown();
    } else if (blownFired && blow < 0.5) {
      blownFired = false;      // allow replay when scrubbing back
    }

    return { grow, num, light, wish, blow, cut, slice };
  }

  return { update, ranges: R };
}

/** smoothstep-normalised sub-range helper */
function seg(x, a, b) {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
