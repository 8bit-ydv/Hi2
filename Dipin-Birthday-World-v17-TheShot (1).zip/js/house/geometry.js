/* =============================================================
   GEOMETRY HELPERS
   Bevelled/rounded primitives so nothing reads as a raw cube.
   All geometries are created once and reused where possible.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";

/** Rounded box via extruded rounded rectangle — gives real bevelled edges. */
export function roundedBox(w, h, d, r = 0.06, smooth = 2) {
  r = Math.min(r, w / 2 - 0.001, h / 2 - 0.001, d / 2 - 0.001);
  const shape = new THREE.Shape();
  const x = -w / 2, y = -h / 2;
  shape.moveTo(x, y + r);
  shape.lineTo(x, y + h - r);
  shape.quadraticCurveTo(x, y + h, x + r, y + h);
  shape.lineTo(x + w - r, y + h);
  shape.quadraticCurveTo(x + w, y + h, x + w, y + h - r);
  shape.lineTo(x + w, y + r);
  shape.quadraticCurveTo(x + w, y, x + w - r, y);
  shape.lineTo(x + r, y);
  shape.quadraticCurveTo(x, y, x, y + r);

  const g = new THREE.ExtrudeGeometry(shape, {
    depth: d - r * 2, bevelEnabled: true,
    bevelThickness: r, bevelSize: r, bevelSegments: smooth, curveSegments: smooth + 2
  });
  g.translate(0, 0, -(d - r * 2) / 2);
  g.computeVertexNormals();
  return g;
}

/** A flat panel with softened edges — walls, shelves, treads. */
export function panel(w, h, d, r = 0.03) {
  return roundedBox(w, h, d, r, 1);
}

/** Simple lathe-turned profile: balusters, lamp stems, table legs. */
export function turned(profile, segments = 14) {
  const pts = profile.map(([x, y]) => new THREE.Vector2(x, y));
  const g = new THREE.LatheGeometry(pts, segments);
  g.computeVertexNormals();
  return g;
}

/** Torus-knot free ribbon: a gentle catenary tube for string lights/garlands. */
export function catenary(from, to, sag, seg = 22, radius = 0.012) {
  const pts = [];
  for (let i = 0; i <= seg; i++) {
    const t = i / seg;
    const p = new THREE.Vector3().lerpVectors(from, to, t);
    p.y -= Math.sin(Math.PI * t) * sag;
    pts.push(p);
  }
  const curve = new THREE.CatmullRomCurve3(pts);
  return { geometry: new THREE.TubeGeometry(curve, seg, radius, 5, false), curve };
}

/** Text drawn to a canvas texture — signage, banners, plaques. */
export function textTexture(text, opts = {}) {
  const {
    w = 1024, h = 256,
    font = "600 130px 'Cormorant Garamond', Georgia, serif",
    color = "#fff3de", letter = 10, glow = "#ffb066", glowBlur = 24,
    bg = null, align = "center"
  } = opts;
  const cv = document.createElement("canvas");
  cv.width = w; cv.height = h;
  const g = cv.getContext("2d");
  if (bg) { g.fillStyle = bg; g.fillRect(0, 0, w, h); }
  g.font = font;
  g.textAlign = align;
  g.textBaseline = "middle";
  if ("letterSpacing" in g) g.letterSpacing = letter + "px";
  // fit to width
  let m = g.measureText(text);
  if (m.width > w * 0.92) {
    const scale = (w * 0.92) / m.width;
    const size = parseFloat(font.match(/(\d+(\.\d+)?)px/)[1]) * scale;
    g.font = font.replace(/(\d+(\.\d+)?)px/, size.toFixed(0) + "px");
  }
  if (glow) { g.shadowColor = glow; g.shadowBlur = glowBlur; }
  g.fillStyle = color;
  g.fillText(text, align === "left" ? w * 0.04 : w / 2, h / 2 + 4);
  g.shadowBlur = 0;
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  t.needsUpdate = true;
  return t;
}

/** Procedural fabric/plaster normal-ish roughness map (cheap, no downloads). */
export function noiseTexture(size = 256, contrast = 0.5, tint = 210) {
  const cv = document.createElement("canvas");
  cv.width = cv.height = size;
  const g = cv.getContext("2d");
  const img = g.createImageData(size, size);
  for (let i = 0; i < size * size; i++) {
    const n = 1 - Math.random() * contrast;
    const v = tint * n;
    img.data[i * 4] = img.data[i * 4 + 1] = img.data[i * 4 + 2] = v;
    img.data[i * 4 + 3] = 255;
  }
  g.putImageData(img, 0, 0);
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  return t;
}

/** Wood grain strip texture — floors, treads, furniture. */
export function woodTexture(size = 512, base = "#6b4a33", grain = "#553826") {
  const cv = document.createElement("canvas");
  cv.width = cv.height = size;
  const g = cv.getContext("2d");
  g.fillStyle = base; g.fillRect(0, 0, size, size);
  for (let i = 0; i < 240; i++) {
    g.strokeStyle = grain;
    g.globalAlpha = 0.04 + Math.random() * 0.1;
    g.lineWidth = 0.6 + Math.random() * 2.4;
    g.beginPath();
    const y = Math.random() * size;
    g.moveTo(0, y);
    g.bezierCurveTo(size * .3, y + (Math.random() - .5) * 22, size * .7, y + (Math.random() - .5) * 22, size, y + (Math.random() - .5) * 10);
    g.stroke();
  }
  // plank seams
  g.globalAlpha = .5;
  g.strokeStyle = "rgba(0,0,0,.45)";
  g.lineWidth = 2;
  for (let i = 1; i < 6; i++) {
    g.beginPath(); g.moveTo(0, (size / 6) * i); g.lineTo(size, (size / 6) * i); g.stroke();
  }
  g.globalAlpha = 1;
  const t = new THREE.CanvasTexture(cv);
  t.wrapS = t.wrapT = THREE.RepeatWrapping;
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}

/** Soft radial sprite used for glows, bulbs and candle halos. */
export function glowSprite(color = "#ffbe72", size = 128) {
  const cv = document.createElement("canvas");
  cv.width = cv.height = size;
  const g = cv.getContext("2d");
  const grd = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  grd.addColorStop(0, color);
  grd.addColorStop(0.35, color.replace(")", ",.55)").replace("rgb", "rgba"));
  grd.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = grd;
  g.fillRect(0, 0, size, size);
  const t = new THREE.CanvasTexture(cv);
  t.colorSpace = THREE.SRGBColorSpace;
  return t;
}
