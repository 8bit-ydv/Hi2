/* =============================================================
   ARCHITECTURE
   The same birthday house, rebuilt properly:
     ground floor · upper floor · rooftop terrace
   Real wall thickness, trims, sills, a pitched roof over a
   terrace bay, a proper staircase with landings, railings and
   balconies.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { roundedBox, panel, turned, textTexture } from "./geometry.js";

/* ---- house dimensions (metres) — one source of truth ---- */
export const DIM = {
  W: 13,          // width  (x)
  D: 11,          // depth  (z)
  T: 0.34,        // wall thickness
  F0: 0.0,        // ground floor level
  H0: 4.6,        // ground floor ceiling height
  F1: 4.9,        // upper floor level
  H1: 4.2,        // upper floor ceiling height
  FW: 8.88,       // the room of wishes (a new floor, upper→roof)
  F2: 12.3,       // rooftop terrace level
  DOOR_W: 2.6,
  DOOR_H: 3.5,
  STAIR_X: -3.9,  // staircase runs along the left side
  BAY_W: 4.4      // balcony opening on the upper floor
};

/* ---- walking levels, shared with the camera rig ---- */
export const LEVEL = {
  G: 0.63,            // ground floor deck top
  U: DIM.F1 + 0.08,   // upper floor deck top
  W: DIM.FW + 0.08,   // the room of wishes, deck top
  R: DIM.F2 + 0.11    // roof deck top
};

/* ---- the staircase, described once so the camera can follow it ---- */
export const STAIR = {
  x: DIM.STAIR_X,
  width: 2.5,
  // flight 1 : ground -> upper, walks toward -Z
  f1: { y0: LEVEL.G, y1: LEVEL.U, z0: 3.8, z1: -2.6, steps: 15 },
  // flight 2 : upper -> the room of wishes, walks back toward +Z
  f2: { y0: LEVEL.U, y1: LEVEL.W, z0: -2.6, z1: 1.9, steps: 14 },
  // flight 3 : wishes -> rooftop, a switchback toward -Z (into the darkroom)
  f3: { y0: LEVEL.W, y1: LEVEL.R, z0: 1.9, z1: -2.6, steps: 13 }
};
/** Height of a flight at a given z (used to keep the camera on the steps). */
export function stairY(f, z) {
  const t = Math.max(0, Math.min(1, (z - f.z0) / (f.z1 - f.z0)));
  return f.y0 + (f.y1 - f.y0) * t;
}

/* ---- holes cut in each deck so the stair (and the camera) can pass ---- */
const VOID_F1 = { x0: -6.35, x1: -1.65, z0: -2.6, z1: 5.3 };
const VOID_FW = { x0: -6.35, x1: -1.65, z0: -2.8, z1: 2.35 };   // open over flight 2
const VOID_F2 = { x0: -6.35, x1: -1.65, z0: -3.2, z1: 2.45 };   // open over flight 3

export function buildArchitecture(scene, M, quality) {
  const { W, D, T, H0, F1, H1, FW, F2, DOOR_W, DOOR_H, BAY_W } = DIM;
  const group = new THREE.Group();
  scene.add(group);

  const add = (mesh, cast = true, receive = true) => {
    mesh.castShadow = cast && quality.shadows;
    mesh.receiveShadow = receive;
    group.add(mesh);
    return mesh;
  };

  /* ---------- plinth / foundation ---------- */
  add(new THREE.Mesh(roundedBox(W + 1.1, 0.55, D + 1.1, 0.06, 1), M.stone))
    .position.set(0, 0.275, 0);
  add(new THREE.Mesh(roundedBox(W + 1.5, 0.16, D + 1.5, 0.05, 1), M.stone))
    .position.set(0, 0.08, 0);

  /* ---------- floor slabs (with a stairwell void) ----------
     Each upper deck is built from four boards around a rectangular
     opening so the staircase — and the camera — can pass through. */
  const solidSlab = (y, mat, th = 0.16) => {
    const s = new THREE.Mesh(new THREE.BoxGeometry(W - T * 1.4, th, D - T * 1.4), mat);
    s.position.set(0, y, 0);
    return add(s, false, true);
  };

  const slabWithVoid = (y, mat, th, VOID) => {
    const iwv = W - T * 1.4, idv = D - T * 1.4;
    const x0 = -iwv / 2, x1 = iwv / 2, z0 = -idv / 2, z1 = idv / 2;
    const vx0 = Math.max(x0, VOID.x0), vx1 = Math.min(x1, VOID.x1);
    const vz0 = Math.max(z0, VOID.z0), vz1 = Math.min(z1, VOID.z1);
    const board = (bx0, bx1, bz0, bz1) => {
      const w = bx1 - bx0, d = bz1 - bz0;
      if (w <= 0.01 || d <= 0.01) return;
      const m = new THREE.Mesh(new THREE.BoxGeometry(w, th, d), mat);
      m.position.set((bx0 + bx1) / 2, y, (bz0 + bz1) / 2);
      add(m, false, true);
    };
    board(x0, vx0, z0, z1);      // left of the void
    board(vx1, x1, z0, z1);      // right of the void
    board(vx0, vx1, z0, vz0);    // behind the void
    board(vx0, vx1, vz1, z1);    // in front of the void
  };

  solidSlab(0.55, M.floor);                    // ground floor deck
  slabWithVoid(F1, M.floorUpper, 0.16, VOID_F1);  // upper floor, open over flight 1
  slabWithVoid(FW, M.floorUpper, 0.16, VOID_FW);  // room of wishes, open over flight 2
  slabWithVoid(F2, M.stone, 0.22, VOID_F2);       // terrace, open over flight 3

  // ceiling underside of each level (so interiors feel enclosed)
  slabWithVoid(F1 - 0.12, M.wallInt, 0.06, VOID_F1);
  slabWithVoid(FW - 0.14, M.wallInt, 0.06, VOID_FW);
  slabWithVoid(F2 - 0.14, M.wallInt, 0.06, VOID_F2);

  /* ---------- wall builder with real thickness ---------- */
  function wall(w, h, d, x, y, z, ext = M.wallExt) {
    const m = new THREE.Mesh(roundedBox(w, h, d, 0.02, 1), ext);
    m.position.set(x, y, z);
    return add(m);
  }

  /* ---------- interior skin ----------
     Four inward-facing plaster panels instead of one closed box, so
     the doorway and the balcony bay are REAL openings from inside as
     well as outside. (The old box turned every opening into a blank
     white slab — which is what made a window read as an empty frame.) */
  const iw = W - T * 2.1, id = D - T * 2.1;

  function skinPanel(w, h, cx, cy, cz, ry, hole) {
    const shape = new THREE.Shape();
    shape.moveTo(-w / 2, -h / 2);
    shape.lineTo(w / 2, -h / 2);
    shape.lineTo(w / 2, h / 2);
    shape.lineTo(-w / 2, h / 2);
    shape.lineTo(-w / 2, -h / 2);
    if (hole) {
      const p = new THREE.Path();
      const hw = hole.w / 2, y0 = hole.y0, y1 = hole.y1;
      p.moveTo(hole.x - hw, y0);
      p.lineTo(hole.x + hw, y0);
      p.lineTo(hole.x + hw, y1);
      p.lineTo(hole.x - hw, y1);
      p.lineTo(hole.x - hw, y0);
      shape.holes.push(p);
    }
    const geo = new THREE.ShapeGeometry(shape);
    const m = new THREE.Mesh(geo, M.wallInt);
    m.position.set(cx, cy, cz);
    m.rotation.y = ry;
    m.receiveShadow = true;
    group.add(m);
    return m;
  }

  // a level's four walls, front wall optionally pierced
  function level(baseY, height, opts = {}) {
    const yMid = baseY + height / 2;
    // back
    wall(W, height, T, 0, yMid, -D / 2 + T / 2);
    // sides
    wall(T, height, D - T * 2, -W / 2 + T / 2, yMid, 0);
    wall(T, height, D - T * 2,  W / 2 - T / 2, yMid, 0);

    let hole = null;
    if (opts.doorway) {
      const side = (W - DOOR_W) / 2;
      wall(side, height, T, -(DOOR_W / 2 + side / 2), yMid, D / 2 - T / 2);
      wall(side, height, T,  (DOOR_W / 2 + side / 2), yMid, D / 2 - T / 2);
      wall(DOOR_W, height - DOOR_H, T, 0, baseY + DOOR_H + (height - DOOR_H) / 2, D / 2 - T / 2);
      hole = { x: 0, w: DOOR_W, y0: -height / 2, y1: -height / 2 + DOOR_H };
    } else if (opts.balconyBay) {
      const bay = BAY_W;
      const side = (W - bay) / 2;
      wall(side, height, T, -(bay / 2 + side / 2), yMid, D / 2 - T / 2);
      wall(side, height, T,  (bay / 2 + side / 2), yMid, D / 2 - T / 2);
      wall(bay, height - 3.0, T, 0, baseY + 3.0 + (height - 3.0) / 2, D / 2 - T / 2);
      hole = { x: 0, w: bay, y0: -height / 2, y1: -height / 2 + 3.0 };
    } else {
      wall(W, height, T, 0, yMid, D / 2 - T / 2);
    }

    // interior plaster panels (facing into the room)
    const hh = height - 0.06;
    skinPanel(iw, hh, 0, yMid, -id / 2, 0);              // back wall, faces +z
    skinPanel(iw, hh, 0, yMid,  id / 2, Math.PI, hole);  // front wall, faces -z
    skinPanel(id, hh, -iw / 2, yMid, 0,  Math.PI / 2);   // left wall, faces +x
    skinPanel(id, hh,  iw / 2, yMid, 0, -Math.PI / 2);   // right wall, faces -x

    // skirting + cornice trims
    const trimGeo = (len, vert) => vert
      ? new THREE.BoxGeometry(0.06, 0.14, len)
      : new THREE.BoxGeometry(len, 0.14, 0.06);
    [[0, baseY + 0.14, -id / 2, false, iw], [0, baseY + 0.14, id / 2, false, iw],
     [-iw / 2, baseY + 0.14, 0, true, id],  [iw / 2, baseY + 0.14, 0, true, id]]
      .forEach(([x, y, z, v, len]) => {
        const t = new THREE.Mesh(trimGeo(len, v), M.trim);
        t.position.set(x, y, z);
        add(t, false, true);
      });
  }

  level(0.55, H0, { doorway: true });
  // The upper storey now rises to the room of wishes; the wishes storey
  // rises to the roof slab. Every storey meets the deck above it — no
  // see-through slits at the edges (the old build had a 19 cm one).
  level(F1, FW - 0.09 - F1, { balconyBay: true });
  level(FW, F2 - 0.09 - FW, {});

  /* ---------- parapet wall around the terrace ---------- */
  const PARA_H = 1.15;
  const para = (w, d, x, z) => {
    const m = new THREE.Mesh(roundedBox(w, PARA_H, d, 0.05, 1), M.wallExt);
    m.position.set(x, F2 + PARA_H / 2 + 0.11, z);
    add(m);
    // coping stone
    const cap = new THREE.Mesh(roundedBox(w + 0.14, 0.12, d + 0.14, 0.04, 1), M.trim);
    cap.position.set(x, F2 + PARA_H + 0.18, z);
    add(cap, false, true);
  };
  para(W, 0.3, 0, -D / 2 + 0.15);
  para(0.3, D, -W / 2 + 0.15, 0);
  para(0.3, D,  W / 2 - 0.15, 0);
  // front parapet split so the stair opening stays clear
  para(4.0, 0.3, -4.5, D / 2 - 0.15);
  para(4.0, 0.3,  4.5, D / 2 - 0.15);

  /* ---------- pitched roof over a covered bay at the back of the terrace ---------- */
  const bayW = 7.2, bayD = 4.4, bayH = 2.9;
  const bayZ = -D / 2 + bayD / 2 + 0.5;
  // four posts
  [[-bayW / 2 + .2, bayZ - bayD / 2 + .2], [bayW / 2 - .2, bayZ - bayD / 2 + .2],
   [-bayW / 2 + .2, bayZ + bayD / 2 - .2], [bayW / 2 - .2, bayZ + bayD / 2 - .2]]
    .forEach(([x, z]) => {
      const p = new THREE.Mesh(
        turned([[0, 0], [0.14, 0], [0.11, 0.2], [0.09, bayH - 0.3], [0.13, bayH - 0.1], [0.13, bayH], [0, bayH]], 12),
        M.woodWarm
      );
      p.position.set(x, F2 + 0.11, z);
      add(p);
    });
  // pitched roof: two sloped slabs + ridge + fascia
  const pitch = 0.42;
  [-1, 1].forEach(s => {
    const slope = new THREE.Mesh(new THREE.BoxGeometry(bayW + 0.9, 0.16, bayD / 2 + 0.75), M.roofTile);
    slope.position.set(0, F2 + bayH + 0.42, bayZ + s * (bayD / 4 + 0.3));
    slope.rotation.x = -s * pitch;
    add(slope);
    const fascia = new THREE.Mesh(roundedBox(bayW + 0.95, 0.2, 0.1, 0.03, 1), M.roofEdge);
    fascia.position.set(0, F2 + bayH + 0.42 - Math.sin(pitch) * (bayD / 4 + 0.36), bayZ + s * (bayD / 2 + 0.62));
    add(fascia);
  });
  const ridge = new THREE.Mesh(roundedBox(bayW + 1.0, 0.2, 0.28, 0.07, 2), M.roofEdge);
  ridge.position.set(0, F2 + bayH + 0.58, bayZ);
  add(ridge);
  // beams under the roof
  [-1, 0, 1].forEach(i => {
    const b = new THREE.Mesh(new THREE.BoxGeometry(bayW + 0.3, 0.14, 0.14), M.woodDark);
    b.position.set(0, F2 + bayH + 0.02, bayZ + i * (bayD / 2.6));
    add(b);
  });

  /* ---------- exterior polish: a cornice band at every floor line ----------
     The bands wrap the building like real cornices, but each one leaves a
     notch over the stairwell that passes through it: built solid across the
     full footprint, they crossed the camera's climb and the lens cut
     straight through solid geometry on every flight. The notch sits well
     inside the outer wall line, so the exterior silhouette is unchanged. */
  [[0.55 + H0 - 0.02, VOID_F1], [F1 - 0.02, VOID_F1], [FW - 0.02, VOID_FW]].forEach(([y, VOID]) => {
    const bw = W + 0.18, bd = D + 0.18;
    const bx0 = -bw / 2, bx1 = bw / 2, bz0 = -bd / 2, bz1 = bd / 2;
    const vx0 = Math.max(bx0, VOID.x0), vx1 = Math.min(bx1, VOID.x1);
    const vz0 = Math.max(bz0, VOID.z0), vz1 = Math.min(bz1, VOID.z1);
    const board = (ax0, ax1, az0, az1) => {
      if (ax1 - ax0 <= 0.01 || az1 - az0 <= 0.01) return;
      const m = new THREE.Mesh(roundedBox(ax1 - ax0, 0.16, az1 - az0, 0.03, 1), M.trim);
      m.position.set((ax0 + ax1) / 2, y, (az0 + az1) / 2);
      add(m, false, true);
    };
    board(bx0, vx0, bz0, bz1);   // left of the void
    board(vx1, bx1, bz0, bz1);   // right of the void
    board(vx0, vx1, bz0, vz0);   // behind the void
    board(vx0, vx1, vz1, bz1);   // in front of the void
  });

  /* ---------- flower boxes under the front windows ---------- */
  [[-4.4, 2.75], [4.4, 2.75], [-4.6, 7.0], [4.6, 7.0]].forEach(([x, y]) => {
    const box = new THREE.Mesh(roundedBox(1.75, 0.26, 0.34, 0.03, 1), M.woodDark);
    box.position.set(x, y - 1.32, D / 2 + 0.14);
    add(box, false, true);
    for (let f = 0; f < 6; f++) {
      const fl = new THREE.Mesh(new THREE.SphereGeometry(0.075, 8, 6),
        new THREE.MeshStandardMaterial({ color: [0xe4869a, 0xf3c98b, 0xc98ad8][f % 3], roughness: 0.9 }));
      fl.position.set(x - 0.66 + (f % 3) * 0.66, y - 1.14, D / 2 + 0.14 + (f > 2 ? 0.08 : -0.05));
      add(fl, false, true);
    }
  });

  /* ---------- the darkroom: an enclosed shed under the bay roof,
     on the right — clear of the stair void on the left. Negatives
     hang inside and develop as you pass (see Interiors). ---------- */
  {
    const R0 = F2 + 0.11;
    const sx0 = 0.9, sx1 = 3.55, sz0 = -5.0, sz1 = -0.9;   // shed bounds
    const shH = 2.35, th = 0.12;
    const shedWall = (w, h, d, x, y, z) => {
      const m = new THREE.Mesh(roundedBox(w, h, d, 0.02, 1), M.wallAccent);
      m.position.set(x, y, z);
      add(m);
    };
    // back + right + left walls
    shedWall(sx1 - sx0, shH, th, (sx0 + sx1) / 2, R0 + shH / 2, sz0);
    shedWall(th, shH, sz1 - sz0, sx1, R0 + shH / 2, (sz0 + sz1) / 2);
    shedWall(th, shH, sz1 - sz0, sx0, R0 + shH / 2, (sz0 + sz1) / 2);
    // front wall with a door opening in its left half.
    // (Widened for the camera: the spline into the shed overshot its keys
    // and clipped the old 1.05 m jamb — see CameraRig.js darkroom keys.
    // V15 QA: the header was raised to 2.25 m so the pushed-back mobile
    // camera passes under it with real clearance.)
    const doorW = 1.2, doorX = sx0 + 0.8;
    shedWall(doorX - sx0 - doorW / 2, shH, th, (sx0 + (doorX - doorW / 2)) / 2, R0 + shH / 2, sz1);
    shedWall(sx1 - (doorX + doorW / 2), shH, th, ((doorX + doorW / 2) + sx1) / 2, R0 + shH / 2, sz1);
    shedWall(doorW, shH - 2.25, th, doorX, R0 + 2.25 + (shH - 2.25) / 2, sz1);
    // door lintel + a warm lamp over the door
    const lint = new THREE.Mesh(roundedBox(doorW + 0.3, 0.12, th + 0.06, 0.02, 1), M.trim);
    lint.position.set(doorX, R0 + 2.25, sz1);
    add(lint);
    // a low ceiling so the red light can gather
    const shedRoof = new THREE.Mesh(new THREE.BoxGeometry(sx1 - sx0, 0.08, sz1 - sz0), M.woodDark);
    shedRoof.position.set((sx0 + sx1) / 2, R0 + shH, (sz0 + sz1) / 2);
    add(shedRoof);
    group.userData.darkroom = { x: (sx0 + sx1) / 2, z: (sz0 + sz1) / 2, y: R0, doorX };
  }

  /* ---------- chimney ---------- */
  const ch = new THREE.Mesh(roundedBox(1.05, 4.2, 1.05, 0.05, 1), M.roofTile);
  ch.position.set(-W / 2 + 1.5, F2 - 1.2, -D / 2 + 1.6);
  add(ch);
  const chCap = new THREE.Mesh(roundedBox(1.3, 0.2, 1.3, 0.04, 1), M.stone);
  chCap.position.set(-W / 2 + 1.5, F2 + 0.95, -D / 2 + 1.6);
  add(chCap);

  /* ---------- entrance: jambs, lintel, door, steps, portico ---------- */
  const zF = D / 2;
  [[-DOOR_W / 2 - 0.16, 1], [DOOR_W / 2 + 0.16, -1]].forEach(([x]) => {
    const jamb = new THREE.Mesh(roundedBox(0.32, DOOR_H + 0.3, T + 0.16, 0.03, 1), M.trim);
    jamb.position.set(x, 0.55 + (DOOR_H + 0.3) / 2, zF - T / 2);
    add(jamb);
  });
  const lint = new THREE.Mesh(roundedBox(DOOR_W + 0.64, 0.34, T + 0.2, 0.04, 1), M.trim);
  lint.position.set(0, 0.55 + DOOR_H + 0.17, zF - T / 2);
  add(lint);

  // the front door, hung on a real hinge: the leaf group sits at the
  // hinge edge and every part is offset to its correct place along the
  // panel, so closed (rotation 0) the door fills the doorway and open
  // (about -1.72) it swings wide of the portico column.
  const leaf = new THREE.Group();
  const leafW = DOOR_W - 0.12;                        // 2.48 — leaves a frame margin
  const leafPanel = new THREE.Mesh(roundedBox(leafW, DOOR_H - 0.1, 0.1, 0.02, 1), M.woodDark);
  leafPanel.position.x = leafW / 2;
  leaf.add(leafPanel);
  [0.75, -0.55].forEach(py => {
    const inset = new THREE.Mesh(roundedBox(leafW * 0.62, 1.0, 0.03, 0.02, 1), M.woodWarm);
    inset.position.set(leafW / 2, py, 0.06);
    leaf.add(inset);
  });
  const knob = new THREE.Mesh(new THREE.SphereGeometry(0.075, 14, 12), M.brass);
  knob.position.set(leafW - 0.17, 0, 0.11);
  leaf.add(knob);
  const plate = new THREE.Mesh(roundedBox(0.1, 0.34, 0.02, 0.01, 1), M.brass);
  plate.position.set(leafW - 0.17, 0, 0.075);
  leaf.add(plate);
  // hinge: left jamb, proud of the outer wall face, sitting inside the jamb depth
  leaf.position.set(-DOOR_W / 2 - 0.04, 0.55 + (DOOR_H - 0.1) / 2, zF + 0.07);
  leaf.rotation.y = 0;                                // closed; HouseScene swings it open
  // The door swings open as the camera reaches the steps. It stays
  // dynamic (never merged, never shadow-baked) so the animation is free,
  // and it casts no shadow that a baked shadow map would freeze.
  leaf.traverse(o => { if (o.isMesh) o.castShadow = false; });
  leaf.userData.dynamic = true;
  group.add(leaf);

  // steps
  for (let i = 0; i < 3; i++) {
    const s = new THREE.Mesh(
      roundedBox(DOOR_W + 2.4 + i * 0.7, 0.2, 0.62 + i * 0.16, 0.03, 1), M.stone);
    s.position.set(0, 0.44 - i * 0.19, zF + 0.55 + i * 0.55);
    add(s, false, true);
  }
  // portico: columns + entablature
  [-2.3, 2.3].forEach(x => {
    const col = new THREE.Mesh(
      turned([[0, 0], [0.24, 0], [0.2, 0.16], [0.15, 0.5], [0.14, 3.4], [0.19, 3.62], [0.22, 3.8], [0, 3.8]], 16),
      M.trim);
    col.position.set(x, 0.55, zF + 1.85);
    add(col);
  });
  const entab = new THREE.Mesh(roundedBox(6.2, 0.42, 2.6, 0.05, 1), M.trim);
  entab.position.set(0, 4.56, zF + 1.5);
  add(entab);
  const porticoRoof = new THREE.Mesh(roundedBox(6.6, 0.22, 2.9, 0.05, 1), M.roofTile);
  porticoRoof.position.set(0, 4.86, zF + 1.5);
  add(porticoRoof);

  /* ---------- windows (frames, mullions, sills, glass) ----------
     Every window is built twice: an exterior face that glows warm
     from outside, and an interior casing with a night pane, so from
     inside the room it reads as a window and never as a blank slab. */
  const windows = [];
  function makeWindow(x, y, z, ry, w = 1.7, h = 2.1, lit = true) {
    const g = new THREE.Group();

    /* ---- outside ---- */
    // reveal box, kept strictly inside the wall thickness
    const rev = new THREE.Mesh(roundedBox(w + 0.3, h + 0.3, T - 0.06, 0.03, 1), M.trim);
    rev.position.z = 0;
    g.add(rev);
    // glass, clearly proud of the reveal.
    // Each lit pane gets its OWN material instance so the approach
    // sequence can wake the windows one by one (see HouseScene).
    const pane = new THREE.Mesh(
      new THREE.PlaneGeometry(w, h),
      lit ? M.glassLit.clone() : M.glassPane
    );
    pane.position.z = T / 2 + 0.015;
    g.add(pane);
    // mullions in front of the glass
    const mv = new THREE.Mesh(roundedBox(0.07, h, 0.06, 0.015, 1), M.trim);
    const mh = new THREE.Mesh(roundedBox(w, 0.07, 0.06, 0.015, 1), M.trim);
    mv.position.z = mh.position.z = T / 2 + 0.05;
    g.add(mv, mh);
    // sill
    const sill = new THREE.Mesh(roundedBox(w + 0.5, 0.1, 0.36, 0.03, 1), M.trim);
    sill.position.set(0, -h / 2 - 0.16, T / 2 + 0.06);
    g.add(sill);
    // shutters
    [-1, 1].forEach(s => {
      const sh = new THREE.Mesh(roundedBox(w * 0.42, h, 0.06, 0.02, 1), M.wallAccent);
      sh.position.set(s * (w / 2 + w * 0.24), 0, T / 2 + 0.05);
      sh.rotation.y = -s * 0.36;
      g.add(sh);
    });

    /* ---- inside (local -Z faces the room) ---- */
    const zi = -(T / 2 + 0.02);
    // the night beyond the glass
    const night = new THREE.Mesh(new THREE.PlaneGeometry(w, h), M.nightPane);
    night.position.z = zi - 0.03;
    night.rotation.y = Math.PI;
    g.add(night);
    // casing
    const cW = 0.11;
    [[0, h / 2 + cW / 2, w + cW * 2, cW], [0, -h / 2 - cW / 2, w + cW * 2, cW],
     [-w / 2 - cW / 2, 0, cW, h], [w / 2 + cW / 2, 0, cW, h]]
      .forEach(([cx, cy, cw, chh]) => {
        const bar = new THREE.Mesh(roundedBox(cw, chh, 0.1, 0.02, 1), M.trim);
        bar.position.set(cx, cy, zi);
        g.add(bar);
      });
    // interior mullion cross
    const imv = new THREE.Mesh(roundedBox(0.06, h, 0.05, 0.012, 1), M.trim);
    const imh = new THREE.Mesh(roundedBox(w, 0.06, 0.05, 0.012, 1), M.trim);
    imv.position.z = imh.position.z = zi - 0.01;
    g.add(imv, imh);
    // interior sill / ledge
    const isill = new THREE.Mesh(roundedBox(w + 0.4, 0.09, 0.3, 0.025, 1), M.trim);
    isill.position.set(0, -h / 2 - 0.14, zi - 0.14);
    g.add(isill);
    // curtains either side
    [-1, 1].forEach(s => {
      const cur = new THREE.Mesh(roundedBox(w * 0.3, h + 0.34, 0.07, 0.03, 2), M.curtain);
      cur.position.set(s * (w / 2 + w * 0.1), -0.05, zi - 0.16);
      g.add(cur);
    });

    g.position.set(x, y, z);
    g.rotation.y = ry;
    g.traverse(o => { if (o.isMesh) { o.castShadow = false; o.receiveShadow = true; } });
    group.add(g);
    windows.push({ group: g, pane });
    return g;
  }

  const zFo = D / 2 - T / 2, zBo = -D / 2 + T / 2;
  const xLo = -W / 2 + T / 2, xRo = W / 2 - T / 2;
  // ground floor front
  makeWindow(-4.4, 2.75, zFo, 0);
  makeWindow( 4.4, 2.75, zFo, 0);
  // ground floor sides
  makeWindow(xRo, 2.75,  2.6, Math.PI / 2);
  makeWindow(xRo, 2.75, -2.6, Math.PI / 2);
  makeWindow(xLo, 2.75,  2.6, -Math.PI / 2);
  makeWindow(xLo, 2.75, -2.6, -Math.PI / 2);
  // ground floor back
  makeWindow(-3.2, 2.75, zBo, Math.PI);
  makeWindow( 3.2, 2.75, zBo, Math.PI);
  // upper floor
  makeWindow(-4.6, 7.0, zFo, 0, 1.5, 1.9);
  makeWindow( 4.6, 7.0, zFo, 0, 1.5, 1.9);
  makeWindow(xRo, 7.0,  2.6, Math.PI / 2, 1.5, 1.9);
  makeWindow(xRo, 7.0, -2.6, Math.PI / 2, 1.5, 1.9);
  makeWindow(xLo, 7.0,  2.6, -Math.PI / 2, 1.5, 1.9);
  makeWindow(xLo, 7.0, -2.6, -Math.PI / 2, 1.5, 1.9);
  // pushed out to the corners: the memory wall owns the middle of this wall
  makeWindow(-5.3, 7.0, zBo, Math.PI, 1.4, 1.8);
  makeWindow( 5.3, 7.0, zBo, Math.PI, 1.4, 1.8);
  // the room of wishes — a smaller, calmer row
  makeWindow(-4.6, FW + 1.95, zFo, 0, 1.3, 1.7);
  makeWindow( 4.6, FW + 1.95, zFo, 0, 1.3, 1.7);
  makeWindow(xRo, FW + 1.95,  2.6, Math.PI / 2, 1.3, 1.7);
  makeWindow(xRo, FW + 1.95, -2.6, Math.PI / 2, 1.3, 1.7);
  makeWindow(xLo, FW + 1.95,  2.6, -Math.PI / 2, 1.3, 1.7);
  makeWindow(xLo, FW + 1.95, -2.6, -Math.PI / 2, 1.3, 1.7);

  /* ---------- upper floor balcony ---------- */
  const balc = new THREE.Mesh(roundedBox(5.6, 0.2, 2.2, 0.04, 1), M.stone);
  balc.position.set(0, F1 - 0.1, zF + 0.9);
  add(balc, true, true);
  // balustrade
  const railTop = new THREE.Mesh(roundedBox(5.7, 0.12, 0.16, 0.05, 2), M.trim);
  railTop.position.set(0, F1 + 1.06, zF + 1.9);
  add(railTop);
  for (let i = 0; i <= 12; i++) {
    const b = new THREE.Mesh(
      turned([[0, 0], [0.055, 0], [0.04, 0.18], [0.062, 0.42], [0.04, 0.72], [0.05, 1.0], [0, 1.0]], 10),
      M.trim);
    b.position.set(-2.75 + i * (5.5 / 12), F1 + 0.02, zF + 1.9);
    add(b, false, true);
  }
  [-1, 1].forEach(s => {
    const side = new THREE.Mesh(roundedBox(0.16, 0.12, 2.1, 0.04, 1), M.trim);
    side.position.set(s * 2.78, F1 + 1.06, zF + 0.9);
    add(side);
  });

  /* ---------- interior staircase: ground -> upper -> roof ----------
     Solid: every step has a tread AND a riser, the flight is closed
     in by a stringer on both sides, and a handrail runs the whole
     way up. Nothing floats. */
  const stairs = [];
  function flight(f, opts = {}) {
    const { x, width } = STAIR;
    const { y0, y1, z0, z1, steps } = f;
    const dy = (y1 - y0) / steps, dz = (z1 - z0) / steps;
    const dir = Math.sign(dz);

    for (let i = 0; i < steps; i++) {
      const zc = z0 + dz * (i + 0.5);
      const tread = new THREE.Mesh(
        roundedBox(width, 0.11, Math.abs(dz) + 0.14, 0.02, 1), M.woodWarm);
      tread.position.set(x, y0 + dy * (i + 1), zc);
      add(tread, true, true);
      stairs.push(tread);
      // riser closes the gap under each nosing
      const riser = new THREE.Mesh(new THREE.BoxGeometry(width, Math.abs(dy) + 0.02, 0.05), M.trim);
      riser.position.set(x, y0 + dy * (i + 0.5), z0 + dz * i + dir * 0.04);
      add(riser, false, true);
    }

    // stringers: a solid sloped board closing each side of the flight
    const len = Math.hypot(y1 - y0, z1 - z0);
    const ang = Math.atan2(y1 - y0, z1 - z0);
    [-1, 1].forEach(s => {
      const str = new THREE.Mesh(new THREE.BoxGeometry(0.12, 0.52, len + 0.2), M.woodDark);
      str.position.set(x + s * (width / 2 + 0.06), (y0 + y1) / 2 - 0.16, (z0 + z1) / 2);
      str.rotation.x = -ang + Math.PI / 2;
      add(str, true, true);
    });

    // handrail + balusters
    const rails = opts.rails || [-1, 1];
    rails.forEach(s => {
      const ox = s * (width / 2 + 0.06);
      const rail = new THREE.Mesh(roundedBox(0.1, 0.1, len + 0.1, 0.04, 2), M.woodDark);
      rail.position.set(x + ox, (y0 + y1) / 2 + 1.0, (z0 + z1) / 2);
      rail.rotation.x = -ang + Math.PI / 2;
      add(rail);
      for (let i = 0; i <= steps; i += 2) {
        const t = i / steps;
        const bal = new THREE.Mesh(
          turned([[0, 0], [0.04, 0], [0.03, 0.3], [0.045, 0.62], [0.03, 0.95], [0, 0.95]], 8), M.trim);
        bal.position.set(x + ox, y0 + (y1 - y0) * t, z0 + (z1 - z0) * t);
        add(bal, false, true);
      }
    });
  }
  flight(STAIR.f1);
  flight(STAIR.f2);

  /* ---------- under-stair enclosures ----------
     Flight 2 climbs over the open stairwell, which read as a detached
     ramp floating in the void — you could see straight past it. A soffit
     beneath each flight and a skirt on the wall side make them read as
     built joinery instead. The soffit of flight 2 starts 1.4 m up the
     run and sits well below the treads so the camera's dip under the
     flight (roofstair → climb4) passes clear of its outer edge. */
  {
    const enclose = (f, opts = {}) => {
      const { zA = f.z0 - 0.1, zB = f.z1 + 0.2, skirts = [], drop = 0.45 } = opts;
      const yAt = z => f.y0 + (f.y1 - f.y0) * ((z - f.z0) / (f.z1 - f.z0));
      const dir = new THREE.Vector3(0, f.y1 - f.y0, f.z1 - f.z0).normalize();
      const perp = new THREE.Vector3(0, dir.z, -dir.y).normalize();  // down-slope
      if (perp.y > 0) perp.negate();                 // always points below the flight
      const midZ = (zA + zB) / 2;
      const L = Math.hypot(zB - zA, yAt(zB) - yAt(zA));

      // soffit: a sloped board under the treads
      const soffit = new THREE.Mesh(
        new THREE.BoxGeometry(STAIR.width + 0.24, 0.12, L + 0.2), M.woodDark);
      soffit.position.set(STAIR.x, yAt(midZ), midZ)
        .addScaledVector(perp, drop + 0.06);
      soffit.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
      add(soffit, true, true);

      // skirts: deep side panels closing the stringer gap
      skirts.forEach(s => {
        const skirt = new THREE.Mesh(
          new THREE.BoxGeometry(0.14, 1.15, L + 0.15), M.woodDark);
        skirt.position.set(STAIR.x + s * (STAIR.width / 2 + 0.13), yAt(midZ), midZ)
          .addScaledVector(perp, 0.38 + 0.575);
        skirt.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), dir);
        add(skirt, true, true);
      });
    };
    // flight 1: full enclosure (its underside faces the ground-floor room)
    enclose(STAIR.f1, { skirts: [-1, 1] });
    // flight 2: the camera dips under this flight's foot (roofstair →
    // climb4), so its soffit only starts 3 m up the run — beyond the
    // camera's crossing point — and the skirt is on the wall side only;
    // the well side stays open behind its balustrade
    enclose(STAIR.f2, {
      zA: STAIR.f2.z0 + 3.0, skirts: [-1]
    });
    // flight 3 rises over the room of wishes — same treatment, wall side
    enclose(STAIR.f3, { skirts: [-1] });
  }

  // newel posts at the foot of each flight
  [[STAIR.f1.z0 + 0.1, STAIR.f1.y0], [STAIR.f2.z0 + 0.05, STAIR.f2.y0],
   [STAIR.f3.z0 - 0.05, STAIR.f3.y0]].forEach(([z, y]) => {
    [-1, 1].forEach(s => {
      const post = new THREE.Mesh(
        turned([[0, 0], [0.1, 0], [0.08, 0.1], [0.07, 1.0], [0.1, 1.1], [0.06, 1.18], [0, 1.2]], 10),
        M.woodDark);
      post.position.set(STAIR.x + s * (STAIR.width / 2 + 0.06), y, z);
      add(post);
    });
  });

  /* ---------- guard rail around the stairwell openings ---------- */
  function guard(x, z0, z1, y) {
    const rail = new THREE.Mesh(roundedBox(0.1, 0.1, z1 - z0, 0.04, 2), M.woodDark);
    rail.position.set(x, y + 1.0, (z0 + z1) / 2);
    add(rail);
    const n = Math.max(3, Math.round((z1 - z0) / 0.42));
    for (let i = 0; i <= n; i++) {
      const b = new THREE.Mesh(
        turned([[0, 0], [0.04, 0], [0.03, 0.3], [0.045, 0.62], [0.03, 0.95], [0, 0.95]], 8), M.trim);
      b.position.set(x, y + 0.05, z0 + (z1 - z0) * (i / n));
      add(b, false, true);
    }
  }
  function guardZ(z, x0, x1, y) {
    const rail = new THREE.Mesh(roundedBox(x1 - x0, 0.1, 0.1, 0.04, 2), M.woodDark);
    rail.position.set((x0 + x1) / 2, y + 1.0, z);
    add(rail);
    const n = Math.max(3, Math.round((x1 - x0) / 0.42));
    for (let i = 0; i <= n; i++) {
      const b = new THREE.Mesh(
        turned([[0, 0], [0.04, 0], [0.03, 0.3], [0.045, 0.62], [0.03, 0.95], [0, 0.95]], 8), M.trim);
      b.position.set(x0 + (x1 - x0) * (i / n), y + 0.05, z);
      add(b, false, true);
    }
  }
  // upper floor: rail down the open side of the stairwell
  guard(VOID_F1.x1, VOID_F1.z0, 4.6, LEVEL.U);
  guardZ(VOID_F1.z0, VOID_F1.x0 + 0.1, VOID_F1.x1, LEVEL.U);
  // rooftop: rail around the second opening
  guard(VOID_F2.x1, VOID_F2.z0, VOID_F2.z1, LEVEL.R);

  /* ---------- signage ---------- */
  const sign = new THREE.Group();
  const board = new THREE.Mesh(roundedBox(4.2, 0.95, 0.16, 0.05, 2), M.woodDark);
  const nameTex = textTexture(window.BDAY_CONFIG.house.nameplate, {
    w: 4096, h: 880,
    font: "600 300px 'Cormorant Garamond', Georgia, serif", letter: 44, color: "#ffeacd",
    glow: "#ffb066", glowBlur: 30
  });
  nameTex.anisotropy = 8;
  const nameMesh = new THREE.Mesh(new THREE.PlaneGeometry(2.9, 0.625),
    new THREE.MeshBasicMaterial({ map: nameTex, transparent: true, depthWrite: false, toneMapped: false }));
  nameMesh.position.z = 0.09;
  nameMesh.renderOrder = 1;
  sign.add(board, nameMesh);
  // hung on the facade band ABOVE the balcony bay — from the approach it
  // used to sit behind the balustrade; up here the whole arc reads it
  sign.position.set(0, 8.82, zF + 0.09);
  nameMesh.material.fog = false;
  group.add(sign);

  /* ---- date plaque beside the door ---- */
  {
    const TXW = 4096, TXH = 680;                 // texture pixels (2× — crisp up close)
    // legibility pass: a much bolder, brighter, wider-tracked engraving —
    // it has to read from the far end of the approach arc
    const plaqueTex = textTexture(window.BDAY_CONFIG.house.datePlaque, {
      w: TXW, h: TXH,
      font: "700 336px Inter, Arial, sans-serif",
      letter: 60, color: "#fff0c8", glow: "#ffab45", glowBlur: 40
    });
    plaqueTex.anisotropy = 8;
    const PW = 3.3;                               // metres wide
    const PH = PW * (TXH / TXW);                  // keep the aspect exactly
    const plaque = new THREE.Group();
    const pb = new THREE.Mesh(roundedBox(PW + 0.22, PH + 0.2, 0.08, 0.035, 2), M.brassDark);
    const bevel = new THREE.Mesh(roundedBox(PW + 0.1, PH + 0.09, 0.09, 0.02, 1), M.brass);
    bevel.position.z = 0.012;
    const pt = new THREE.Mesh(new THREE.PlaneGeometry(PW, PH),
      new THREE.MeshBasicMaterial({ map: plaqueTex, transparent: true, depthWrite: false, toneMapped: false }));
    pt.position.z = 0.056;
    pt.renderOrder = 2;
    plaque.add(pb, bevel, pt);
    // beside the nameplate on the upper facade — the old spot (under the
    // portico, low) left the text out of frame and in shadow on approach
    plaque.position.set(0, 8.18, zF + 0.09);
    pt.material.fog = false;
    group.add(plaque);
  }

  return { group, windows, stairs, sign, DIM, VOID_F1, VOID_FW, VOID_F2, door: leaf };
}
