/* =============================================================
   SCENE OPTIMISER
   The house is authored as hundreds of small, readable meshes.
   Before the first frame we collapse everything static into a
   handful of merged draw calls, and convert the many little glow
   sprites into two Points clouds.

   Anything tagged `userData.dynamic = true` (or animated by the
   render loop) is left untouched.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";

/* ---------- minimal geometry merge (no examples/ dependency) ---------- */
function toNonIndexed(g) { return g.index ? g.toNonIndexed() : g; }

function mergeGeometries(list) {
  if (!list.length) return null;
  const geos = list.map(toNonIndexed);
  // only merge attributes present in ALL geometries
  const common = ["position", "normal", "uv"].filter(name =>
    geos.every(g => g.attributes[name]));
  let total = 0;
  geos.forEach(g => { total += g.attributes.position.count; });

  const out = new THREE.BufferGeometry();
  common.forEach(name => {
    const size = geos[0].attributes[name].itemSize;
    const arr = new Float32Array(total * size);
    let off = 0;
    geos.forEach(g => {
      arr.set(g.attributes[name].array, off);
      off += g.attributes[name].count * size;
    });
    out.setAttribute(name, new THREE.BufferAttribute(arr, size));
  });
  out.computeBoundingSphere();
  return out;
}

/**
 * Collapse static meshes into one merged mesh per material.
 * @returns {object} stats
 */
export function mergeStatics(scene, opts = {}) {
  const { minGroup = 2 } = opts;
  const buckets = new Map();      // "matUUID|zoneHint" -> { material, zoneHint, meshes: [] }
  const skipped = [];
  const zoned = [];                // merged meshes tagged with a zone (for visibility toggling)

  scene.updateMatrixWorld(true);

  scene.traverse(o => {
    if (!o.isMesh) return;
    if (o.userData.dynamic) return;
    // meshes that start hidden (knives, slices, LEDs…) must stay hidden:
    // merging would bake them into a visible batch with no way back
    if (!o.visible) return;
    // never merge things the loop animates or that carry per-object state
    let p = o, dyn = false;
    while (p) { if (p.userData && p.userData.dynamic) { dyn = true; break; } p = p.parent; }
    if (dyn) return;
    if (o.isInstancedMesh || o.isSkinnedMesh) return;
    if (Array.isArray(o.material)) return;
    if (!o.geometry || !o.geometry.attributes.position) return;

    const m = o.material;
    // perf: keep zoned geometry (outdoor grounds vs. indoor floors vs.
    // rooftop furniture) out of the same merged batch as everything
    // else, so the batch can be hidden outright while the camera is
    // nowhere near it — see zoneHint tagging in HouseScene.js.
    const zoneHint = o.userData.zoneHint || "";
    const key = m.uuid + "|" + zoneHint;
    if (!buckets.has(key)) buckets.set(key, { material: m, zoneHint, meshes: [] });
    buckets.get(key).meshes.push(o);
  });

  let merged = 0, removed = 0;
  buckets.forEach(({ material, zoneHint, meshes }) => {
    if (meshes.length < minGroup) { skipped.push(...meshes); return; }

    const geos = [];
    let castShadow = false, receiveShadow = false;
    meshes.forEach(mesh => {
      const g = mesh.geometry.clone();
      g.applyMatrix4(mesh.matrixWorld);
      geos.push(g);
      castShadow = castShadow || mesh.castShadow;
      receiveShadow = receiveShadow || mesh.receiveShadow;
    });

    const combined = mergeGeometries(geos);
    geos.forEach(g => g.dispose());
    if (!combined) { skipped.push(...meshes); return; }

    const mm = new THREE.Mesh(combined, material);
    mm.castShadow = castShadow;
    mm.receiveShadow = receiveShadow;
    mm.matrixAutoUpdate = false;
    mm.frustumCulled = true;
    if (zoneHint) { mm.userData.zone = zoneHint; zoned.push(mm); }
    scene.add(mm);
    merged++;

    meshes.forEach(mesh => {
      mesh.geometry.dispose();
      mesh.removeFromParent();
      removed++;
    });
  });

  // a mesh that didn't get merged (too small a group, or an incompatible
  // geometry) still needs its zone respected — otherwise it'd be the one
  // stray triangle count that never goes away with the rest of its zone.
  skipped.forEach(o => { if (o.userData.zoneHint) { o.userData.zone = o.userData.zoneHint; zoned.push(o); } });

  return { mergedMeshes: merged, removedMeshes: removed, skipped: skipped.length, zoned };
}

/* =============================================================
   GLOW POINTS
   Replaces dozens of individual Sprites with one additive
   Points cloud. Each glow keeps an index so the render loop can
   still breathe its brightness individually.
   ============================================================= */
export function createGlowCloud(scene, entries, opts = {}) {
  const { sizeScale = 1 } = opts;
  const n = entries.length;
  if (!n) return null;

  const pos = new Float32Array(n * 3);
  const col = new Float32Array(n * 3);
  const siz = new Float32Array(n);
  const bri = new Float32Array(n);
  // GPU animation channel: most glows (halos, embers, lanterns…) still
  // get their brightness written from the CPU each frame via aBright.
  // String-light bulbs are the one large, uniform group (dozens of
  // them) that flicker/wake on a purely time + seed + zone based curve,
  // so their brightness is computed IN the vertex shader instead —
  // aMode flags which points opt into that path, aSeed/aZone feed it.
  const mode = new Float32Array(n);   // 0 = CPU aBright, 1 = GPU bulb shader
  const seed = new Float32Array(n);
  const zone = new Float32Array(n);   // 0 ground · 1 balcony · 2 roof
  const c = new THREE.Color();

  entries.forEach((e, i) => {
    pos[i * 3] = e.position.x;
    pos[i * 3 + 1] = e.position.y;
    pos[i * 3 + 2] = e.position.z;
    c.set(e.color);
    col[i * 3] = c.r; col[i * 3 + 1] = c.g; col[i * 3 + 2] = c.b;
    siz[i] = (e.size || 0.4) * sizeScale;
    bri[i] = e.brightness ?? 0.5;
  });

  const geo = new THREE.BufferGeometry();
  geo.setAttribute("position", new THREE.BufferAttribute(pos, 3));
  geo.setAttribute("aColor", new THREE.BufferAttribute(col, 3));
  geo.setAttribute("aSize", new THREE.BufferAttribute(siz, 1));
  geo.setAttribute("aBright", new THREE.BufferAttribute(bri, 1));
  geo.setAttribute("aMode", new THREE.BufferAttribute(mode, 1));
  geo.setAttribute("aSeed", new THREE.BufferAttribute(seed, 1));
  geo.setAttribute("aZone", new THREE.BufferAttribute(zone, 1));

  const mat = new THREE.ShaderMaterial({
    transparent: true, depthWrite: false, blending: THREE.AdditiveBlending,
    uniforms: {
      uPixelRatio: { value: Math.min(devicePixelRatio || 1, 2) },
      uTime: { value: 0 },
      uWakeBalcony: { value: 1 },
      uRoofA: { value: 0 },
      uRoofS: { value: 1 },
      uProgress: { value: 0 }
    },
    vertexShader: `
      attribute vec3 aColor; attribute float aSize; attribute float aBright;
      attribute float aMode; attribute float aSeed; attribute float aZone;
      uniform float uPixelRatio; uniform float uTime;
      uniform float uWakeBalcony; uniform float uRoofA; uniform float uRoofS; uniform float uProgress;
      varying vec3 vColor; varying float vBright;
      float smoothstepf(float a, float b, float x){
        float t = clamp((x - a) / (b - a), 0.0, 1.0);
        return t * t * (3.0 - 2.0 * t);
      }
      void main(){
        vColor = aColor;
        if (aMode > 0.5) {
          // ---- bulb flicker/wake, entirely on the GPU ----
          float v = 0.62 + 0.38 * (0.5 + 0.5 * sin(uTime * 1.35 + aSeed));
          float wk = 1.0;
          if (aZone > 0.5 && aZone < 1.5) {
            wk = uWakeBalcony;
          } else if (aZone >= 1.5) {
            float f = (sin(aSeed) + 1.0) * 0.5;
            float a0 = uRoofA + f * 0.62 * uRoofS;
            float a1 = uRoofA + (0.38 + f * 0.62) * uRoofS;
            wk = 0.22 + 0.78 * smoothstepf(a0, a1, uProgress);
          }
          vBright = (0.28 * v + 0.18) * wk;
        } else {
          vBright = aBright;
        }
        vec4 mv = modelViewMatrix * vec4(position, 1.0);
        gl_PointSize = clamp(aSize * 210.0 * uPixelRatio / -mv.z, 1.0, 46.0);
        gl_Position = projectionMatrix * mv;
      }`,
    fragmentShader: `
      varying vec3 vColor; varying float vBright;
      void main(){
        float d = length(gl_PointCoord - 0.5) * 2.0;
        if (d > 1.0) discard;
        float a = pow(1.0 - d, 2.6) * vBright;
        gl_FragColor = vec4(vColor, a);
      }`
  });

  const points = new THREE.Points(geo, mat);
  points.frustumCulled = false;
  points.renderOrder = 4;
  points.userData.dynamic = true;
  scene.add(points);

  return {
    points, geo, mat,
    brightness: geo.attributes.aBright,
    setBrightness(i, v) { bri[i] = v; },
    flush() { geo.attributes.aBright.needsUpdate = true; },
    // one-time setup for GPU-driven bulbs — never touched again per-frame
    setBulb(i, { seed: s, zone: z }) {
      mode[i] = 1; seed[i] = s; zone[i] = z;
    },
    flushBulbSetup() {
      geo.attributes.aMode.needsUpdate = true;
      geo.attributes.aSeed.needsUpdate = true;
      geo.attributes.aZone.needsUpdate = true;
    },
    count: n
  };
}

/* =============================================================
   INSTANCED FIELD
   For genuinely repeated objects (balusters, bulbs, trees) that
   share one geometry + material.
   ============================================================= */
export function instanceFrom(scene, geometry, material, transforms, opts = {}) {
  const mesh = new THREE.InstancedMesh(geometry, material, transforms.length);
  const m = new THREE.Matrix4();
  const q = new THREE.Quaternion();
  const e = new THREE.Euler();
  const s = new THREE.Vector3();
  const p = new THREE.Vector3();
  transforms.forEach((t, i) => {
    p.set(t.position[0], t.position[1], t.position[2]);
    e.set(t.rotation?.[0] || 0, t.rotation?.[1] || 0, t.rotation?.[2] || 0);
    q.setFromEuler(e);
    const sc = t.scale ?? 1;
    s.set(Array.isArray(sc) ? sc[0] : sc, Array.isArray(sc) ? sc[1] : sc, Array.isArray(sc) ? sc[2] : sc);
    m.compose(p, q, s);
    mesh.setMatrixAt(i, m);
  });
  mesh.instanceMatrix.needsUpdate = true;
  mesh.castShadow = opts.castShadow ?? false;
  mesh.receiveShadow = opts.receiveShadow ?? true;
  scene.add(mesh);
  return mesh;
}

/** Debug helper — call from the console. */
export function report(renderer, scene) {
  let meshes = 0, sprites = 0, points = 0, lights = 0;
  scene.traverse(o => {
    if (o.isMesh) meshes++;
    else if (o.isSprite) sprites++;
    else if (o.isPoints) points++;
    else if (o.isLight) lights++;
  });
  return {
    calls: renderer.info.render.calls,
    triangles: renderer.info.render.triangles,
    meshes, sprites, points, lights,
    geometries: renderer.info.memory.geometries,
    textures: renderer.info.memory.textures
  };
}
