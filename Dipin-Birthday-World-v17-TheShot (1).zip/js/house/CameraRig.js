/* =============================================================
   CAMERA RIG
   A single scroll-scrubbed journey:

     distant house → approach → portico → threshold →
     ground floor → the cake ceremony → gifts & wishes →
     up the stairs → upper floor → second flight → rooftop →
     the reveal → final drift

   Positions are Catmull-Rom interpolated so there are no corners,
   and the look-at target rides its own spline so the camera can
   turn its head independently of where it is walking.

   Every key carries a `tag`; captions, hotspots, the floor label
   and the cake ceremony are all timed off those tags, so the words
   on screen can never drift out of step with the picture.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { DIM, LEVEL, STAIR, stairY } from "./Architecture.js";

const { G, U, W, R } = LEVEL;
const EYE = 1.62;                       // eye height above a floor / tread
const SX = STAIR.x;                     // the staircase centre line

// eye height while standing on a flight at a given z
const onF1 = z => stairY(STAIR.f1, z) + EYE;
const onF2 = z => stairY(STAIR.f2, z) + EYE;
const onF3 = z => stairY(STAIR.f3, z) + EYE;
/* Flight 2 runs directly over the top of flight 1 (a true switchback) and
   the vertical gap between the two runs is ~1.52 m — less than a standing
   eye height. The old 1.62 m eye let the lens dip up to ~6 cm INTO flight
   2's treads near the top of the first climb (verified by raycast). A
   slightly lower eye on flight 1 clears the treads with real air between
   the lens and the wood, and reads the same on screen. */
const onF1LOW = z => stairY(STAIR.f1, z) + 1.42;

export const KEYS = [
  // ---------- INTRO HOLD ----------
  // A slow, straight-on establishing drift while Ekanth's title cards
  // play over the top. The WHOLE house is in frame, feet on the ground,
  // never cropped, never sunk.
  { p: [0,    8.0,  41], l: [0,   6.2,  0],  fov: 38, tag: "intro-a" },
  { p: [-3.2, 7.6,  36], l: [0,   6.1,  0],  fov: 39, tag: "intro-b" },
  { p: [2.4,  7.1,  31], l: [0,   5.9,  0],  fov: 41, tag: "intro-c" },

  // ---------- APPROACH ----------
  { p: [0,    6.4,  26], l: [0,   5.5,  0],  fov: 43, tag: "far" },
  { p: [-8,   5.9,  22], l: [0,   5.0,  0],  fov: 46, tag: "arc" },
  { p: [-11,  5.0,  14], l: [-1,  4.4,  0],  fov: 48, tag: "side" },
  { p: [-6,   4.2,  14], l: [0,   4.2,  1],  fov: 50, tag: "return" },
  { p: [0,    3.5,  13.5],l:[0,   3.8,  1],  fov: 52, tag: "garden" },
  { p: [0,    3.0,  10.6],l:[0,   3.3,  0],  fov: 55, tag: "portico" },
  { p: [0,    2.6,   8.6],l:[0,   2.9, -1],  fov: 58, tag: "steps" },
  { p: [0,    2.4,   6.5],l:[0,   2.6, -3],  fov: 60, tag: "threshold" },

  // ---------- GROUND FLOOR ----------
  { p: [0,    G + EYE,       3.6], l: [0.3, 2.3, -2.2], fov: 62, tag: "enter" },
  { p: [1.1,  G + EYE,       2.1], l: [0.4, 2.2, -1.6], fov: 58, tag: "room" },

  // ---------- THE CAKE CEREMONY ----------
  // Each beat has its own camera key, and the cake animation for that
  // beat finishes exactly when the camera arrives. Nothing important
  // ever happens off-screen.
  { p: [1.95, 3.05, 2.15], l: [0.40, 2.42, -1.4], fov: 46, tag: "cake-approach" },
  { p: [1.20, 3.12, 1.95], l: [0.40, 2.55, -1.4], fov: 42, tag: "cake-candles" },
  { p: [0.85, 3.20, 1.90], l: [0.40, 2.78, -1.4], fov: 38, tag: "cake-number" },
  { p: [0.70, 3.24, 1.95], l: [0.40, 2.86, -1.4], fov: 37, tag: "cake-lit" },
  { p: [0.55, 3.26, 2.00], l: [0.40, 2.90, -1.4], fov: 36, tag: "cake-wish" },
  { p: [0.48, 3.24, 2.05], l: [0.40, 2.88, -1.4], fov: 36, tag: "cake-blow" },
  { p: [1.50, 3.05, 1.95], l: [0.45, 2.32, -1.4], fov: 44, tag: "cake-cut" },
  { p: [1.75, 2.94, 2.15], l: [0.60, 2.10, -1.3], fov: 46, tag: "cake-slice" },

  // ---------- GIFTS & WISHES ----------
  { p: [0.45, 2.25, 2.45], l: [-1.55, 1.10, 0.75], fov: 48, tag: "gifts" },
  { p: [0.55, 2.70, 3.10], l: [0.40, 2.55, -1.4], fov: 58, tag: "wishes" },

  // ---------- TO THE STAIRS ----------
  { p: [-1.2, G + EYE, 3.4], l: [-3.6, 2.7, 1.8], fov: 56, tag: "turn" },
  { p: [SX,   G + EYE, 4.9], l: [SX,   3.1, 1.4], fov: 55, tag: "stairfoot" },

  // ---------- CLIMBING (feet on the treads, the whole way) ----------
  // Flight 1 uses the lower eye so the lens never dips into the treads
  // of flight 2 stacked above it (see onF1LOW).
  { p: [SX, onF1LOW(2.6),  2.6], l: [SX - 0.4, onF1(2.6) + 0.3, -0.6], fov: 55, tag: "climb1" },
  { p: [SX, onF1LOW(0.8),  0.8], l: [SX - 0.6, onF1(0.8) + 0.3, -1.8], fov: 54, tag: "climb2" },
  { p: [SX, onF1LOW(-1.0), -1.0], l: [SX - 0.8, onF1(-1.0) + 0.2, -3.2], fov: 54, tag: "climb3" },
  { p: [SX, U + EYE,   -3.0], l: [-2.2, U + 1.7, -4.4], fov: 56, tag: "stairtop" },

  // ---------- UPPER FLOOR ----------
  // Arriving on the landing, the camera now walks BEHIND flight two and
  // around its right side — the old line clipped straight through the
  // second staircase ("aar paar"). Stay at z ≤ −2.9 (behind the flight's
  // first riser at −2.6) until safely right of the stair span.
  { p: [-1.5, U + EYE, -2.95], l: [0.6, U + 1.6, -4.2], fov: 58, tag: "upper" },
  { p: [-0.6, U + EYE,  0.9], l: [0,   U + 1.8, -5.0], fov: 54, tag: "gallery" },
  { p: [0,    U + 1.72, 2.3], l: [0,   U + 1.9, -5.05], fov: 48, tag: "memorywall" },
  { p: [0.9,  U + EYE,  1.7], l: [5.6, U + 1.6,  1.2], fov: 58, tag: "hallway" },

  // ---------- SECOND FLIGHT (upper → the room of wishes) ----------
  { p: [-2.2, U + EYE,  0.6], l: [SX,   U + 2.6, -1.2], fov: 56, tag: "roofstair" },
  { p: [SX,  onF2(-1.4), -1.4], l: [SX + 0.2, onF2(-1.4) + 1.7, 0.8], fov: 55, tag: "climb4" },
  { p: [SX,  onF2(0.6),  0.6], l: [SX + 0.8, W + 0.85, 2.6], fov: 55, tag: "climb5" },

  // ---------- THE ROOM OF WISHES ----------
  { p: [SX,   W + EYE,  1.9], l: [0.6,  W + 1.6, -0.5], fov: 56, tag: "wishfoot" },
  // NOTE: this key was previously also tagged "wishes", duplicating the
  // ground-floor gifts→wishes key. Duplicate tags silently overwrite each
  // other in the tag→scroll lookup, which broke the wish-card window, the
  // indoor confetti and two captions. The upper-floor key is now unique.
  { p: [0.5,  W + EYE, -0.9], l: [0,    W + 1.75, -4.3], fov: 52, tag: "wishroom" },
  { p: [-1.4, W + EYE,  0.2], l: [SX,   W + 2.6,  1.6], fov: 55, tag: "wishturn" },

  // ---------- THIRD FLIGHT (wishes → rooftop, into the back) ----------
  { p: [SX, onF3(1.0),   1.0], l: [SX - 0.2, onF3(1.0) + 1.6, -1.2], fov: 55, tag: "climb6" },
  { p: [SX, onF3(-0.8), -0.8], l: [SX - 0.4, onF3(-0.8) + 1.5, -2.8], fov: 54, tag: "climb7" },
  { p: [SX, R + EYE,    -2.7], l: [-1.0, R + 1.3, -4.6], fov: 58, tag: "emerging" },

  // ---------- THE DARKROOM ----------
  // The spline through the shed door overshot its Catmull-Rom control
  // points and clipped the door's right jamb ("aar paar"). The keys are
  // tucked toward the door centre and the shed door was widened to match
  // (see Architecture.js), so the path stays inside the opening.
  // (V15 QA: darkdoor moved to x=1.25 so the approach crosses the door
  // plane at x≈1.7 — the middle of the opening — instead of grazing the
  // right jamb at x≈2.1.)
  { p: [1.25, R + EYE, -0.15], l: [1.7, R + 1.5, -2.2], fov: 58, tag: "darkdoor" },
  { p: [2.02, R + EYE, -2.35], l: [2.3, R + 1.45, -4.4], fov: 56, tag: "darkroom" },
  // Kept in line with the shed door (x ≈ 1.1–2.3): the old key let the
  // spline's overshoot ride the door's right jamb, and on mobile the
  // pushed-back key put the camera back inside the shed wall.
  { p: [1.1,  R + EYE,  0.3],  l: [-1.5, R + 1.5, 3.0], fov: 58, tag: "bayout" },

  // ---------- ROOFTOP ----------
  { p: [-2.4, R + 1.78, 4.6], l: [0.8,  R + 1.5, -1.6], fov: 60, tag: "terrace" },
  { p: [1.5,  R + 1.72, 4.2], l: [3.9,  R + 1.05, 2.2], fov: 46, tag: "roofcake" },
  { p: [0,    R + 2.05, 8.4], l: [0,   R + 2.05,  1.2], fov: 50, tag: "reveal" },
  { p: [0,    R + 3.1, 13.5], l: [0,   R + 1.7,  0.4], fov: 54, tag: "pullback" },
  { p: [-6,   R + 5.6,  23],  l: [0,   R + 1.2, -1.0], fov: 52, tag: "final" }
];

/* Scroll budget per segment (segment i = key i -> key i+1). */
const WEIGHTS = [
  // intro hold — the title cards + note play across these three segments
  2.0, 1.8, 1.6,
  // approach
  1.0, 0.9, 0.9, 0.8, 0.8, 0.7, 0.7, 0.7,
  // ground floor
  0.7, 0.8,
  // the cake ceremony — the set piece of the whole house
  0.9, 1.2, 1.2, 1.1, 1.2, 1.3, 1.3, 1.2,
  // gifts + wishes
  1.2, 1.2,
  // to the stairs
  0.8, 0.8,
  // climbing
  0.8, 0.8, 0.8, 0.9,
  // upper floor
  0.9, 0.9, 1.5, 1.0,
  // second flight + the room of wishes
  0.8, 0.8, 0.8, 0.7, 1.6, 0.7,
  // third flight + the darkroom
  0.8, 0.8, 0.7, 0.7, 1.6, 0.6,
  // rooftop + reveal + finale
  1.0, 1.1, 1.5, 1.3, 1.0
];

export function createRig(camera, quality) {
  /* Mobile runs a much wider field of view, which puts walls right in
     the lens. Rather than a different path, every key is pushed back
     along its own view vector so the same choreography simply sits
     further from whatever it is looking at. */
  const keyPts = KEYS.map(k => new THREE.Vector3(...k.p));
  const lookAt = KEYS.map(k => new THREE.Vector3(...k.l));
  if (quality.mobile) {
    const back = new THREE.Vector3();
    // rooms need a step back on a narrow screen; the staircase does NOT —
    // stepping back there would lift the camera off the treads again.
    // "bayout" is deliberately NOT roomy: it already stands clear of the
    // shed, and pushing it back along its view vector put the camera back
    // INSIDE the shed — through the door's right jamb.
    const ROOMY = /^(enter|room|cake-|gifts|wishes|wishroom|turn|upper|gallery|memorywall|hallway|roofcake|terrace|wishfoot|wishturn|darkdoor|darkroom)/;
    const ONSTAIR = /^(stairfoot|climb|stairtop|roofstair|emerging)/;
    keyPts.forEach((p, i) => {
      const tag = KEYS[i].tag;
      if (ONSTAIR.test(tag)) return;                    // stay on the steps
      back.copy(p).sub(lookAt[i]);
      const d = back.length();
      if (d <= 0.001) return;
      if (ROOMY.test(tag)) {
        back.normalize().multiplyScalar(Math.min(1.7, d * 0.55));
        p.add(back);
        p.y += 0.12;
      } else {
        back.normalize().multiplyScalar(d * 0.16);
        p.add(back);
        p.y += 0.4;
      }
      if (tag.startsWith("cake-")) p.y += 0.25;
    });
  }

  /* ---------------------------------------------------------------
     A CatmullRomCurve3 does NOT place key i at u = i/segments once a
     non-uniform (centripetal) parameterisation is used — the camera
     drifted metres off the authored path and clipped floors and stairs.

     Instead we evaluate the spline ourselves, one segment at a time,
     so segment i is exactly the run from key i to key i+1. Same smooth
     tangents, but the keys are now honoured precisely.
     --------------------------------------------------------------- */
  function crSegment(pts, i, k, out) {
    const n = pts.length - 1;
    const p0 = pts[Math.max(0, i - 1)];
    const p1 = pts[i];
    const p2 = pts[Math.min(n, i + 1)];
    const p3 = pts[Math.min(n, i + 2)];
    const k2 = k * k, k3 = k2 * k;
    // Catmull-Rom basis with tension 0.5
    out.x = 0.5 * ((2 * p1.x) + (-p0.x + p2.x) * k +
      (2 * p0.x - 5 * p1.x + 4 * p2.x - p3.x) * k2 +
      (-p0.x + 3 * p1.x - 3 * p2.x + p3.x) * k3);
    out.y = 0.5 * ((2 * p1.y) + (-p0.y + p2.y) * k +
      (2 * p0.y - 5 * p1.y + 4 * p2.y - p3.y) * k2 +
      (-p0.y + 3 * p1.y - 3 * p2.y + p3.y) * k3);
    out.z = 0.5 * ((2 * p1.z) + (-p0.z + p2.z) * k +
      (2 * p0.z - 5 * p1.z + 4 * p2.z - p3.z) * k2 +
      (-p0.z + 3 * p1.z - 3 * p2.z + p3.z) * k3);
    return out;
  }

  // kept only so external tools can still sample the shape
  const posCurve = {
    getPoint(u, out = new THREE.Vector3()) {
      const n = keyPts.length - 1;
      const f = Math.max(0, Math.min(0.999999, u)) * n;
      const i = Math.floor(f);
      return crSegment(keyPts, i, f - i, out);
    }
  };
  const lookCurve = {
    getPoint(u, out = new THREE.Vector3()) {
      const n = lookAt.length - 1;
      const f = Math.max(0, Math.min(0.999999, u)) * n;
      const i = Math.floor(f);
      return crSegment(lookAt, i, f - i, out);
    }
  };

  /* ---------------------------------------------------------------
     PACING — every key segment gets its own scroll budget.
     --------------------------------------------------------------- */
  const segCount = KEYS.length - 1;
  const w = [];
  for (let i = 0; i < segCount; i++) w.push(WEIGHTS[i] ?? 1);
  const wTotal = w.reduce((a, b) => a + b, 0);
  // cumulative scroll position of each key, 0..1
  const keyAt = [0];
  let acc = 0;
  for (let i = 0; i < segCount; i++) { acc += w[i] / wTotal; keyAt.push(acc); }

  /** scroll position (0-1) of an authored key, by tag */
  const TAG_AT = {};
  KEYS.forEach((k, i) => { TAG_AT[k.tag] = keyAt[i]; });
  const tAt = tag => TAG_AT[tag] ?? 0;

  /** scroll t (0-1) -> normalised curve u (0-1) on the piecewise spline */
  function tToU(t) {
    const x = Math.max(0, Math.min(0.999999, t));
    let i = 0;
    while (i < segCount - 1 && x >= keyAt[i + 1]) i++;
    const span = keyAt[i + 1] - keyAt[i] || 1;
    let k = (x - keyAt[i]) / span;
    k = k * k * (3 - 2 * k);
    return (i + k) / segCount;
  }

  const _p = new THREE.Vector3();
  const _l = new THREE.Vector3();
  const smooth = {
    p: new THREE.Vector3(...KEYS[0].p),
    l: new THREE.Vector3(...KEYS[0].l),
    fov: KEYS[0].fov
  };
  let inited = false;

  function fovAt(t) {
    const x = Math.max(0, Math.min(0.999999, t));
    let i = 0;
    while (i < segCount - 1 && x >= keyAt[i + 1]) i++;
    const span = keyAt[i + 1] - keyAt[i] || 1;
    let k = (x - keyAt[i]) / span;
    k = k * k * (3 - 2 * k);
    return KEYS[i].fov + (KEYS[i + 1].fov - KEYS[i].fov) * k;
  }

  const indoorFrom = tAt("threshold");
  const indoorTo = tAt("emerging");

  /**
   * @param {number} t      0-1 scroll progress
   * @param {object} mouse  {x,y} -1..1 pointer, for parallax sway
   * @param {number} dt     delta seconds (framerate-independent smoothing)
   */
  function update(t, mouse, dt = 1 / 60) {
    // resolve which authored segment we are in, and how far along it
    const x = Math.max(0, Math.min(0.999999, t));
    let si = 0;
    while (si < segCount - 1 && x >= keyAt[si + 1]) si++;
    const span = keyAt[si + 1] - keyAt[si] || 1;
    let k = (x - keyAt[si]) / span;
    k = k * k * (3 - 2 * k);                  // ease within the segment
    crSegment(keyPts, si, k, _p);
    crSegment(lookAt, si, k, _l);

    // pointer sway: free outdoors, tightly restrained indoors so the
    // camera can never be nudged through a wall
    const indoor = Math.min(1, Math.max(0,
      Math.min((t - indoorFrom) / 0.04, (indoorTo - t) / 0.04, 1)));
    const swayAmt = (1 - indoor * 0.88) * (quality.mobile ? 0.4 : 1);
    _p.x += mouse.x * 1.1 * swayAmt;
    _p.y -= mouse.y * 0.65 * swayAmt;
    _l.x += mouse.x * 0.3 * swayAmt;
    _l.y -= mouse.y * 0.2 * swayAmt;

    const targetFov = fovAt(t) + (quality.mobile ? 5 : 0);

    if (!inited) {
      smooth.p.copy(_p); smooth.l.copy(_l); smooth.fov = targetFov;
      inited = true;
    } else {
      const kk = 1 - Math.pow(0.0016, dt);
      smooth.p.lerp(_p, kk);
      smooth.l.lerp(_l, kk);
      smooth.fov += (targetFov - smooth.fov) * kk;
    }

    camera.position.copy(smooth.p);
    camera.lookAt(smooth.l);
    if (Math.abs(camera.fov - smooth.fov) > 0.01) {
      camera.fov = smooth.fov;
      camera.updateProjectionMatrix();
    }
  }

  return { update, KEYS, posCurve, lookCurve, keyAt, tToU, tAt, TAG_AT };
}
