/* =============================================================
   HOUSE SCENE — orchestrator
   Owns the renderer, the scene graph, the lighting rig and the
   per-frame animation. Scroll progress (0-1) drives everything:
   camera, interior lighting, sky warmth, reveal and confetti.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { buildMaterials } from "./materials.js";
import { buildArchitecture, DIM } from "./Architecture.js";
import { buildInteriors } from "./Interiors.js";
import { buildEnvironment } from "./Environment.js";
import { createRig } from "./CameraRig.js";
import { preloadPhotos } from "./PhotoFrame.js";
import { mergeStatics, createGlowCloud, report } from "./optimize.js";
import { createCeremony, ceremonyRange } from "./Ceremony.js";
import { buildMagic } from "./Magic.js";

export function createHouseScene(canvas, opts = {}) {
  const mobile = opts.mobile ?? matchMedia("(max-width: 820px)").matches;
  const reduce = opts.reduce ?? false;

  /* ---------------- quality profile ---------------- */
  const gl0 = canvas.getContext("webgl2") || canvas.getContext("webgl");
  const maxAniso = gl0 ? (gl0.getExtension("EXT_texture_filter_anisotropic")
    ? gl0.getParameter(gl0.getExtension("EXT_texture_filter_anisotropic").MAX_TEXTURE_MAX_ANISOTROPY_EXT) : 1) : 1;
  const quality = {
    mobile,
    shadows: !mobile,
    transmission: false,
    aniso: Math.min(mobile ? 2 : 8, maxAniso || 1),
    // perf: phones are almost always fill-rate bound here (lots of
    // overlapping transparency/glow/fog), so the initial mobile cap
    // comes down a notch — the adaptive scaler below can still step it
    // back up if the device turns out to have headroom.
    dpr: Math.min(devicePixelRatio || 1, mobile ? 1.35 : 1.9)
  };

  /* ---------------- renderer ---------------- */
  const renderer = new THREE.WebGLRenderer({
    canvas, antialias: !mobile, alpha: true,
    powerPreference: "high-performance", stencil: false
  });
  renderer.setPixelRatio(quality.dpr);
  renderer.setSize(innerWidth, innerHeight, false);
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;
  if (quality.shadows) {
    /* ---- perf pass: shadows ----
       One shadow-casting key light (moonKey, below) is all the scene
       ever uses — every interior/rooftop light stays shadow-free on
       purpose, so the renderer only ever fills a single shadow map.
       A hard 512x512 PCFShadowMap (instead of the 1536x1536 soft map)
       cuts the shadow pass cost by >8x, which is where the frame-time
       spikes/stutter were coming from; at this camera distance the
       softer PCFSoftShadowMap's extra samples weren't buying anything
       visible anyway. */
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFShadowMap;
  }

  const scene = new THREE.Scene();
  scene.fog = new THREE.FogExp2(0x1b1430, 0.0052);
  const FOG_BASE = 0.0052;

  const camera = new THREE.PerspectiveCamera(46, innerWidth / innerHeight, 0.1, 700);
  camera.position.set(0, 12.5, 46);

  /* ---------------- build the world ---------------- */
  const M = buildMaterials(quality);
  const env = buildEnvironment(scene, M, quality);
  const arch = buildArchitecture(scene, M, quality);
  const int = buildInteriors(scene, M, quality);
  const rig = createRig(camera, quality);
  /* the three add-on features — built BEFORE the glow collection so
     their halo sprites join the additive cloud like every other glow */
  const magic = buildMagic(scene, M, quality, rig.tAt);

  /* =============================================================
     OPTIMISATION PASS
     1. every little glow Sprite becomes one point in a Points cloud
     2. every static mesh is merged per-material
     Both run once, before the first frame.
     ============================================================= */

  // --- 1. gather all sprites into a single additive cloud ---
  const glowEntries = [];
  const spriteRefs = [];
  scene.updateMatrixWorld(true);
  const ceremonyHalos = new Set(int.anim.cake ? int.anim.cake.userData.halos : []);
  // the disco ball's halo is driven directly every frame (opacity pulse,
  // gated by the "party" amount) — it must stay a real Sprite, not get
  // folded into the shared glow cloud like the one-off decorative glows.
  if (int.anim.disco && int.anim.disco.halo) ceremonyHalos.add(int.anim.disco.halo);
  scene.traverse(o => {
    if (!o.isSprite) return;
    if (ceremonyHalos.has(o)) return;      // driven directly, not by the shared cloud
    const wp = new THREE.Vector3();
    o.getWorldPosition(wp);
    glowEntries.push({
      position: wp,
      color: o.material.color ? o.material.color.getHex() : 0xffc98a,
      size: (o.scale.x || 0.4) * 0.30,
      brightness: o.material.opacity ?? 0.5
    });
    spriteRefs.push(o);
  });
  const glow = createGlowCloud(scene, glowEntries, { sizeScale: 1 });
  // remap animation targets from Sprites -> cloud indices
  const spriteIndex = new Map();
  spriteRefs.forEach((sp, i) => spriteIndex.set(sp, i));
  const haloIdx   = int.anim.halos.map(h => spriteIndex.get(h)).filter(i => i !== undefined);
  const bulbIdx   = int.anim.bulbs.map(b => ({ i: spriteIndex.get(b.halo), seed: b.seed, bulb: b.bulb }))
                                  .filter(o => o.i !== undefined);
  // the magic features' halos join the same cloud
  magic.bindGlow(glow, sp => spriteIndex.get(sp));
  const emberIdx  = int.anim.sprites.map(s => ({ i: spriteIndex.get(s.sprite), base: s.base, amp: s.amp, speed: s.speed }))
                                    .filter(o => o.i !== undefined);
  const lanternIdx= env.anim.lanterns.map((l, j) => ({ i: spriteIndex.get(l.halo), seed: l.seed, j }))
                                 .filter(o => o.i !== undefined);
  spriteRefs.forEach(sp => { sp.removeFromParent(); sp.material.dispose(); });

  /* ---- the porch halo joins the cloud too (it wakes with the door) ---- */
  const porchIdx = int.anim.porch ? spriteIndex.get(int.anim.porch.halo) : undefined;
  const eggIdx = int.anim.easterEgg ? spriteIndex.get(int.anim.easterEgg.halo) : undefined;

  /* ---- classify the string-light bulbs by where they hang ----
     ground floor (always on) · balcony run (wakes with the garden) ·
     rooftop canopy (the staged finale reveal). World height is a
     reliable separator: G+3.9 / U+3.0 / R+2.2..3.4. */
  const _bp = new THREE.Vector3();
  bulbIdx.forEach(b => {
    if (!b.bulb) { b.zone = "ground"; return; }
    b.bulb.getWorldPosition(_bp);
    b.zone = _bp.y > 10.5 ? "roof" : (_bp.y > 6.5 ? "balcony" : "ground");
  });

  /* ---- GPU animation: bulbs → shader ----
     The flicker + wake curve above used to run as a JS loop over every
     bulb, every frame (dozens of Math.sin calls + a full buffer
     re-upload). It's now baked into the glow cloud's own vertex shader
     (see createGlowCloud): each bulb is tagged once, here, at startup —
     after that the render loop only ever writes a handful of uniforms. */
  const ZONE_NUM = { ground: 0, balcony: 1, roof: 2 };
  bulbIdx.forEach(b => {
    if (glow && b.i !== undefined) glow.setBulb(b.i, { seed: b.seed, zone: ZONE_NUM[b.zone] ?? 0 });
  });
  if (glow) {
    glow.flushBulbSetup();
    glow.mat.uniforms.uRoofA.value = rig.tAt("terrace");
    glow.mat.uniforms.uRoofS.value = rig.tAt("reveal") - rig.tAt("terrace");
  }

  // --- 2. mark everything the loop animates as dynamic, then merge the rest ---
  const dynamic = [
    ...int.anim.flames, ...int.anim.balloons, ...int.anim.flags,
    ...int.anim.bulbs.map(b => b.bulb),
    // the speakers' LEDs blink on and off — they can never be merged
    ...(int.anim.speakers || []).map(s => s.userData && s.userData.led).filter(Boolean)
  ];
  // the ceremony cake animates every part of itself — exclude it entirely
  if (int.anim.cake) {
    int.anim.cake.userData.dynamic = true;
    int.anim.cake.traverse(o => { o.userData.dynamic = true; });
  }
  if (int.anim.reveal) dynamic.push(int.anim.reveal.group, ...int.anim.reveal.planes);
  dynamic.forEach(o => { if (o) o.userData.dynamic = true; });
  // photo frames must never be merged: they carry unique textures and
  // merging would break the careful per-frame depth separation
  scene.traverse(o => {
    if (o.isMesh && o.material && o.material.map &&
        o.material.map.image && o.material.map.image.src &&
        o.material.map.image.src.includes("/photos/")) {
      o.userData.dynamic = true;
      let p = o.parent;
      if (p) p.userData.dynamic = true;
    }
  });
  // shader-driven env objects
  [env.anim.fireflies?.points, env.anim.confetti?.points].forEach(o => { if (o) o.userData.dynamic = true; });

  /* ---- zone-based geometry visibility (perf pass 2) ----
     Three.js has no occlusion culling: without this, every triangle of
     the whole house — every room's furniture, the rooftop dance floor,
     every tree and flower in the garden — is submitted to the GPU on
     every single frame, no matter which of those the camera can
     actually see right now. That's the biggest reason the approach
     across the garden (and the first moment the house scene appears at
     all) felt heavier than everywhere else: the camera is furthest
     back and widest there, so nothing is off-frustum either, on top of
     paying for the entire indoor+rooftop scene it can't even see yet.
     Every static mesh below is tagged with which zone it can possibly
     be seen from; mergeStatics (next line) keeps each zone's batch
     separate so it can be switched off outright — same trick as the
     interior/rooftop LIGHT zoning above, just for geometry. */
  env.group.traverse(o => {
    if (o.isMesh && !o.userData.alwaysVisible && !o.userData.dynamic) o.userData.zoneHint = "outdoor";
  });
  {
    const _fp = new THREE.Vector3();
    int.root.traverse(o => {
      if (!o.isMesh || o.userData.dynamic) return;
      o.getWorldPosition(_fp);
      o.userData.zoneHint = _fp.y > 10.5 ? "roof" : "lower";
    });
  }

  const mergeStats = mergeStatics(scene, { minGroup: 2 });
  // visible = f(zone): see the render loop below, right next to the
  // fireflies/smoke toggle it mirrors.
  const zoneMeshes = mergeStats.zoned || [];
  let lastGeoZone = null;
  function applyZoneVisibility(zone) {
    if (zone === lastGeoZone) return;
    lastGeoZone = zone;
    const outdoorOn = zone === "exterior" || zone === "garden";
    const lowerOn = zone !== "exterior" && zone !== "garden";
    const roofOn = zone === "rooftop" || zone === "finale";
    for (let i = 0; i < zoneMeshes.length; i++) {
      const zm = zoneMeshes[i];
      zm.visible = zm.userData.zone === "outdoor" ? outdoorOn
        : zm.userData.zone === "roof" ? roofOn
        : lowerOn;
    }
  }

  // everything left standing is static: stop three.js recomputing its
  // world matrix 60 times a second
  scene.traverse(o => {
    if (o.isMesh && !o.userData.dynamic && !o.isPoints) {
      o.updateMatrixWorld(true);
      o.matrixAutoUpdate = false;
    }
  });

  /* ---------------- global lighting rig ---------------- */
  const hemi = new THREE.HemisphereLight(0x6d7cba, 0x241a34, 0.85);
  scene.add(hemi);

  const moonKey = new THREE.DirectionalLight(0xb3c5ff, 1.35);
  moonKey.position.set(-60, 46, -70);
  if (quality.shadows) {
    // the ONE shadow-casting light in the whole scene (see renderer setup
    // above) — a small, hard 512x512 map instead of the old 1536x1536 one
    moonKey.castShadow = true;
    moonKey.shadow.mapSize.set(512, 512);
    moonKey.shadow.camera.near = 10;
    moonKey.shadow.camera.far = 190;
    const s = 26;
    moonKey.shadow.camera.left = -s; moonKey.shadow.camera.right = s;
    moonKey.shadow.camera.top = s;   moonKey.shadow.camera.bottom = -s;
    // a hard map without PCF's soft kernel needs a touch more bias to
    // avoid acne at this resolution
    moonKey.shadow.bias = -0.0011;
    moonKey.shadow.normalBias = 0.045;
  }
  scene.add(moonKey);

  // warm rim from the house itself, so the building never goes flat
  const rim = new THREE.PointLight(0xffa860, 6, 40, 2);
  rim.position.set(0, DIM.F1, DIM.D / 2 + 4);
  scene.add(rim);

  const ambient = new THREE.AmbientLight(0xffe4c4, 0.3);
  scene.add(ambient);

  /* ---------------- preload every photo texture up front ----------------
     Guarantees textures exist before a frame is ever drawn, which
     removes the last possible source of pop-in / flicker.            */
  const hp = window.BDAY_CONFIG.house.photos;
  const base = window.BDAY_CONFIG.paths.photos;
  // every small photo preloads once — the house set plus the small
  // versions used by the gifts, the mirror pass and the constellation
  const allSm = [];
  for (let i = 1; i <= 17; i++) allSm.push(base + "p" + String(i).padStart(2, "0") + "_sm.webp");
  preloadPhotos([
    ...hp.mantel.map(i => base + i + "_sm.webp"),
    ...hp.sideTable.map(i => base + i + "_sm.webp"),
    ...hp.stairs.map(i => base + i + "_sm.webp"),
    ...hp.memoryWall.map(i => base + i + ".webp"),
    ...hp.hallway.map(i => base + i + "_sm.webp"),
    ...hp.rooftop.map(i => base + i + ".webp"),
    ...allSm
  ], quality.aniso);

  /* ---------------- the windows that wake one by one ----------------
     Each pane now owns its material. The approach sequence settles the
     whole house to embers, then walks the windows back on in narrative
     order: the one light that was "on all evening", the ground floor,
     the sides, the upper floor — full again by the portico. */
  const wakePanes = [];
  arch.windows.forEach((w, idx) => {
    const m = w.pane && w.pane.material;
    if (!m || m.emissiveIntensity === undefined) return;
    const p = w.group.position;
    const upper = p.y > 6, front = p.z > 4, side = Math.abs(p.x) > 5;
    let rank;
    if (upper && front && p.x < 0) rank = 0;          // "there's a light on"
    else if (!upper && front)     rank = 1;           // the ground floor
    else if (!upper && side)      rank = 2;           // along the sides
    else if (upper && front)      rank = 3;
    else if (upper && side)       rank = 4;
    else if (!upper)              rank = 5;           // the back, last
    else                          rank = 6;
    wakePanes.push({ m, rank, jitter: (idx % 3) * 0.34 });
  });
  wakePanes.sort((a, b) => (a.rank - b.rank) || (a.jitter - b.jitter));
  // the single window that never goes out
  const EMBER_FIRST = 0.55, EMBER = 0.12;

  /* ---------------- the cake ceremony ---------------- */
  const cakeLight = int.lights.find(l => l.userData && l.userData.kind === "cake");
  const ceremony = int.anim.cake
    ? createCeremony(int.anim.cake, {
        cakeLight,
        tAt: rig.tAt,
        onBlown: () => {
          if (window.BdayAudio && window.BdayAudio.enabled) window.BdayAudio.wishChime();
          window.dispatchEvent(new Event("house:candles-blown"));
        }
      })
    : null;
  const cerRange = ceremonyRange(rig.tAt);
  // gifts + wishes live just after the cake
  const GIFT_A = rig.tAt("cake-slice"), GIFT_B = rig.tAt("gifts"), GIFT_C = rig.tAt("wishes"),
        GIFT_END = rig.tAt("stairfoot");

  /* ---------------- per-frame state ---------------- */
  const A = int.anim;
  const EA = env.anim;
  const DPR_MAX = Math.min(devicePixelRatio || 1, mobile ? 1.35 : 1.9);
  const DPR_MIN = Math.min(DPR_MAX, mobile ? 0.75 : 1.25);   // never soft, only lighter
  let dprNow = DPR_MAX;
  let frameAvg = 1 / 60;
  let lastDprChange = 0;
  let shadowBake = quality.shadows ? 4 : 0;
  let progress = 0;
  const mouse = { x: 0, y: 0, tx: 0, ty: 0 };
  const clock = new THREE.Clock();
  let lastT = 0;
  let lastPop = -9;

  // cache the base intensity of every interior light so we can dim/raise as a set
  int.lights.forEach(l => { l.userData.baseIntensity = l.intensity; });

  /* ---- distance culling ----
     Forward rendering pays for every enabled light on every fragment.
     Lights far behind the camera contribute nothing visible, so we
     switch them off. Cheap check, large win, no visual difference. */
  /* ---- light budget ----
     Forward rendering pays for every enabled light on every fragment, and
     the house has 26 of them. Only the handful nearest the camera can
     actually be seen at any moment, so the rest are switched off. The list
     is re-sorted a few times a second, not every frame. */
  const cullable = int.lights.filter(l => l.isPointLight || l.isSpotLight);
  const MAX_LIGHTS = quality.mobile ? 5 : 11;
  const _lp = new THREE.Vector3();
  cullable.forEach(l => {
    const reach = (l.distance || 12) + 4;
    l.userData.reach2 = reach * reach;
  });

  /* ---- zone activation ----
     Every interior light above is tagged with the area of the house it
     belongs to (`zone: "interior" | "rooftop" | "finale"`, set in
     Interiors.js). The camera's scroll position maps onto five zones —
     far exterior, garden, interior, rooftop, finale — and a light whose
     zone isn't the current one is never even a *candidate* for the
     distance budget below: the whole "far exterior" and "garden" legs
     of the journey run with zero interior/rooftop/finale lights active
     (nothing to see through the walls yet anyway), and each floor only
     pays for its own room lights once the camera actually arrives. This
     stacks with the distance budget below, and reuses the same flip
     hysteresis, so crossing a boundary never fires more than a couple
     of shader recompiles at once. */
  const ZONE_END = {
    exterior: rig.tAt("garden"),
    garden:   rig.tAt("threshold"),
    interior: rig.tAt("emerging"),
    rooftop:  rig.tAt("reveal")
  };
  function zoneOf(p) {
    if (p < ZONE_END.exterior) return "exterior";
    if (p < ZONE_END.garden) return "garden";
    if (p < ZONE_END.interior) return "interior";
    if (p < ZONE_END.rooftop) return "rooftop";
    return "finale";
  }

  const ranked = [];
  let cullT = -1;
  function cullLights(t) {
    if (t - cullT < 0.12) return;
    cullT = t;
    const zone = zoneOf(progress);
    ranked.length = 0;
    for (let i = 0; i < cullable.length; i++) {
      const l = cullable[i];
      const lz = l.userData.zone;
      const zoneOk = !lz || lz === zone;
      l.getWorldPosition(_lp);
      const d2 = _lp.distanceToSquared(camera.position);
      const want = zoneOk && d2 < l.userData.reach2;
      ranked.push({ l, d2, want, rank: 0 });
    }
    ranked.sort((a, b) => a.d2 - b.d2);
    // hysteresis: a light only flips state when it has WANTED the new
    // state for 0.4 s. Every flip changes the shader's light count and
    // forces a recompile — one hitch — so flips must be rare and certain.
    let flips = 0;
    for (let i = 0; i < ranked.length; i++) {
      const r = ranked[i];
      const on = r.want && i < MAX_LIGHTS;
      if (r.l.visible === on) { r.l.userData._since = 0; continue; }
      r.l.userData._since = (r.l.userData._since || 0) + 0.12;
      if (r.l.userData._since >= 0.4 && flips < 2) {
        r.l.visible = on;
        r.l.userData._since = 0;
        flips++;
      }
    }
  }

  function setProgress(t) { progress = Math.max(0, Math.min(1, t)); }
  function setPointer(x, y) { mouse.tx = x; mouse.ty = y; }

  function render() {
    const t = clock.getElapsedTime();
    const dt = Math.min(0.05, t - lastT);
    lastT = t;

    /* ---- adaptive resolution ----
       Geometry, lighting and textures never change: only the number of
       pixels does, and only if the machine is genuinely struggling. On a
       healthy machine it sits at full quality and never moves. */
    if (dt > 0.0001) {
      frameAvg = frameAvg * 0.92 + dt * 0.08;
      if (t - lastDprChange > 1.4) {
        if (frameAvg > 0.026 && dprNow > DPR_MIN) {           // under ~38 fps
          dprNow = Math.max(DPR_MIN, dprNow - 0.25);
          renderer.setPixelRatio(dprNow);
          lastDprChange = t;
        } else if (frameAvg < 0.0155 && dprNow < DPR_MAX) {   // comfortably over 60
          dprNow = Math.min(DPR_MAX, dprNow + 0.15);
          renderer.setPixelRatio(dprNow);
          lastDprChange = t;
        }
      }
    }

    /* ---- shadows are baked ----
       Nothing that casts a meaningful shadow ever moves, so the shadow
       map is rendered for the first few frames and then frozen. This is
       the single biggest saving in the scene, and it is invisible. */
    if (shadowBake > 0) {
      shadowBake--;
      renderer.shadowMap.needsUpdate = true;
      if (shadowBake === 0) renderer.shadowMap.autoUpdate = false;
    }

    mouse.x += (mouse.tx - mouse.x) * 0.045;
    mouse.y += (mouse.ty - mouse.y) * 0.045;

    rig.update(progress, mouse, dt);

    /* ---- the wake-up choreography, one place, pure functions of scroll ----
       windows settle to embers → wake one by one · porch light with the door ·
       garden lanterns · balcony string lights · stair sconces on the climb ·
       the gallery focus moment · the staged rooftop reveal. Every value is
       derived from camera-key tags, so scrubbing back replays it in reverse. */
    const T = rig.tAt, pr = progress;
    const wake = {
      settle:  smoothstep(T("far"),      T("arc"),        pr),   // lit → embers
      winFull: smoothstep(T("arc"),      T("portico"),    pr),   // embers → all on
      door:    smoothstep(T("portico"),  T("threshold"),  pr),
      porch:   smoothstep(T("steps"),    T("threshold"),  pr),
      garden:  smoothstep(T("garden"),   T("portico"),    pr),
      balcony: smoothstep(T("garden"),   T("threshold"),  pr),
      stairs1: smoothstep(T("turn"),     T("stairfoot"),  pr),
      stairs2: smoothstep(T("stairtop"), T("emerging"),   pr),
      focus:   smoothstep(T("upper"),    T("memorywall"), pr)
               * (1 - smoothstep(T("memorywall"), T("roofstair"), pr)),
      roof:    smoothstep(T("terrace"),  T("reveal"),     pr)
    };

    /* ---- flames: subtle, natural, never strobing ---- */
    for (let i = 0; i < A.flames.length; i++) {
      const f = A.flames[i];
      const s = f.userData.seed;
      const w = Math.sin(t * 6.1 + s) * 0.5 + Math.sin(t * 11.3 + s * 2) * 0.28;
      f.scale.set(1 + w * 0.07, 1.9 + w * 0.2, 1 + w * 0.07);
      f.position.y = f.userData.baseY + w * 0.004;
    }
    for (let i = 0; i < haloIdx.length; i++) {
      glow.setBrightness(haloIdx[i], 0.44 + Math.sin(t * 5.4 + i) * 0.1);
    }

    /* ---- string light bulbs: slow, offset breathing ----
       GPU animation now: the whole flicker + wake curve for every bulb
       runs in the glow cloud's vertex shader (see createGlowCloud /
       glow.setBulb at setup). Per frame this is 3 uniform writes total,
       not a loop over every bulb. */
    glow.mat.uniforms.uTime.value = t;
    glow.mat.uniforms.uWakeBalcony.value = wake.balcony;
    glow.mat.uniforms.uProgress.value = pr;

    /* ---- balloons: gentle float + tilt ---- */
    for (let i = 0; i < A.balloons.length; i++) {
      const b = A.balloons[i];
      const s = b.userData.seed || i;
      b.position.y += Math.sin(t * 0.85 + s) * 0.0022;
      b.rotation.z = Math.sin(t * 0.62 + s) * 0.075;
      b.rotation.x = Math.cos(t * 0.51 + s) * 0.05;
    }

    /* ---- banner flags ---- */
    for (let i = 0; i < A.flags.length; i++) {
      const f = A.flags[i];
      f.rotation.x = Math.sin(t * 1.25 + f.userData.seed) * 0.14;
    }

    /* ---- the ceremony (driven by absolute scroll, key by key) ---- */
    if (ceremony) ceremony.update(progress, t);

    /* ---- the three add-on features: gifts, mirror, constellation ---- */
    magic.update(progress, t, mouse, camera, glow);

    /* ---- the room of wakes: lights rise, lanterns sway ---- */
    if (int.anim.wishLanterns) {
      const on = smoothstep(T("climb5"), T("wishfoot"), pr);
      for (let i = 0; i < int.lights.length; i++) {
        const L = int.lights[i];
        if (L.userData && L.userData.kind === "wishroom")
          L.intensity = (L.userData.baseWish || 3.5) * (0.15 + 0.85 * on);
      }
      for (let i = 0; i < int.anim.wishLanterns.length; i++) {
        const g = int.anim.wishLanterns[i];
        g.rotation.z = Math.sin(t * 0.7 + i * 1.3) * 0.05;
        g.rotation.x = Math.cos(t * 0.6 + i) * 0.04;
      }
    }

    /* ---- the darkroom: negatives develop in the red light ---- */
    if (int.anim.negatives) {
      const a = T("darkdoor"), b = T("bayout");
      for (let i = 0; i < int.anim.negatives.length; i++) {
        const n = int.anim.negatives[i];
        const o = smoothstep(a + (b - a) * (0.12 + i * 0.2), a + (b - a) * (0.5 + i * 0.2), pr);
        n.dev.material.opacity = o;
        n.dev.visible = o > 0.01;
      }
      const warm = smoothstep(a, b, pr);
      for (let i = 0; i < int.lights.length; i++) {
        const L = int.lights[i];
        if (L.userData && L.userData.kind === "darkroom") {
          L.color.setHSL(0.015 + 0.065 * warm, 0.88 - 0.4 * warm, 0.5);
          L.intensity = L.userData.baseIntensity * (0.7 + 0.55 * warm);
        }
      }
      if (int.anim.darkBulb) {
        int.anim.darkBulb.material.color.setHSL(0.015 + 0.065 * warm, 0.8, 0.55);
        int.anim.darkBulb.material.emissive.setHSL(0.015 + 0.065 * warm, 0.9, 0.3 + 0.25 * warm);
      }
    }

    /* ---- gifts + wishes ---- */
    {
      const giftsUp = smoothstep(GIFT_A, GIFT_B, progress) * (1 - smoothstep(GIFT_C, GIFT_END, progress));
      if (A.giftLight) A.giftLight.intensity = giftsUp * 9;
      const wishUp = smoothstep(GIFT_B, GIFT_C, progress);
      const wishOut = smoothstep(GIFT_C + 0.005, GIFT_END, progress);
      if (A.wishCards) {
        for (let i = 0; i < A.wishCards.length; i++) {
          const c = A.wishCards[i];
          const d = i / Math.max(1, A.wishCards.length);
          const inAmt = smoothstep(d * 0.55, 0.55 + d * 0.45, wishUp);
          const o = inAmt * (1 - wishOut);
          c.material.opacity = o * 0.96;
          c.visible = o > 0.01;
          c.position.y = c.userData.baseY + (1 - inAmt) * -0.35
                       + Math.sin(t * 0.9 + c.userData.seed) * 0.045;
          c.rotation.z = Math.sin(t * 0.7 + c.userData.seed) * 0.035;
        }
      }
      const rc = A.roomConfetti;
      if (rc) {
        // GPU particles: the shader computes fall/sway/loop from uTime;
        // the CPU only ever touches two uniforms + a visibility flag.
        const amt = smoothstep(GIFT_A, GIFT_B, progress) * (1 - smoothstep(GIFT_C, GIFT_END, progress));
        rc.points.visible = amt > 0.01;
        if (amt > 0.01) {
          rc.mat.uniforms.uTime.value = t;
          rc.mat.uniforms.uAmt.value = amt;
        }
      }
    }

    /* ---- flickering warm lights (cake, fire) ---- */
    for (let i = 0; i < A.lights.length; i++) {
      const L = A.lights[i];
      let v = L.base + Math.sin(t * L.speed + i) * L.amp * 0.5
                     + Math.sin(t * L.speed * 2.3 + i) * L.amp * 0.25;
      const cs = L.light.userData && L.light.userData.ceremonyScale;
      if (cs !== undefined) v *= cs;
      L.light.intensity = v;
    }
    for (let i = 0; i < emberIdx.length; i++) {
      const S = emberIdx[i];
      glow.setBrightness(S.i, S.base + Math.sin(t * S.speed + i) * S.amp);
    }

    /* ---- environment ---- */
    EA.water.uniforms.uTime.value = t;
    EA.stars.uniforms.uTime.value = t;
    // zone activation: fireflies/chimney-smoke are outdoor ambience —
    // once the camera is inside the walls (interior/rooftop/finale) they
    // sit behind solid geometry and are never seen, so they're skipped
    // by the renderer entirely rather than just quietly ticking along.
    const outsideZone = zoneOf(progress);
    applyZoneVisibility(outsideZone);
    EA.fireflies.points.visible = outsideZone === "exterior" || outsideZone === "garden";
    if (EA.fireflies.points.visible) EA.fireflies.mat.uniforms.uTime.value = t;
    if (EA.smoke) {
      EA.smoke.points.visible = outsideZone !== "interior";
      if (EA.smoke.points.visible) EA.smoke.mat.uniforms.uTime.value = t;
    }

    for (let i = 0; i < lanternIdx.length; i++) {
      const l = lanternIdx[i];
      // path lanterns come on one after another as the camera walks the garden
      const a = T("garden"), s = (T("portico") - a) * 0.55;
      const wk = 0.15 + 0.85 * smoothstep(a + l.j * s * 0.22, a + s + l.j * s * 0.22, pr);
      glow.setBrightness(l.i, (0.44 + Math.sin(t * 1.7 + l.seed) * 0.1) * wk);
    }
    // the easter-egg frame breathes softly, just enough to be found
    if (eggIdx !== undefined && eggIdx !== null) {
      glow.setBrightness(eggIdx, 0.26 + 0.2 * (0.5 + 0.5 * Math.sin(t * 1.9)));
    }
    glow.flush();

    /* ---- the rooftop party ---- */
    {
      const party = smoothstep(rig.tAt("climb5"), rig.tAt("terrace"), progress);
      // glowing dance floor — GPU animation now: one InstancedMesh, the
      // whole hue-cycling pulse runs in the fragment shader off uTime,
      // so this is two uniform writes instead of a 20-tile JS loop
      // rewriting a Color + emissiveIntensity on 20 separate materials.
      if (A.danceFloor) {
        A.danceFloor.mesh.visible = party > 0.01;
        if (party > 0.01) {
          A.danceFloor.mat.uniforms.uTime.value = t;
          A.danceFloor.mat.uniforms.uAmt.value = party;
        }
      }
      // mirror ball
      if (A.disco) {
        A.disco.ball.visible = party > 0.01;
        A.disco.ball.rotation.y = t * 0.9;
        if (A.disco.halo) {
          A.disco.halo.visible = party > 0.01;
          A.disco.halo.material.opacity = (0.28 + 0.22 * Math.sin(t * 2.2)) * party;
        }
      }
      // speaker LEDs blink with the beat
      if (A.speakers) {
        for (let i = 0; i < A.speakers.length; i++) {
          const led = A.speakers[i].userData.led;
          if (led) led.visible = party > 0.2 && Math.sin(t * 6.2 + i) > -0.2;
        }
      }
      // fireworks over the house
      if (EA.fireworks) {
        const fwAmt = smoothstep(rig.tAt("emerging"), rig.tAt("terrace"), progress);
        EA.fireworks.points.visible = fwAmt > 0.01;
        EA.fireworks.mat.uniforms.uAmt.value = fwAmt;
        EA.fireworks.mat.uniforms.uTime.value = t;
        // a distant thump now and then, only when the sound is on
        if (fwAmt > 0.3 && t - lastPop > 1.15 + Math.random()) {
          lastPop = t;
          if (window.BdayAudio && BdayAudio.enabled && BdayAudio.pop) BdayAudio.pop(0.55);
        }
      }
    }

    /* ---- confetti: only alive during the finale ----
       GPU particles now: the fall/sway/loop is computed in the vertex
       shader from uTime alone, so per frame this is just two uniform
       writes (no position buffer to rewrite) — and it's fully invisible
       (skipped by the renderer, not just transparent) outside the finale. */
    const finaleAmt = smoothstep(rig.tAt("roofcake"), rig.tAt("pullback"), progress);
    EA.confetti.points.visible = finaleAmt > 0.01;
    if (finaleAmt > 0.01) {
      EA.confetti.mat.uniforms.uTime.value = t;
      EA.confetti.mat.uniforms.uAmt.value = finaleAmt;
    }

    /* ---- story lighting: the house wakes up as we approach ---- */
    // the intro holds the camera far out; lift the whole scene there so the
    // house reads as a clear, deliberate establishing shot rather than a
    // dark silhouette
    const introLift = 1 - smoothstep(rig.tAt("far"), rig.tAt("side"), progress);
    const arrive = smoothstep(0.0, rig.tAt("garden"), progress);
    const inside = smoothstep(rig.tAt("steps"), rig.tAt("enter"), progress);
    rim.intensity = 4 + arrive * 6 + introLift * 13;
    hemi.intensity = 0.85 - inside * 0.32 + introLift * 0.55;
    moonKey.intensity = 1.35 - inside * 0.6 + introLift * 0.9;
    ambient.intensity = 0.30 + inside * 0.14 + introLift * 0.22;
    renderer.toneMappingExposure = 1.15 + arrive * 0.1 - inside * 0.05 + introLift * 0.26;

    scene.fog.density = FOG_BASE * (1 - introLift * 0.55);
    /* ---- the windows: settle to embers, then wake one by one ----
       During the intro they burn bright (the establishing shot keeps its
       look, introLift). As the camera leaves the cards behind, the house
         eases to embers — dusk settling, one window still on ("it's been
         on all evening") — and then, from the arc to the portico, every
         window walks back up to full in narrative order. */
    if (wakePanes.length) {
      const full = 1.1 + introLift * 1.6;
      const N = wakePanes.length;
      const span = Math.max(0.0001, wake.winFull);
      for (let i = 0; i < N; i++) {
        const w = wakePanes[i];
        const slot = (i / Math.max(1, N - 1)) * 0.72 + w.jitter * 0.05;
        const lit = smoothstep(Math.min(1, slot), Math.min(1, slot + 0.28), span);
        const ember = i === 0 ? EMBER_FIRST : (EMBER + w.jitter * 0.02);
        w.m.emissiveIntensity = full * ((1 - wake.settle) + wake.settle * (ember + (1 - ember) * lit));
      }
    }

    /* ---- the door: swings open as the camera crosses the steps ----
       Warm interior light spills out with it; the porch lantern above
         turns on a beat earlier so the entrance is already glowing. */
    if (arch.door) arch.door.rotation.y = -1.72 * wake.door;
    if (int.anim.porch) {
      const pOn = wake.porch;
      int.anim.porch.light.intensity = 5.5 * pOn;
      int.anim.porch.bulb.material.emissiveIntensity = 0.35 + 0.8 * pOn;
      if (porchIdx !== undefined && porchIdx !== null) {
        glow.setBrightness(porchIdx, 0.16 + 0.42 * pOn + Math.sin(t * 3.7) * 0.035 * pOn);
      }
    }

    /* ---- sconces warm up as the camera starts to climb ---- */
    for (let i = 0; i < int.lights.length; i++) {
      const L = int.lights[i], k = L.userData && L.userData.kind;
      if (k === "sconce") {
        const up = L.position.y > 7;
        // capped below full — the stair wall should be warm, not floodlit
        L.intensity = L.userData.baseIntensity * (up ? 0.62 + 0.26 * wake.stairs2
                                                    : 0.58 + 0.30 * wake.stairs1);
      } else if (k === "gallery") {
        // the memory wall gets its cinematic moment: wash lifts, room softens
        L.intensity = L.userData.baseIntensity * (1 + 0.4 * wake.focus);
      } else if (k === "fill") {
        L.intensity = L.userData.baseIntensity * (1 - 0.22 * wake.focus);
      } else if ((k === "room" || k === "cake") && L.position.y > 10) {
        // the rooftop room and roof-cake come the last mile of the way on
        const rv = 0.78 + 0.22 * wake.roof;
        if (k === "room") L.intensity = L.userData.baseIntensity * rv;
        else L.userData.ceremonyScale = rv;
      }
    }
    EA.sky.uniforms.uWarm.value = 0.15 + finaleAmt * 0.75;
    EA.water.uniforms.uWarm.value = arrive * 0.4 + finaleAmt * 0.6;
    EA.stars.uniforms.uOpacity.value = 0.55 + finaleAmt * 0.45;

    /* ---- protect the reveal sightline ----
       Anything that drifts into the narrow corridor between the camera
       and the birthday message during the finale gently fades away, so
       the payoff of the whole journey can never be obscured. */
    if (finaleAmt > 0.01) {
      for (let i = 0; i < A.balloons.length; i++) {
        const b = A.balloons[i];
        if (!b.userData.rooftop) continue;
        const inCorridor = Math.abs(b.position.x) < 6.2 && b.position.z > -2.5;
        const target = inCorridor ? 1 - finaleAmt : 1;
        const sc = b.userData._s ?? 1;
        const next = sc + (target - sc) * 0.08;
        b.userData._s = next;
        b.scale.setScalar(Math.max(0.001, next));
        b.visible = next > 0.02;
      }
    } else {
      for (let i = 0; i < A.balloons.length; i++) {
        const b = A.balloons[i];
        if (b.userData.rooftop && b.userData._s !== undefined && b.userData._s < 0.999) {
          b.userData._s = Math.min(1, b.userData._s + 0.05);
          b.scale.setScalar(b.userData._s);
          b.visible = true;
        }
      }
    }

    /* ---- the reveal ---- */
    if (A.reveal) {
      const rA = rig.tAt("roofcake"), rB = rig.tAt("reveal");
      const rv = smoothstep(rA, rB, progress);
      const planes = A.reveal.planes;
      const stepv = (rB - rA) * 0.22;
      for (let i = 0; i < planes.length; i++) {
        const stagger = smoothstep(rA + i * stepv, rB + i * stepv, progress);
        planes[i].material.opacity = stagger;
      }
      A.reveal.light.intensity = rv * 7;
      A.reveal.group.position.y = (DIM.F2 + 0.11) + 2.3 + (1 - rv) * 0.4;
      A.reveal.group.scale.setScalar(0.94 + rv * 0.06);
    }

    cullLights(t);
    renderer.render(scene, camera);
  }

  function resize() {
    camera.aspect = innerWidth / innerHeight;
    camera.updateProjectionMatrix();
    renderer.setSize(innerWidth, innerHeight, false);
    renderer.setPixelRatio(dprNow);
  }

  function dispose() {
    renderer.dispose();
    scene.traverse(o => {
      if (o.geometry) o.geometry.dispose();
      if (o.material) {
        (Array.isArray(o.material) ? o.material : [o.material])
          .forEach(m => { Object.values(m).forEach(v => v && v.isTexture && v.dispose()); m.dispose(); });
      }
    });
  }

  /* ---- pre-warm shaders for the opening state ----
     The canvas doesn't actually render anything until the house section
     scrolls into view (see index.js), which is exactly why the very
     first visible frame used to stutter: dozens of merged materials × a
     handful of lights × water/sky/glow shaders were all compiling their
     GPU programs for the first time in that one frame, synchronously,
     right as the user arrived. Rendering a few throwaway frames now —
     while the canvas is still invisible, during the loading/gate screen
     — forces that same compilation to happen where nobody is looking,
     and finishes the shadow-map bake (see shadowBake) at the same time. */
  try {
    for (let i = 0; i < 6; i++) render();
  } catch (e) { console.warn("[house] warm-up render skipped:", e); }

  return {
    render, resize, dispose, setProgress, setPointer,
    camera, scene, renderer, quality, KEYS: rig.KEYS,
    stats: () => report(renderer, scene),
    ceremonyRange: cerRange,
    tAt: rig.tAt,
    tags: rig.TAG_AT,
    introEnd: rig.tAt("far") || 0.14,
    easterEgg: int.anim.easterEgg || null,
    door: arch.door || null,
    magic,
    __posCurve: rig.posCurve, __tToU: rig.tToU, __keyAt: rig.keyAt,
    mergeStats
  };
}

function smoothstep(a, b, x) {
  const t = Math.max(0, Math.min(1, (x - a) / (b - a)));
  return t * t * (3 - 2 * t);
}
