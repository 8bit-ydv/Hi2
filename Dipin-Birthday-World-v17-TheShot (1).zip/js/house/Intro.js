/* =============================================================
   HOUSE INTRO
   Before the house is revealed the visitor meets the sender:
   three cinematic title cards, then a handwritten note from
   Ekanth, then the camera pulls back and the house appears —
   fully clear of the trees, framed like an establishing shot.

   Pure DOM/GSAP. It sits on top of the canvas and hands over
   cleanly once the note is finished.
   ============================================================= */

export function buildIntro(sec, C) {
  const I = C.house.intro;

  const root = document.createElement("div");
  root.id = "houseIntro";
  root.className = "noSel";

  /* ---- title cards ---- */
  const cardWrap = document.createElement("div");
  cardWrap.className = "hi-cards";
  const cards = I.cards.map((c, i) => {
    const el = document.createElement("div");
    el.className = "hi-card";
    el.innerHTML =
      `<p class="hi-small">${c.small}</p>` +
      `<p class="hi-big">${c.big}</p>` +
      `<span class="hi-rule"></span>`;
    cardWrap.appendChild(el);
    return el;
  });

  /* ---- handwritten note ---- */
  const noteWrap = document.createElement("div");
  noteWrap.className = "hi-note";
  const paper = document.createElement("div");
  paper.className = "hi-paper";
  const lines = I.note.map(txt => {
    const p = document.createElement("p");
    p.className = "hi-line";
    p.textContent = txt;
    paper.appendChild(p);
    return p;
  });
  const sign = document.createElement("p");
  sign.className = "hi-sign";
  sign.textContent = I.noteSign;
  paper.appendChild(sign);
  noteWrap.appendChild(paper);

  root.appendChild(cardWrap);
  root.appendChild(noteWrap);
  sec.querySelector(".pin").appendChild(root);

  return { root, cards, lines, sign, noteWrap, cardWrap };
}

/**
 * Drive the intro from scroll progress (0-1 across the whole house scene).
 * Cards live in the first slice, the note in the second, then it clears.
 */
export function createIntroTimeline(intro, gsap) {
  const { cards, lines, sign, noteWrap, cardWrap, root } = intro;

  // everything starts hidden and is positioned by the timeline
  gsap.set(cards, { opacity: 0, y: 26, filter: "blur(10px)" });
  gsap.set(lines, { opacity: 0, y: 16 });
  gsap.set(sign, { opacity: 0, y: 12 });
  gsap.set(noteWrap, { opacity: 0 });
  gsap.set(cardWrap, { opacity: 1 });

  const tl = gsap.timeline({ paused: true });

  // --- three cards, each fading through ---
  cards.forEach((c, i) => {
    const at = i * 0.9;
    tl.to(c, { opacity: 1, y: 0, filter: "blur(0px)", duration: 0.5, ease: "power2.out" }, at)
      .to(c, { opacity: 0, y: -22, filter: "blur(8px)", duration: 0.42, ease: "power2.in" }, at + 0.56);
  });

  const cardsEnd = cards.length * 0.9;

  // --- the note writes itself in ---
  tl.to(cardWrap, { opacity: 0, duration: 0.2 }, cardsEnd - 0.1)
    .to(noteWrap, { opacity: 1, duration: 0.5, ease: "power2.out" }, cardsEnd);

  lines.forEach((l, i) => {
    tl.to(l, { opacity: 1, y: 0, duration: 0.42, ease: "power2.out" }, cardsEnd + 0.2 + i * 0.42);
  });
  tl.to(sign, { opacity: 1, y: 0, duration: 0.5, ease: "power2.out" },
        cardsEnd + 0.3 + lines.length * 0.42);

  // --- hand over to the house ---
  const noteEnd = cardsEnd + 0.7 + lines.length * 0.42;
  tl.to(noteWrap, { opacity: 0, y: -30, filter: "blur(10px)", duration: 0.7, ease: "power2.in" }, noteEnd)
    .set(root, { pointerEvents: "none" }, noteEnd + 0.7);

  tl.totalDuration(1);   // normalise so we can seek with a 0-1 value
  return tl;
}
