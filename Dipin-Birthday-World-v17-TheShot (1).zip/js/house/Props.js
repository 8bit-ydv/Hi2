/* =============================================================
   PROPS — furniture, cake, gifts, balloons, lights, plants
   Every prop is a small factory returning a Group so the
   interiors can compose them without duplicating geometry code.
   ============================================================= */
import * as THREE from "../../assets/vendor/three.module.min.js";
import { roundedBox, turned, catenary, textTexture, glowSprite } from "./geometry.js";

/* ---------------- shared bits ---------------- */
const GLOW_TEX = {};
function glowTex(color) {
  if (!GLOW_TEX[color]) GLOW_TEX[color] = glowSprite(color);
  return GLOW_TEX[color];
}

/* ---------------- birthday cake ---------------- */
/**
 * A ceremonial cake. Returns rich userData so the scene can run the
 * full sequence: light → wish → blow → cut → slice.
 */
export function makeCake(M, opts = {}) {
  const { scale = 1, tiers = 3, numeral = null, candles = 0 } = opts;
  const g = new THREE.Group();
  const flames = [];
  const halos = [];
  const smokes = [];
  const candleGroups = [];

  // ---- cake stand ----
  const stand = new THREE.Mesh(
    turned([[0, 0], [0.52, 0], [0.5, 0.05], [0.12, 0.1], [0.1, 0.34], [0.34, 0.44],
            [0.62, 0.5], [0.64, 0.56], [0, 0.57]], 26), M.ceramic);
  g.add(stand);

  const tierDefs = [
    { r: 0.62, h: 0.34, y: 0.57 },
    { r: 0.46, h: 0.29, y: 0.91 },
    { r: 0.31, h: 0.25, y: 1.20 }
  ].slice(0, tiers);

  let topY = 0.57;
  tierDefs.forEach((t, i) => {
    const body = new THREE.Mesh(new THREE.CylinderGeometry(t.r, t.r * 1.02, t.h, 34), M.frosting);
    body.position.y = t.y + t.h / 2;
    body.castShadow = true;
    g.add(body);

    const collar = new THREE.Mesh(
      new THREE.TorusGeometry(t.r * 0.99, t.h * 0.13, 8, 34), M.frostingPink);
    collar.rotation.x = Math.PI / 2;
    collar.position.y = t.y + t.h - t.h * 0.16;
    g.add(collar);

    const top = new THREE.Mesh(new THREE.CylinderGeometry(t.r, t.r, 0.02, 34), M.frosting);
    top.position.y = t.y + t.h;
    g.add(top);

    const pearls = 18 + i * 4;
    for (let p = 0; p < pearls; p++) {
      const a = (p / pearls) * Math.PI * 2;
      const pearl = new THREE.Mesh(new THREE.SphereGeometry(t.h * 0.1, 8, 6), M.frostingPink);
      pearl.position.set(Math.cos(a) * t.r, t.y + t.h * 0.09, Math.sin(a) * t.r);
      g.add(pearl);
    }
    topY = t.y + t.h;
  });

  const midTier = tierDefs[Math.max(0, tierDefs.length - 2)];
  const midY = midTier.y + midTier.h;

  /* ---- helper: one candle flame, parented wherever it belongs ---- */
  function addFlame(parent, x, y, z, s = 1) {
    const flame = new THREE.Mesh(new THREE.SphereGeometry(0.03 * s, 12, 12), M.emitFlame);
    flame.scale.set(1, 1.9, 1);
    flame.position.set(x, y, z);
    flame.userData.baseY = y;
    flame.userData.baseScale = s;
    flame.userData.seed = Math.random() * 6.28;
    parent.add(flame);
    flames.push(flame);

    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex("rgb(255,196,120)"), color: 0xffc478,
      transparent: true, opacity: 0.0, depthWrite: false,
      blending: THREE.AdditiveBlending
    }));
    halo.scale.setScalar(0.52 * s);
    halo.position.set(x, y + 0.01, z);
    parent.add(halo);
    halos.push(halo);

    // a wisp of smoke, hidden until the candle is blown out
    const smoke = new THREE.Mesh(
      new THREE.PlaneGeometry(0.08 * s, 0.36 * s),
      new THREE.MeshBasicMaterial({
        color: 0xd8d2ca, transparent: true, opacity: 0,
        depthWrite: false, side: THREE.DoubleSide
      })
    );
    smoke.position.set(x, y + 0.2 * s, z);
    smoke.userData.baseY = y + 0.2 * s;
    smoke.userData.seed = Math.random() * 6.28;
    parent.add(smoke);
    smokes.push(smoke);

    return flame;
  }

  /* ---- a ring of wax candles that can grow out of the frosting ---- */
  if (candles > 0) {
    const topTier = tierDefs[tierDefs.length - 1];
    const three = tierDefs.length > 2;
    // 3-tier: the ring circles the top tier's base (the ceremony look).
    // 2-tier: the ring stands ON the top surface — never inside the tier.
    const ringR = three ? topTier.r + 0.09 : topTier.r * 0.62;
    const ringY = three ? midY : topY;
    for (let i = 0; i < candles; i++) {
      const a = (i / candles) * Math.PI * 2 + 0.25;
      const x = Math.cos(a) * ringR, z = Math.sin(a) * ringR;
      const h = 0.2 + (i % 3) * 0.02;
      const c = new THREE.Group();
      c.position.set(x, ringY, z);
      const stick = new THREE.Mesh(
        new THREE.CylinderGeometry(0.016, 0.017, h, 8),
        i % 2 ? M.frosting : M.frostingPink);
      stick.position.y = h / 2;
      c.add(stick);
      // candy stripe
      const stripe = new THREE.Mesh(
        new THREE.CylinderGeometry(0.0172, 0.0172, h * 0.16, 8),
        i % 2 ? M.frostingPink : M.frosting);
      stripe.position.y = h * 0.55;
      c.add(stripe);
      const wick = new THREE.Mesh(new THREE.CylinderGeometry(0.004, 0.004, 0.03, 4), M.backing);
      wick.position.y = h + 0.014;
      c.add(wick);
      addFlame(c, 0, h + 0.065, 0, 1);
      c.userData.height = h;
      c.scale.y = 0.001;
      g.add(c);
      candleGroups.push(c);
    }
  }

  /* ---- the big number candle ("20") on the top tier ---- */
  let numeralGroup = null;
  if (numeral) {
    numeralGroup = new THREE.Group();
    numeralGroup.position.y = topY;
    const digits = String(numeral).split("");
    const dw = 0.2, gap = 0.04;
    const totalW = digits.length * dw + (digits.length - 1) * gap;
    digits.forEach((d, i) => {
      const x = -totalW / 2 + dw / 2 + i * (dw + gap);
      const tex = textTexture(d, {
        w: 256, h: 384,
        font: "700 300px 'Cormorant Garamond', Georgia, serif",
        letter: 0, color: "#fff4e0", glow: "#ffb066", glowBlur: 18
      });
      // a slim extruded slab carries the digit on both faces
      const slab = new THREE.Mesh(roundedBox(dw, dw * 1.5, 0.04, 0.012, 1), M.frostingPink);
      slab.position.set(x, dw * 0.75 + 0.02, 0);
      slab.castShadow = true;
      numeralGroup.add(slab);
      [1, -1].forEach(side => {
        const face = new THREE.Mesh(
          new THREE.PlaneGeometry(dw * 0.92, dw * 1.42),
          new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, toneMapped: false })
        );
        face.position.set(x, dw * 0.75 + 0.02, side * 0.021);
        face.rotation.y = side > 0 ? 0 : Math.PI;
        face.renderOrder = 2;
        numeralGroup.add(face);
      });
      // wick + flame on top of each digit
      const wick = new THREE.Mesh(new THREE.CylinderGeometry(0.005, 0.005, 0.03, 4), M.backing);
      wick.position.set(x, dw * 1.5 + 0.04, 0);
      numeralGroup.add(wick);
      addFlame(numeralGroup, x, dw * 1.5 + 0.095, 0, 1.35);
    });
    numeralGroup.scale.setScalar(0.001);
    g.add(numeralGroup);
  }

  /* ---- the cutting knife (hidden until the cut beat) ----
     A real chef's knife profile: a wide blade that tapers to a point,
     a steel bolster and a dark riveted handle — blade up, ready. */
  const knife = new THREE.Group();
  // the blade: a long tapering slab, tip at y=0 pointing DOWN — it
  // plunges tip-first, the way the ceremony animates it
  const bladeShape = new THREE.Shape();
  bladeShape.moveTo(0, 0);
  bladeShape.lineTo(0.024, -0.1);
  bladeShape.lineTo(0.031, -0.58);
  bladeShape.lineTo(0.022, -0.68);
  bladeShape.lineTo(-0.022, -0.68);
  bladeShape.lineTo(-0.031, -0.58);
  bladeShape.lineTo(-0.024, -0.1);
  bladeShape.lineTo(0, 0);
  const bladeGeo = new THREE.ExtrudeGeometry(bladeShape,
    { depth: 0.007, bevelEnabled: true, bevelThickness: 0.0025, bevelSize: 0.004, bevelSegments: 1 });
  bladeGeo.translate(0, 0, -0.0035);     // centre the thickness on z
  const bladeMatl = new THREE.MeshStandardMaterial({ color: 0xe2e7ed, roughness: 0.13, metalness: 0.95 });
  const blade = new THREE.Mesh(bladeGeo, bladeMatl);
  blade.castShadow = true;
  // bolster + handle above, so the hand reads instantly
  const bolster = new THREE.Mesh(roundedBox(0.05, 0.05, 0.03, 0.008, 1), M.brass);
  bolster.position.y = 0.025;
  const handle = new THREE.Mesh(
    turned([[0, 0], [0.024, 0], [0.031, 0.05], [0.029, 0.2], [0.021, 0.25], [0.027, 0.275], [0, 0.285]], 12),
    M.woodDark);
  handle.position.y = 0.05;
  const rivet = new THREE.Mesh(new THREE.CylinderGeometry(0.006, 0.006, 0.04, 8), M.brass);
  rivet.rotation.x = Math.PI / 2;
  rivet.position.set(0, 0.16, 0);
  knife.add(blade, bolster, handle, rivet);
  knife.position.set(0.52, topY + 0.8, 0.34);
  knife.rotation.z = 0.42;
  knife.visible = false;
  g.add(knife);

  /* ---- the slice that lifts out after the cut ---- */
  const sliceGroup = new THREE.Group();
  const bt = tierDefs[0];
  const sliceAngle = Math.PI / 7;
  const sliceShape = new THREE.Shape();
  sliceShape.moveTo(0, 0);
  sliceShape.absarc(0, 0, bt.r, -sliceAngle / 2, sliceAngle / 2, false);
  sliceShape.lineTo(0, 0);
  const sliceGeo = new THREE.ExtrudeGeometry(sliceShape, { depth: bt.h, bevelEnabled: false });
  sliceGeo.rotateX(-Math.PI / 2);
  const slice = new THREE.Mesh(sliceGeo, M.frosting);
  slice.position.y = bt.y;
  const sliceInner = new THREE.Mesh(sliceGeo.clone(), M.sponge);
  sliceInner.scale.set(0.97, 0.86, 0.97);
  sliceInner.position.y = bt.y + 0.01;
  sliceGroup.add(slice, sliceInner);
  // the wedge opens toward the ceremony camera (cake at 0.4,-1.4 world,
  // camera arriving from +x/+z) so the cut is visible from outside
  sliceGroup.rotation.y = 0.32;
  // 7% slimmer than the gap: while the slice sits inside the cake the two
  // solids must never touch — coincident faces were the flicker
  sliceGroup.scale.set(0.93, 1, 0.93);
  sliceGroup.visible = false;
  g.add(sliceGroup);

  // the wedge-shaped gap left in the cake once the slice is removed
  const gapGeo = new THREE.ExtrudeGeometry(sliceShape, { depth: bt.h, bevelEnabled: false });
  gapGeo.rotateX(-Math.PI / 2);
  const gap = new THREE.Mesh(gapGeo, M.sponge);
  // arc a hair PROUD of the tier's curve, top a few mm above its frosting:
  // the removed wedge reads instantly and never shares a plane with the tier
  gap.position.y = bt.y - 0.006;
  gap.scale.set(1.012, 1.03, 1.012);
  gap.rotation.y = 0.32;
  gap.visible = false;
  g.add(gap);

  // a small plate for the slice to land on
  const plate = new THREE.Mesh(
    turned([[0, 0], [0.19, 0], [0.2, 0.012], [0.18, 0.03], [0.05, 0.02], [0, 0.02]], 20),
    M.ceramic);
  plate.position.set(0.42, 0.02, 1.26);   // along the wedge yaw (0.32 rad)
  plate.visible = false;
  g.add(plate);

  g.scale.setScalar(scale);
  g.userData = {
    flames, halos, smokes, knife, slice: sliceGroup, gap, plate,
    candleGroups, numeral: numeralGroup,
    topY: topY * scale, baseTier: bt
  };
  return g;
}

/* ---------------- gifts ---------------- */
export function makeGift(M, size = 0.5, colorIndex = 0) {
  const g = new THREE.Group();
  const mat = M.gifts[colorIndex % M.gifts.length];
  const box = new THREE.Mesh(roundedBox(size, size * 0.86, size, size * 0.06, 2), mat);
  box.position.y = size * 0.43;
  box.castShadow = true;
  g.add(box);
  // ribbon cross
  const rw = size * 0.13;
  [[0, 0], [Math.PI / 2, 1]].forEach(([ry]) => {
    const r = new THREE.Mesh(roundedBox(rw, size * 0.88, size * 1.02, rw * 0.3, 1), M.ribbon);
    r.position.y = size * 0.43;
    r.rotation.y = ry;
    g.add(r);
  });
  // bow: two loops + knot
  const loopGeo = new THREE.TorusGeometry(size * 0.16, size * 0.045, 8, 18, Math.PI * 1.5);
  [-1, 1].forEach(s => {
    const l = new THREE.Mesh(loopGeo, M.ribbon);
    l.position.set(s * size * 0.14, size * 0.92, 0);
    l.rotation.set(Math.PI / 2, 0, s * 0.6);
    g.add(l);
  });
  const knot = new THREE.Mesh(new THREE.SphereGeometry(size * 0.07, 10, 8), M.ribbon);
  knot.position.y = size * 0.9;
  g.add(knot);
  return g;
}

export function makeGiftPile(M, count = 5, spread = 1.4, seedBase = 0) {
  const g = new THREE.Group();
  for (let i = 0; i < count; i++) {
    const s = 0.34 + ((i * 37 + seedBase) % 10) / 10 * 0.34;
    const gift = makeGift(M, s, i + seedBase);
    const a = (i / count) * Math.PI * 2 + seedBase;
    gift.position.set(Math.cos(a) * spread * (0.4 + (i % 3) * 0.22), 0,
                      Math.sin(a) * spread * (0.4 + (i % 2) * 0.3));
    gift.rotation.y = a * 1.7;
    g.add(gift);
  }
  // one stacked pair for verticality
  const base = makeGift(M, 0.6, seedBase + 2);
  base.position.set(spread * 0.55, 0, -spread * 0.3);
  const top = makeGift(M, 0.36, seedBase + 4);
  top.position.set(spread * 0.55, 0.53, -spread * 0.3);
  top.rotation.y = 0.7;
  g.add(base, top);
  return g;
}

/* ---------------- balloons ---------------- */
export function makeBalloon(M, r = 0.34, colorIndex = 0, stringLen = 1.4) {
  const g = new THREE.Group();
  const mat = M.balloons[colorIndex % M.balloons.length];
  // teardrop: sphere squashed then tapered with a small cone neck
  // perf: 22x18 segments (792 tri) per balloon was overkill for a small
  // matte teardrop seen from a few metres away, and balloons appear in
  // clusters of 5-7 all over the house — 14x10 (280 tri, a ~2.8x cut per
  // balloon) reads identically round at this scale/material.
  const body = new THREE.Mesh(new THREE.SphereGeometry(r, 14, 10), mat);
  body.scale.set(1, 1.18, 1);
  body.castShadow = true;
  g.add(body);
  const neck = new THREE.Mesh(new THREE.ConeGeometry(r * 0.16, r * 0.3, 10), mat);
  neck.position.y = -r * 1.18;
  neck.rotation.x = Math.PI;
  g.add(neck);
  // curling string
  const pts = [];
  for (let i = 0; i <= 16; i++) {
    const t = i / 16;
    pts.push(new THREE.Vector3(
      Math.sin(t * 7) * 0.05 * t,
      -r * 1.3 - t * stringLen,
      Math.cos(t * 5) * 0.05 * t
    ));
  }
  const str = new THREE.Line(
    new THREE.BufferGeometry().setFromPoints(pts),
    new THREE.LineBasicMaterial({ color: 0xd8c6ad, transparent: true, opacity: 0.55 })
  );
  g.add(str);
  g.userData.seed = Math.random() * 6.28;
  return g;
}

export function makeBalloonCluster(M, count = 7, radius = 0.6, seed = 0) {
  const g = new THREE.Group();
  for (let i = 0; i < count; i++) {
    const a = (i / count) * Math.PI * 2 + seed;
    const b = makeBalloon(M, 0.26 + (i % 3) * 0.06, i + seed, 1.0 + (i % 4) * 0.35);
    b.position.set(Math.cos(a) * radius, Math.sin(i * 2.1) * radius * 0.55, Math.sin(a) * radius);
    g.add(b);
  }
  return g;
}

/* ---------------- string lights ---------------- */
export function makeStringLights(M, from, to, sag, bulbCount = 10, colors) {
  const g = new THREE.Group();
  const { geometry, curve } = catenary(from, to, sag, 26, 0.012);
  const wire = new THREE.Mesh(geometry, M.iron);
  g.add(wire);
  const bulbs = [];
  const cols = colors || [0xffd89b, 0xe4869a, 0x9fb8ff, 0xfff0d8];
  for (let i = 1; i < bulbCount; i++) {
    const p = curve.getPoint(i / bulbCount);
    const col = cols[i % cols.length];
    const bulb = new THREE.Mesh(
      new THREE.SphereGeometry(0.055, 10, 8),
      new THREE.MeshBasicMaterial({ color: col })
    );
    bulb.position.copy(p).y -= 0.075;
    g.add(bulb);
    const halo = new THREE.Sprite(new THREE.SpriteMaterial({
      map: glowTex("rgb(255,220,170)"), color: col, transparent: true,
      opacity: 0.42, depthWrite: false, blending: THREE.AdditiveBlending
    }));
    halo.scale.setScalar(0.4);
    halo.position.copy(bulb.position);
    g.add(halo);
    bulbs.push({ bulb, halo, seed: Math.random() * 6.28 });
  }
  g.userData.bulbs = bulbs;
  return g;
}

/* ---------------- banner ---------------- */
export function makeBanner(M, text, width = 6, from, to, sag = 0.7) {
  const g = new THREE.Group();
  const { curve } = catenary(from, to, sag, 20, 0.01);
  const wire = new THREE.Mesh(catenary(from, to, sag, 20, 0.008).geometry, M.iron);
  g.add(wire);
  const chars = text.split("");
  const flags = [];
  chars.forEach((ch, i) => {
    if (ch === " ") return;
    const t = (i + 0.5) / chars.length;
    const p = curve.getPoint(t);
    const tex = textTexture(ch, {
      w: 128, h: 160, font: "600 108px 'Cormorant Garamond', Georgia, serif",
      letter: 0, color: "#fff3de", glow: "#ffb066", glowBlur: 12
    });
    const flag = new THREE.Group();
    const cloth = new THREE.Mesh(
      new THREE.PlaneGeometry(0.42, 0.52),
      new THREE.MeshStandardMaterial({
        color: [0xb3546e, 0x4a6ba8, 0xd39a52, 0x6a4a86][i % 4],
        roughness: 0.94, side: THREE.DoubleSide
      })
    );
    const letter = new THREE.Mesh(
      new THREE.PlaneGeometry(0.36, 0.44),
      new THREE.MeshBasicMaterial({ map: tex, transparent: true, depthWrite: false, side: THREE.DoubleSide })
    );
    letter.position.z = 0.008;
    letter.renderOrder = 1;
    flag.add(cloth, letter);
    flag.position.copy(p).y -= 0.3;
    flag.userData.seed = i * 0.4;
    g.add(flag);
    flags.push(flag);
  });
  g.userData.flags = flags;
  return g;
}

/* ---------------- furniture ---------------- */
export function makeTable(M, w = 2.2, d = 1.1, h = 0.78, round = false) {
  const g = new THREE.Group();
  const top = round
    ? new THREE.Mesh(new THREE.CylinderGeometry(w / 2, w / 2, 0.09, 32), M.woodWarm)
    : new THREE.Mesh(roundedBox(w, 0.09, d, 0.02, 1), M.woodWarm);
  top.position.y = h;
  top.castShadow = true; top.receiveShadow = true;
  g.add(top);
  // apron
  if (!round) {
    const apron = new THREE.Mesh(roundedBox(w - 0.16, 0.1, d - 0.16, 0.02, 1), M.woodDark);
    apron.position.y = h - 0.09;
    g.add(apron);
  }
  const legProfile = [[0, 0], [0.07, 0], [0.055, 0.08], [0.04, h * 0.45],
                      [0.055, h * 0.72], [0.045, h - 0.06], [0.06, h], [0, h]];
  if (round) {
    const ped = new THREE.Mesh(
      turned([[0, 0], [0.34, 0], [0.3, 0.06], [0.1, 0.2], [0.08, h - 0.1], [0.22, h], [0, h]], 20),
      M.woodDark);
    g.add(ped);
  } else {
    [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
      const leg = new THREE.Mesh(turned(legProfile, 10), M.woodDark);
      leg.position.set(sx * (w / 2 - 0.16), 0, sz * (d / 2 - 0.16));
      leg.castShadow = true;
      g.add(leg);
    });
  }
  g.userData.top = h;
  return g;
}

export function makeSofa(M, w = 2.6) {
  const g = new THREE.Group();
  const seatH = 0.42, d = 1.0;
  const base = new THREE.Mesh(roundedBox(w, seatH, d, 0.08, 2), M.fabricRose);
  base.position.y = seatH / 2 + 0.1;
  base.castShadow = true;
  g.add(base);
  const back = new THREE.Mesh(roundedBox(w, 0.66, 0.24, 0.09, 2), M.fabricRose);
  back.position.set(0, seatH + 0.42, -d / 2 + 0.12);
  g.add(back);
  [-1, 1].forEach(s => {
    const arm = new THREE.Mesh(roundedBox(0.24, 0.5, d, 0.1, 2), M.fabricRose);
    arm.position.set(s * (w / 2 - 0.12), seatH + 0.06, 0);
    g.add(arm);
  });
  // cushions
  for (let i = 0; i < 3; i++) {
    const c = new THREE.Mesh(roundedBox(w / 3.4, 0.14, d * 0.78, 0.06, 2), M.fabricCream);
    c.position.set(-w / 3.2 + i * (w / 3.2), seatH + 0.18, 0.04);
    c.rotation.z = (i - 1) * 0.03;
    g.add(c);
  }
  // throw pillows
  [-1, 1].forEach((s, i) => {
    const p = new THREE.Mesh(roundedBox(0.42, 0.42, 0.14, 0.08, 2),
      i ? M.fabricCream : M.rug);
    p.position.set(s * (w / 2 - 0.46), seatH + 0.44, -0.2);
    p.rotation.set(0.2, s * 0.3, s * 0.25);
    g.add(p);
  });
  // feet
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
    const f = new THREE.Mesh(new THREE.CylinderGeometry(0.05, 0.04, 0.12, 8), M.woodDark);
    f.position.set(sx * (w / 2 - 0.2), 0.06, sz * (d / 2 - 0.16));
    g.add(f);
  });
  return g;
}

export function makeLamp(M, h = 1.5) {
  const g = new THREE.Group();
  const stem = new THREE.Mesh(
    turned([[0, 0], [0.16, 0], [0.14, 0.04], [0.05, 0.1], [0.035, h * 0.7],
            [0.05, h * 0.82], [0.03, h * 0.9], [0, h * 0.9]], 14), M.brassDark);
  g.add(stem);
  const shade = new THREE.Mesh(
    new THREE.CylinderGeometry(0.2, 0.3, 0.34, 22, 1, true),
    new THREE.MeshStandardMaterial({
      color: 0xf7e0bc, roughness: 0.95, side: THREE.DoubleSide,
      emissive: 0xffb877, emissiveIntensity: 0.5
    }));
  shade.position.y = h * 0.9 + 0.13;
  g.add(shade);
  const bulbGlow = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex("rgb(255,200,140)"), color: 0xffc98a,
    transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending
  }));
  bulbGlow.scale.setScalar(1.1);
  bulbGlow.position.y = h * 0.9 + 0.1;
  g.add(bulbGlow);
  g.userData.lightY = h * 0.9 + 0.1;
  return g;
}

export function makePendantLight(M, dropFrom, drop = 1.0, r = 0.26) {
  const g = new THREE.Group();
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, drop, 6), M.iron);
  cord.position.y = -drop / 2;
  g.add(cord);
  const shade = new THREE.Mesh(
    new THREE.SphereGeometry(r, 20, 14, 0, Math.PI * 2, 0, Math.PI * 0.58),
    new THREE.MeshStandardMaterial({
      color: 0xe8d3b4, roughness: 0.6, metalness: 0.25, side: THREE.DoubleSide
    }));
  shade.position.y = -drop;
  g.add(shade);
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(r * 0.34, 12, 10), M.emitWarm);
  bulb.position.y = -drop - r * 0.28;
  g.add(bulb);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex("rgb(255,205,145)"), color: 0xffcd91,
    transparent: true, opacity: 0.45, depthWrite: false, blending: THREE.AdditiveBlending
  }));
  halo.scale.setScalar(1.2);
  halo.position.y = -drop - r * 0.28;
  g.add(halo);
  g.position.copy(dropFrom);
  g.userData.bulbY = -drop - r * 0.28;
  return g;
}

export function makePlant(M, h = 1.0) {
  const g = new THREE.Group();
  const pot = new THREE.Mesh(
    turned([[0, 0], [0.2, 0], [0.22, 0.06], [0.24, 0.3], [0.26, 0.34], [0.23, 0.36], [0, 0.36]], 18),
    M.terracotta);
  pot.castShadow = true;
  g.add(pot);
  const soil = new THREE.Mesh(new THREE.CylinderGeometry(0.21, 0.21, 0.03, 16), M.backing);
  soil.position.y = 0.35;
  g.add(soil);
  // fronds
  const n = 9;
  for (let i = 0; i < n; i++) {
    const a = (i / n) * Math.PI * 2;
    const lean = 0.3 + (i % 3) * 0.18;
    const len = h * (0.6 + (i % 4) * 0.13);
    const shape = new THREE.Shape();
    shape.moveTo(0, 0);
    shape.quadraticCurveTo(0.09, len * 0.5, 0, len);
    shape.quadraticCurveTo(-0.09, len * 0.5, 0, 0);
    const leaf = new THREE.Mesh(new THREE.ShapeGeometry(shape, 8), M.leaf);
    leaf.position.set(Math.cos(a) * 0.06, 0.36, Math.sin(a) * 0.06);
    leaf.rotation.set(-lean, a, 0);
    g.add(leaf);
  }
  return g;
}

export function makeRug(M, w = 3.2, d = 2.2) {
  const g = new THREE.Group();
  const base = new THREE.Mesh(roundedBox(w, 0.03, d, 0.1, 1), M.rug);
  base.receiveShadow = true;
  g.add(base);
  const inner = new THREE.Mesh(roundedBox(w - 0.34, 0.032, d - 0.34, 0.08, 1), M.fabricCream);
  inner.position.y = 0.004;
  inner.receiveShadow = true;
  g.add(inner);
  const inner2 = new THREE.Mesh(roundedBox(w - 0.7, 0.034, d - 0.7, 0.06, 1), M.rug);
  inner2.position.y = 0.008;
  g.add(inner2);
  return g;
}

export function makeShelf(M, w = 1.8) {
  const g = new THREE.Group();
  const board = new THREE.Mesh(roundedBox(w, 0.07, 0.3, 0.02, 1), M.woodWarm);
  board.castShadow = true; board.receiveShadow = true;
  g.add(board);
  [-1, 1].forEach(s => {
    const br = new THREE.Mesh(roundedBox(0.06, 0.22, 0.24, 0.02, 1), M.brassDark);
    br.position.set(s * (w / 2 - 0.16), -0.14, -0.02);
    g.add(br);
  });
  return g;
}

export function makeCandleStick(M, h = 0.42) {
  const g = new THREE.Group();
  const base = new THREE.Mesh(
    turned([[0, 0], [0.09, 0], [0.08, 0.02], [0.025, 0.06], [0.022, h * 0.8],
            [0.05, h * 0.86], [0.045, h * 0.9], [0, h * 0.9]], 14), M.brass);
  g.add(base);
  const wax = new THREE.Mesh(new THREE.CylinderGeometry(0.026, 0.028, 0.24, 12), M.frosting);
  wax.position.y = h * 0.9 + 0.12;
  g.add(wax);
  const flame = new THREE.Mesh(new THREE.SphereGeometry(0.024, 8, 8), M.emitFlame);
  flame.scale.set(1, 1.9, 1);
  flame.position.y = h * 0.9 + 0.27;
  flame.userData.baseY = flame.position.y;
  flame.userData.seed = Math.random() * 6.28;
  g.add(flame);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex("rgb(255,190,110)"), color: 0xffbe72,
    transparent: true, opacity: 0.42, depthWrite: false, blending: THREE.AdditiveBlending
  }));
  halo.scale.setScalar(0.3);
  halo.position.copy(flame.position);
  g.add(halo);
  g.userData = { flame, halo };
  return g;
}

/* =============================================================
   UPPER FLOOR — a room to actually sit in
   ============================================================= */

/** A tall bookcase, packed with books of different heights. */
export function makeBookshelf(M, w = 2.4, h = 2.2, d = 0.42) {
  const g = new THREE.Group();
  const t = 0.07;
  // carcass
  const side = (x) => {
    const m = new THREE.Mesh(roundedBox(t, h, d, 0.02, 1), M.woodDark);
    m.position.set(x, h / 2, 0);
    m.castShadow = true;
    g.add(m);
  };
  side(-w / 2 + t / 2); side(w / 2 - t / 2);
  const back = new THREE.Mesh(roundedBox(w, h, 0.04, 0.02, 1), M.woodWarm);
  back.position.set(0, h / 2, -d / 2 + 0.02);
  g.add(back);

  const shelves = 4;
  const bookMats = M.gifts;
  for (let i = 0; i <= shelves; i++) {
    const y = 0.06 + (h - 0.14) * (i / shelves);
    const board = new THREE.Mesh(roundedBox(w - t * 2, 0.06, d - 0.04, 0.015, 1), M.woodDark);
    board.position.set(0, y, 0);
    board.receiveShadow = true;
    g.add(board);
    if (i === shelves) break;
    // books
    let x = -w / 2 + t + 0.09;
    let k = 0;
    while (x < w / 2 - t - 0.12) {
      const bw = 0.05 + ((i * 7 + k * 13) % 5) * 0.018;
      const bh = 0.26 + ((i * 5 + k * 11) % 6) * 0.035;
      const lean = (i + k) % 9 === 0 ? 0.22 : 0;
      const b = new THREE.Mesh(roundedBox(bw, bh, d * 0.7, 0.008, 1), bookMats[(i + k) % bookMats.length]);
      b.position.set(x + bw / 2, y + 0.03 + bh / 2, 0.02);
      b.rotation.z = lean;
      g.add(b);
      x += bw + 0.012;
      k++;
    }
  }
  // cornice
  const top = new THREE.Mesh(roundedBox(w + 0.1, 0.09, d + 0.08, 0.02, 1), M.woodDark);
  top.position.set(0, h + 0.03, 0);
  g.add(top);
  return g;
}

/** A simple wooden chair. */
export function makeChair(M, s = 1) {
  const g = new THREE.Group();
  const seatH = 0.46 * s, w = 0.46 * s, d = 0.44 * s;
  const seat = new THREE.Mesh(roundedBox(w, 0.07 * s, d, 0.02, 1), M.woodWarm);
  seat.position.y = seatH;
  seat.castShadow = true;
  g.add(seat);
  const back = new THREE.Mesh(roundedBox(w, 0.5 * s, 0.06 * s, 0.02, 1), M.woodWarm);
  back.position.set(0, seatH + 0.3 * s, -d / 2 + 0.04 * s);
  g.add(back);
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
    const leg = new THREE.Mesh(new THREE.CylinderGeometry(0.024 * s, 0.028 * s, seatH, 8), M.woodDark);
    leg.position.set(sx * (w / 2 - 0.05 * s), seatH / 2, sz * (d / 2 - 0.05 * s));
    g.add(leg);
  });
  const cushion = new THREE.Mesh(roundedBox(w - 0.06 * s, 0.06 * s, d - 0.06 * s, 0.03, 2), M.fabricRose);
  cushion.position.y = seatH + 0.06 * s;
  g.add(cushion);
  return g;
}

/** An armchair for the reading corner. */
export function makeArmchair(M, s = 1) {
  const g = new THREE.Group();
  const w = 0.95 * s, d = 0.9 * s, seatH = 0.4 * s;
  const base = new THREE.Mesh(roundedBox(w, seatH, d, 0.1, 2), M.fabricRose);
  base.position.y = seatH / 2 + 0.08 * s;
  base.castShadow = true;
  g.add(base);
  const back = new THREE.Mesh(roundedBox(w, 0.72 * s, 0.22 * s, 0.1, 2), M.fabricRose);
  back.position.set(0, seatH + 0.42 * s, -d / 2 + 0.1 * s);
  back.rotation.x = -0.12;
  g.add(back);
  [-1, 1].forEach(sx => {
    const arm = new THREE.Mesh(roundedBox(0.2 * s, 0.42 * s, d * 0.86, 0.09, 2), M.fabricRose);
    arm.position.set(sx * (w / 2 - 0.08 * s), seatH + 0.12 * s, 0.02 * s);
    g.add(arm);
  });
  const cush = new THREE.Mesh(roundedBox(w - 0.24 * s, 0.14 * s, d - 0.22 * s, 0.06, 2), M.fabricCream);
  cush.position.y = seatH + 0.14 * s;
  g.add(cush);
  [[-1, -1], [1, -1], [-1, 1], [1, 1]].forEach(([sx, sz]) => {
    const f = new THREE.Mesh(new THREE.CylinderGeometry(0.045 * s, 0.035 * s, 0.11 * s, 8), M.woodDark);
    f.position.set(sx * (w / 2 - 0.16 * s), 0.055 * s, sz * (d / 2 - 0.16 * s));
    g.add(f);
  });
  return g;
}

/** A few books stacked flat, for a table top. */
export function makeBookStack(M, n = 3, s = 1) {
  const g = new THREE.Group();
  let y = 0;
  for (let i = 0; i < n; i++) {
    const w = (0.26 - i * 0.014) * s, d = (0.19 - i * 0.01) * s, h = 0.035 * s;
    const b = new THREE.Mesh(roundedBox(w, h, d, 0.006, 1), M.gifts[(i * 3) % M.gifts.length]);
    b.position.set((i % 2 ? 0.012 : -0.01) * s, y + h / 2, (i % 3 ? -0.008 : 0.01) * s);
    b.rotation.y = (i % 2 ? 1 : -1) * 0.08;
    g.add(b);
    y += h;
  }
  return g;
}

/* =============================================================
   ROOFTOP PARTY
   ============================================================= */

/** A glowing dance floor: a grid of tiles that pulse through colours.
    GPU animation: every tile used to be its own Mesh + own
    MeshStandardMaterial, recoloured with Color.setHSL() in a JS loop
    every frame (20 draw calls + 20 colour conversions/frame). It's now
    one InstancedMesh with a per-instance phase attribute; the whole
    pulse/hue-cycle runs in the fragment shader from a single uTime +
    uAmt uniform, so the CPU does nothing per frame at all. */
export function makeDanceFloor(M, cols = 5, rows = 4, tile = 0.82) {
  const g = new THREE.Group();
  const w = cols * tile, d = rows * tile;
  // dark base so the tiles read as inset panels
  const base = new THREE.Mesh(roundedBox(w + 0.22, 0.06, d + 0.22, 0.03, 1),
    new THREE.MeshStandardMaterial({ color: 0x1a1526, roughness: 0.5, metalness: 0.3 }));
  base.position.y = 0.03;
  base.receiveShadow = true;
  g.add(base);

  const n = cols * rows;
  const geo = roundedBox(tile * 0.92, 0.05, tile * 0.92, 0.02, 1);
  const mat = new THREE.ShaderMaterial({
    uniforms: { uTime: { value: 0 }, uAmt: { value: 0 } },
    vertexShader: `
      attribute float aPhase;
      varying float vPhase;
      void main(){
        vPhase = aPhase;
        gl_Position = projectionMatrix * modelViewMatrix * instanceMatrix * vec4(position, 1.0);
      }`,
    fragmentShader: `
      uniform float uTime; uniform float uAmt;
      varying float vPhase;
      vec3 hsl2rgb(vec3 c){
        vec3 rgb = clamp(abs(mod(c.x * 6.0 + vec3(0.0, 4.0, 2.0), 6.0) - 3.0) - 1.0, 0.0, 1.0);
        return c.z + c.y * (rgb - 0.5) * (1.0 - abs(2.0 * c.z - 1.0));
      }
      void main(){
        float beat = 0.5 + 0.5 * sin(uTime * 3.1 + vPhase * 1.6);
        float hue = fract(uTime * 0.06 + vPhase * 0.06);
        vec3 glow = hsl2rgb(vec3(hue, 0.72, 0.42 + beat * 0.16));
        float emissiveIntensity = (0.25 + beat * 1.5) * uAmt;
        vec3 base = vec3(0.141, 0.109, 0.2);   // 0x241c33
        gl_FragColor = vec4(base + glow * emissiveIntensity, 1.0);
      }`
  });
  const mesh = new THREE.InstancedMesh(geo, mat, n);
  const phase = new Float32Array(n);
  const m4 = new THREE.Matrix4();
  let k = 0;
  for (let i = 0; i < cols; i++) {
    for (let j = 0; j < rows; j++) {
      m4.setPosition(-w / 2 + tile / 2 + i * tile, 0.075, -d / 2 + tile / 2 + j * tile);
      mesh.setMatrixAt(k, m4);
      phase[k] = i * 0.7 + j * 1.1;
      k++;
    }
  }
  mesh.instanceMatrix.needsUpdate = true;
  mesh.geometry.setAttribute("aPhase", new THREE.InstancedBufferAttribute(phase, 1));
  mesh.frustumCulled = false;
  g.add(mesh);
  g.userData.mesh = mesh;
  g.userData.mat = mat;
  return g;
}

/** Mirror ball, complete with a rig and a scatter of light dots. */
export function makeDiscoBall(M, r = 0.34, drop = 1.4) {
  const g = new THREE.Group();
  const cord = new THREE.Mesh(new THREE.CylinderGeometry(0.012, 0.012, drop, 6), M.iron);
  cord.position.y = -drop / 2;
  g.add(cord);
  const ball = new THREE.Mesh(
    new THREE.IcosahedronGeometry(r, 2),
    new THREE.MeshStandardMaterial({
      color: 0xe8eefb, roughness: 0.1, metalness: 1, flatShading: true,
      emissive: 0x9fb6e8, emissiveIntensity: 0.85
    }));
  ball.position.y = -drop - r;
  ball.castShadow = false;
  g.add(ball);
  const halo = new THREE.Sprite(new THREE.SpriteMaterial({
    map: glowTex("rgb(200,215,255)"), color: 0xc8d7ff,
    transparent: true, opacity: 0.5, depthWrite: false, blending: THREE.AdditiveBlending
  }));
  halo.scale.setScalar(2.6);
  halo.position.copy(ball.position);
  g.add(halo);
  g.userData = { ball, halo, drop, r };
  return g;
}

/** DJ console: a table, a deck, and two glowing speakers. */
export function makeDJBooth(M, w = 2.2) {
  const g = new THREE.Group();
  const h = 0.95;
  const body = new THREE.Mesh(roundedBox(w, h, 0.72, 0.05, 1),
    new THREE.MeshStandardMaterial({ color: 0x241b30, roughness: 0.6, metalness: 0.25 }));
  body.position.y = h / 2;
  body.castShadow = true;
  g.add(body);
  const top = new THREE.Mesh(roundedBox(w + 0.16, 0.08, 0.86, 0.02, 1), M.woodDark);
  top.position.y = h + 0.04;
  g.add(top);
  // face lights
  const strip = new THREE.Mesh(roundedBox(w - 0.2, 0.07, 0.03, 0.02, 1),
    new THREE.MeshBasicMaterial({ color: 0xff7bc0, toneMapped: false }));
  strip.position.set(0, h * 0.62, 0.37);
  g.add(strip);
  const strip2 = new THREE.Mesh(roundedBox(w - 0.5, 0.05, 0.03, 0.02, 1),
    new THREE.MeshBasicMaterial({ color: 0x7bd7ff, toneMapped: false }));
  strip2.position.set(0, h * 0.4, 0.37);
  g.add(strip2);
  // two decks + a mixer
  [-0.62, 0.62].forEach(x => {
    const deck = new THREE.Mesh(new THREE.CylinderGeometry(0.22, 0.22, 0.05, 20), M.brassDark);
    deck.position.set(x, h + 0.11, 0);
    g.add(deck);
    const disc = new THREE.Mesh(new THREE.CylinderGeometry(0.17, 0.17, 0.02, 20),
      new THREE.MeshStandardMaterial({ color: 0x14121c, roughness: 0.4, metalness: 0.5 }));
    disc.position.set(x, h + 0.145, 0);
    g.add(disc);
  });
  const mixer = new THREE.Mesh(roundedBox(0.6, 0.06, 0.4, 0.02, 1), M.iron);
  mixer.position.set(0, h + 0.11, 0);
  g.add(mixer);
  for (let i = 0; i < 6; i++) {
    const k = new THREE.Mesh(new THREE.CylinderGeometry(0.018, 0.018, 0.03, 8),
      new THREE.MeshBasicMaterial({ color: i % 2 ? 0xffc06a : 0x9fe8ff, toneMapped: false }));
    k.position.set(-0.22 + i * 0.09, h + 0.16, -0.1);
    g.add(k);
  }
  return g;
}

/** A stack speaker with a warm cone glow. */
export function makeSpeaker(M, h = 1.5) {
  const g = new THREE.Group();
  const w = 0.62, d = 0.5;
  const box = new THREE.Mesh(roundedBox(w, h, d, 0.03, 1),
    new THREE.MeshStandardMaterial({ color: 0x1d1826, roughness: 0.8 }));
  box.position.y = h / 2;
  box.castShadow = true;
  g.add(box);
  [[0.34, 0.2], [0.66, 0.14], [0.86, 0.08]].forEach(([ty, r]) => {
    const cone = new THREE.Mesh(new THREE.CylinderGeometry(r, r * 0.8, 0.05, 18), M.iron);
    cone.rotation.x = Math.PI / 2;
    cone.position.set(0, h * ty, d / 2 + 0.01);
    g.add(cone);
    const dust = new THREE.Mesh(new THREE.SphereGeometry(r * 0.34, 10, 8),
      new THREE.MeshStandardMaterial({ color: 0x3a3346, roughness: 0.5, metalness: 0.4 }));
    dust.position.set(0, h * ty, d / 2 + 0.04);
    g.add(dust);
  });
  const led = new THREE.Mesh(new THREE.SphereGeometry(0.03, 8, 6),
    new THREE.MeshBasicMaterial({ color: 0x7bff9d, toneMapped: false }));
  led.position.set(w / 2 - 0.08, h - 0.08, d / 2 + 0.01);
  g.add(led);
  g.userData.led = led;
  return g;
}

/** Triangular bunting on a slack line. */
export function makeBunting(M, from, to, sag = 0.5, n = 14) {
  const g = new THREE.Group();
  const { curve, geometry } = catenary(from, to, sag, 24, 0.008);
  g.add(new THREE.Mesh(geometry, M.iron));
  const cols = [0xe4869a, 0xf3c98b, 0x9fb8ff, 0xc98ad8, 0x8fd0c0];
  const flags = [];
  for (let i = 1; i < n; i++) {
    const p = curve.getPoint(i / n);
    const shape = new THREE.Shape();
    shape.moveTo(-0.16, 0); shape.lineTo(0.16, 0); shape.lineTo(0, -0.3); shape.lineTo(-0.16, 0);
    const flag = new THREE.Mesh(new THREE.ShapeGeometry(shape),
      new THREE.MeshStandardMaterial({
        color: cols[i % cols.length], roughness: 0.9, side: THREE.DoubleSide,
        emissive: cols[i % cols.length], emissiveIntensity: 0.14
      }));
    flag.position.copy(p);
    flag.userData.seed = i * 0.5;
    g.add(flag);
    flags.push(flag);
  }
  g.userData.flags = flags;
  return g;
}
