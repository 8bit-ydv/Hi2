/* =============================================================
   WORLD — persistent atmospheric layers (canvas)
   starfield · floating embers · confetti burst
   All DPR-aware, visibility-aware, mobile-throttled.
   ============================================================= */
(function (w) {
  const reduce = matchMedia("(prefers-reduced-motion: reduce)").matches;
  const isMobile = matchMedia("(max-width: 820px)").matches;

  function fit(cv) {
    const dpr = Math.min(devicePixelRatio || 1, isMobile ? 1.6 : 2);
    cv.width = innerWidth * dpr;
    cv.height = innerHeight * dpr;
    cv.style.width = innerWidth + "px";
    cv.style.height = innerHeight + "px";
    const ctx = cv.getContext("2d");
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    return ctx;
  }

  /* ---------------- STARFIELD ---------------- */
  const Stars = {
    init() {
      this.cv = document.getElementById("starfield");
      this.ctx = fit(this.cv);
      this.build();
      addEventListener("resize", () => { this.ctx = fit(this.cv); this.build(); }, { passive: true });
    },
    build() {
      const n = isMobile ? 90 : 220;
      this.s = Array.from({ length: n }, () => ({
        x: Math.random() * innerWidth,
        y: Math.random() * innerHeight * 0.85,
        r: Math.random() * 1.25 + 0.25,
        a: Math.random() * 0.6 + 0.2,
        tw: Math.random() * 0.02 + 0.004,
        ph: Math.random() * Math.PI * 2,
        d: Math.random() * 0.7 + 0.3 // depth for parallax
      }));
    },
    render(t, px, py, fade) {
      const c = this.ctx;
      c.clearRect(0, 0, innerWidth, innerHeight);
      if (fade <= 0.01) return;
      for (const s of this.s) {
        const a = s.a * (0.6 + 0.4 * Math.sin(t * s.tw + s.ph)) * fade;
        c.globalAlpha = a;
        c.fillStyle = a > 0.65 ? "#fff2d6" : "#dfe4ff";
        c.beginPath();
        c.arc(s.x + px * 26 * s.d, s.y + py * 18 * s.d - Stars.scroll * s.d * 0.06, s.r, 0, 6.283);
        c.fill();
      }
      c.globalAlpha = 1;
    },
    scroll: 0
  };

  /* ---------------- EMBERS / DUST / CONFETTI ---------------- */
  const Particles = {
    init() {
      this.cv = document.getElementById("particles");
      this.ctx = fit(this.cv);
      this.warm = 0;        // 0 = cool dust, 1 = warm embers
      this.confetti = [];
      this.build();
      addEventListener("resize", () => { this.ctx = fit(this.cv); this.build(); }, { passive: true });
    },
    build() {
      const n = isMobile ? 26 : 60;
      this.p = Array.from({ length: n }, () => this.spawn(true));
    },
    spawn(rand) {
      return {
        x: Math.random() * innerWidth,
        y: rand ? Math.random() * innerHeight : innerHeight + 20,
        r: Math.random() * 2.1 + 0.6,
        vy: -(Math.random() * 0.28 + 0.08),
        vx: (Math.random() - 0.5) * 0.16,
        a: Math.random() * 0.5 + 0.15,
        ph: Math.random() * 6.283,
        warmC: `rgba(255,${(180 + Math.random() * 40) | 0},120,1)`,
        d: Math.random() * 0.8 + 0.2
      };
    },
    burst(x, y, count) {
      const N = isMobile ? Math.round(count * 0.55) : count;
      const colors = ["#f3c98b", "#ffd89b", "#e4869a", "#9fb8ff", "#fff3e0", "#c98a6b"];
      for (let i = 0; i < N; i++) {
        const ang = Math.random() * Math.PI * 2;
        const sp = Math.random() * 9 + 2.5;
        this.confetti.push({
          x, y,
          vx: Math.cos(ang) * sp,
          vy: Math.sin(ang) * sp - 3.5,
          w: Math.random() * 7 + 3,
          h: Math.random() * 4 + 2,
          rot: Math.random() * 6.283,
          vr: (Math.random() - 0.5) * 0.34,
          c: colors[(Math.random() * colors.length) | 0],
          life: 1
        });
      }
      if (this.confetti.length > 700) this.confetti.splice(0, this.confetti.length - 700);
    },
    render(t, px, py) {
      const c = this.ctx;
      c.clearRect(0, 0, innerWidth, innerHeight);

      // ambient particles
      for (const p of this.p) {
        p.y += p.vy * (1 + this.warm * 0.9);
        p.x += p.vx + Math.sin(t * 0.001 + p.ph) * 0.22;
        if (p.y < -20) Object.assign(p, this.spawn(false));
        const a = p.a * (0.55 + 0.45 * Math.sin(t * 0.002 + p.ph));
        c.globalAlpha = a;
        c.fillStyle = this.warm > 0.35 ? p.warmC : "rgba(198,206,255,1)";
        c.shadowBlur = this.warm > 0.35 ? 12 : 6;
        c.shadowColor = this.warm > 0.35 ? "rgba(255,170,80,.9)" : "rgba(160,180,255,.6)";
        c.beginPath();
        c.arc(p.x + px * 18 * p.d, p.y + py * 12 * p.d, p.r * (1 + this.warm * 0.35), 0, 6.283);
        c.fill();
      }
      c.shadowBlur = 0;

      // confetti
      for (let i = this.confetti.length - 1; i >= 0; i--) {
        const f = this.confetti[i];
        f.vy += 0.17;
        f.vx *= 0.992;
        f.x += f.vx; f.y += f.vy; f.rot += f.vr;
        f.life -= 0.0055;
        if (f.life <= 0 || f.y > innerHeight + 60) { this.confetti.splice(i, 1); continue; }
        c.save();
        c.globalAlpha = Math.max(0, Math.min(1, f.life));
        c.translate(f.x, f.y);
        c.rotate(f.rot);
        c.fillStyle = f.c;
        c.fillRect(-f.w / 2, -f.h / 2, f.w, f.h * (0.4 + 0.6 * Math.abs(Math.sin(f.rot))));
        c.restore();
      }
      c.globalAlpha = 1;
    }
  };

  /* ---------------- LOOP ---------------- */
  const World = {
    mx: 0, my: 0, tx: 0, ty: 0, paused: false, covered: false,
    init() {
      Stars.init(); Particles.init();
      if (!reduce) {
        addEventListener("pointermove", e => {
          this.tx = (e.clientX / innerWidth - 0.5) * 2;
          this.ty = (e.clientY / innerHeight - 0.5) * 2;
        }, { passive: true });
      }
      document.addEventListener("visibilitychange", () => { this.paused = document.hidden; });
      let last = 0;
      let cleared = false;
      const loop = t => {
        requestAnimationFrame(loop);
        if (this.paused) return;
        // the 3D house covers the viewport completely — no point drawing
        // two full-screen canvases underneath it
        if (this.covered) {
          if (!cleared) {
            Stars.ctx.clearRect(0, 0, innerWidth, innerHeight);
            Particles.ctx.clearRect(0, 0, innerWidth, innerHeight);
            cleared = true;
          }
          return;
        }
        cleared = false;
        if (t - last < 22) return;                 // ~45fps is plenty for dust
        last = t;
        this.mx += (this.tx - this.mx) * 0.045;
        this.my += (this.ty - this.my) * 0.045;
        Stars.render(t, this.mx, this.my, this.starFade);
        Particles.render(t, this.mx, this.my);
      };
      requestAnimationFrame(loop);
    },
    starFade: 1,
    setStarFade(v) { this.starFade = v; },
    setWarm(v) { Particles.warm = v; },
    setScroll(v) { Stars.scroll = v; },
    setCovered(v) { this.covered = !!v; },
    burst(x, y, n) { Particles.burst(x, y, n); },
    get pointer() { return { x: this.mx, y: this.my }; },
    isMobile, reduce
  };

  w.World = World;
})(window);
